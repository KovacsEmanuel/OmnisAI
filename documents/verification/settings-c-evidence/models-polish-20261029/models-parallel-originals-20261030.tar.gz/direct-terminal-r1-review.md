# R1 independent — terminal read / selected-operation hydration

## Verdict: APPROVED_SCOPED

Nu am identificat un blocker concret în delta `ea78ee2705156af88f53df92549f93a99ef71149..db6ab2bc4ff04f71cb101ca4f815fb74ccae0bd7`. Aprobarea privește corecția SOURCE a suprascrierii citirii terminale de către hidratarea locală a aceleiași operații și oracolul regresiei. Permite trecerea la QA reală afectată, după reviewul complementar și prerechizitele/slotul deținute de părinte; nu acordă PASS browser/API/PG, integrare, instalare sau închidere T1/T2.

## Identitatea verificată independent

- Checkout: `/home/kali/.hermes/cache/scratch/settings-inline-feedback-20261029`; branch `feat/settings-inline-feedback-20261029`.
- HEAD: `db6ab2bc4ff04f71cb101ca4f815fb74ccae0bd7`; tree: `74ae52e6139714df1472aca01b79395cc61a9826`.
- Exact două căi schimbate, `+55/-2`: `web/src/features/engagement/SettingsModelsPage.tsx` și `web/src/app/SettingsWizard.test.tsx`.
- Page blob: `a3d799db11051d14c7bc8754055b1eb736cf6c25`; test blob: `834934e9cc6adb97336f861a24a54accd020f6d7`. Blobs working-tree coincid cu HEAD; SHA256 coincid cu `astra-evidence/freeze.json`.
- SHA256 al diff-ului binar generat independent și al originalului `astra-evidence/direct-terminal.delta.diff`: `7c91cfe788c156964110c504ccfd1ec6f381ddd0627643a86b65a55ba53d5ebd`; egalitate byte-exact.
- Wizard `a9ddccfa4867aef0f3352c2f6eab01a18acca769` și E2E `f9436bdb7d9fb6dd0ffad165806b561e7e9726ac` neschimbate în această deltă. Acceptările lor anterioare nu sunt reauditate sau extinse aici.
- Tracked/index curate înainte și la verificarea finală. Numai cele patru symlinkuri untracked preexistente: `api/.venv`, `cli/.venv`, `tools/development/anti-slop/node_modules`, `web/node_modules`; tipul/țintele coincid cu freeze-ul. Nu au fost înlocuite, adoptate ori șterse.
- Hashurile buildului existent coincid cu freeze-ul: manifest `c1a0ba960ec48b2f3d1f427725ab1895170645ddd2fb0aaf3b364d4d66b9f96a`, JS `index-CnipzoFp.js` → `d96ea4540841d43fa2be2b66754a7d0888cbb04206a87ebbe5c3497c522bc0b1`. Aceasta este identitate de artefact, nu execuție de browser.

## Scope și traseul consumatorului

Cerință → consumator → risc → decizie: rezultatul exact terminal trebuie să rămână autoritativ față de cache-ul local mai vechi; App → ProviderSettings → SettingsModelsPage; altfel al doilea Test sănătos rămâne Connecting/Cancel și blochează progresul normal. Un defect concret revine la Astra; clearance-ul SOURCE permite QA healthy pe bytes noi.

Contractul relevant este `web/design/settings-final.md:25–39,54–56,88–92,136–142`: citire terminală exactă, Connected numai pentru identitate/revizii curente, Cancel/readback pe operația activă, fresh recovery și fără reluarea automată a apelurilor.

Am urmărit callerul unic `ProviderSettings.tsx:20–22` (mount legat de scope), `SettingsModelsPage.tsx:56–118,152–159,247–329,420–438,513–524`, clientul `shared/api/client.ts:74–102`, decoderul `shared/api/modelTest.ts:49–63`, `exactCheck` din `SettingsModels.ts:32–34`, fixture-ul HTTP și testele de recuperare afectate. Nu sunt necesare schimbări în fixture/config/export/API: guardul este local efectului comun de hidratare, iar noile aserțiuni ating consumatorul App existent.

## Cerință → cod → dovadă → evaluare

| Criteriu | Evaluare focalizată |
|---|---|
| FINISHED/rev3 al operației selectate nu redevine RUNNING/rev2 din biblioteca locală | **Satisfăcut SOURCE.** La `SettingsModelsPage.tsx:110–118`, `active.operation_id !== operation` oprește exact scrierea vechii proiecții peste query-ul selectat. Când `operationPending` devine false la terminal, biblioteca poate fi încă RUNNING; efectul ulterior `:153–159` poate acum proiecta `observed` fără ca efectul anterior să îl invalideze. Dependența `operation` corespunde valorii citite. |
| Save & connect pentru A → Connected, apoi Test direct B → Connected automat | **Satisfăcut de regresia App/HTTP sintetic, nu încă de QA reală.** Testul nou `SettingsWizard.test.tsx:684–735` folosește StrictMode și acțiuni normale de consent/Start, ține numai GET-ul exact al lui B și cere Connecting/Cancel pentru B, A încă Connected. După release cere simultan query B și library B FINISHED/rev3, UI Connected și dispariția Cancel. Nu apasă Read/Reload/Stop și nu injectează terminalul direct în QueryClient. |
| Recuperarea unei operații active distincte pe pagină nouă rămâne disponibilă | **Păstrată SOURCE.** Pentru `operation=null` sau un istoric terminal A, B activă are identitate diferită, deci este în continuare seed-uită/selectată și citită exact. `operationPending/sending/connecting` rămân barierele anterioare. Testele existente `:1039–1066` acoperă fresh-unknown-first și istoric remembered completed/unknown; `:976–1037` verifică read/Cancel pe ID activ, inclusiv fresh hydration, fără Start nou în modul hydrated. |

Oracolul nou este discriminant: fixture-ul produce terminalul prin răspunsul HTTP, trecând prin client/decoder/componentă. Aserțiunile `:722–729` verifică identitatea și revizia atât în query, cât și în bibliotecă/UI, păstrarea primului rezultat, exact două Starts distincte, lista exactă a mutațiilor și cheile neschimbate. Nu transformă succesul lui A în succes pentru B și nu introduce read manual ca workaround. Mockul HTTP nu probează workerul, PG, rețeaua nativă sau statusul fizic al peerului.

Guardul nu schimbă pollingul750ms, deadline-ul300s, cererile Start/Cancel, pinul generation, Stop, UNKNOWN, `current`/reviziile/capurile sau `exactCheck`. Connected continuă să fie calculat din rezultatul exact eligibil, nu din simpla lipsă a stării busy. Nu apare o nouă cale de retry/resend sau de expunere a datelor.

## Dovezi originale citite, fără rerulare

Sursa este CURRENT din `astra-result.md` și originale distincte din `/home/kali/.hermes/cache/scratch/t1-parallel-20261030/astra-evidence/`. Am citit argv/cwd/returncode și stdout/stderr relevante, nu numai sumarul developerului.

- `direct-red-2.command.json` + stdout/stderr: `npm test -- src/app/SettingsWizard.test.tsx -t 'SOURCE healthy direct Test'`, exit1, **1 FAIL / 108 skipped**. La `:722`, aceeași operație `906c8b4e-f405-413e-9311-edd23695e497`: fixture FINISHED/rev3, query RUNNING/rev2, exactReads2, starts2, visibility=visible. Acesta este RED-ul comportamental reținut, executat de autor; nu o execuție independentă a mea.
- `direct-green.*`, aceeași selecție: exit0, **1 PASS / 108 skipped**; stderr gol.
- `direct-regression.*`: `npm test -- src/app/SettingsWizard.test.tsx -t 'SOURCE healthy direct Test|recovers the actual active check|expands history without replacing|remote UNKNOWN|manual read uncertainty|ends the unsent sequence|does not claim Connected|orphan RUNNING Cancel|SOURCE missing local projection|Save & connect waits'`, exit0, **27 PASS / 82 skipped**; stderr gol. Am inspectat codul testelor fresh/distinct/history/Cancel, nu am dedus acoperirea numai din număr.
- `direct-lint.*`, `direct-typecheck.*`, `direct-build.*`: `npm run lint`, `npm run typecheck`, `npm run build`, toate exit0; stdouturile confirmă comenzile reale și buildul cu contract/design/tsc/Vite. Nu sunt probe de corectitudine live.
- Comenzile de integritate executate de mine: `git status --short --branch`, `git rev-parse`, `git show --stat --oneline HEAD`, diff exact/name-status/numstat, `git diff --check ea78ee2705156af88f53df92549f93a99ef71149..HEAD`, `git hash-object` și comparațiile SHA256/freeze/build; exit0, identitățile de mai sus confirmate.

Nu am rerulat SOURCE doar pentru a reproduce numerele: nu a rămas o suspiciune concretă care să justifice o nouă execuție. Nu am rulat suite neafectate sau creat harness/observer nou.

## Dispoziția constatărilor/eșecurilor anterioare

1. **Suprascriere locală same-operation terminal→RUNNING:** remediată și **CLOSED_SCOPED_SOURCE** pe bloburile db6ab2b de mai sus. RED-ul reținut, guardul și GREEN/regresiile ating aceeași clasă/caller; nu este schimbat oracolul pentru verde.
2. **`direct-red` inițial:** lookup al rândului înainte de Save/readback, nu product RED. Nu îl număr drept demonstrație a defectului; `direct-red-2` este demonstrația comportamentală.
3. **Healthy real pe ea78ee2, al doilea direct Test la E2E `:238`:** rămâne FAIL istoric, cauză internă **NEATRIBUITĂ**. Fără martorul operației/workerului din acea execuție, clasa SOURCE demonstrată nu dovedește retrospectiv cauza ei. QA healthy pe db6ab2b rămâne **NOT_RUN** în acest review.
4. **Stop-read real PASS pe ea78ee2:** dovadă anterioară comunicată/verificată de părinte, nu rerulată aici și nu înlocuiește healthy fără Stop. Nu transfer această acceptare la noul guard.

**Findings blocante curente în delta: niciunul identificat.** Nu rezultă absența tuturor bugurilor și nu este o garanție generală de monotonicitate pentru orice răspuns HTTP întârziat; concluzia privește suprascrierea locală same-operation și recuperarea distinctă urmărite aici.

## Predare și limite

Propunere către părinte: cod IMPLEMENTED în candidat / dovadă SOURCE PASS în originalele autorului / review R1 APPROVED_SCOPED; QA reală healthy pe acest freeze NOT_RUN. Părintele adjudecă reviewurile și admite consumatorul PG/browser afectat numai după slotul Sol și preflightul propriu. E2E neschimbat trebuie să obțină automat Connected pentru ambele Starts, apoi identități/exact/current/latest/revizii/cap64 și cleanup/census conform criteriilor existente, fără read manual sau relaxarea limitelor.

Am creat numai acest raport original scratch; nu am editat produs/teste/fixture, harta de status, skilluri sau index și nu am făcut commit. Niciun acces PG/OCI/operator/model, agent nou, configurație Hermes sau fișier protejat. Reticle NOT_INTEGRATED; Chisel BLOCKED_NO_GO; fără instalare/instrumentare.

Am omis intenționat rerulări, QA nativă/PG și auditul vechi Add/Remove/UI; ele nu intră în acest review read-only al deltei.
Risc rămas: healthy real pe bytes noi și cauza FAIL-ului istoric nu sunt încă probate; APPROVED_SCOPED nu închide T1/T2 sau instalarea.
