"""Bounded SOURCE R2 review only; synthetic storage/SDK sink, no services."""
import os
import sys
import socket
from pathlib import Path

ROOT = Path('/home/kali/.hermes/cache/scratch/omnis-s1-20261104')
sys.path[:0] = [str(ROOT / 'api/src'), str(ROOT / 'api/tests')]
os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD'] = '1'
blocked = []
def audit(event, args):
    if event in {'socket.connect', 'socket.bind', 'socket.getaddrinfo', 'socket.gethostbyname', 'socket.gethostbyaddr', 'subprocess.Popen', 'os.system', 'os.posix_spawn', 'os.fork'} or (event == 'socket.__new__' and args[1] in (socket.AF_INET, socket.AF_INET6)):
        blocked.append(event)
        raise RuntimeError('NO_EFFECT:' + event)
    if event == 'open' and len(args) > 2 and isinstance(args[2], int) and args[2] & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND):
        path = Path(args[0]).resolve() if isinstance(args[0], (str, bytes)) else None
        own = Path('/home/kali/.hermes/cache/scratch/s1-env-20261104/run-evidence/main-fixes/r2-private')
        if path is not None and path != Path('/dev/null') and not path.is_relative_to(own):
            blocked.append('write:' + str(path))
            raise RuntimeError('NO_WRITE_OUTSIDE_PRIVATE')
sys.addaudithook(audit)
import importlib.metadata
import pytest
print('PINS', {name: importlib.metadata.version(name) for name in ('openai-agents', 'openai', 'cryptography')})
rc = pytest.main(['-p', 'pytest_asyncio.plugin', '-p', 'no:cacheprovider', '-c', str(ROOT / 'api/pyproject.toml'),
 str(ROOT / 'api/tests/test_run_data_source.py'), str(ROOT / 'api/tests/test_run_finish_source.py'), str(ROOT / 'api/tests/test_run_refusals_source.py'),
 str(Path(__file__).with_name('r2-finish-error-probe.py')), '-q', '--tb=short'])
print('AUDIT_BLOCKED_ATTEMPTS', blocked)
raise SystemExit(rc)
