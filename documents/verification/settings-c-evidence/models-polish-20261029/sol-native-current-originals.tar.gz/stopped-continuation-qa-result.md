QA INDEPENDENTĂ — CONTINUAREA ACELEIAȘI FIXTURE

Rezultat funcțional scoped: Start DEVELOPMENT0/READY → observație90s → Stop normal0/STOPPED, cu identitate și settlement verificate. Există însă un FAIL al anvelopei QA, păstrat explicit; nu declar invocarea inițială exit0 sau acceptare globală.

Snapshot/input: helper f7f0c8cdbab0d41260efeb027dc21d901be32dfb, worktree curat /home/kali/.hermes/cache/scratch/settings-supervisor-tcp-20261030. Aceleași data_home omnis-bundle-xi8ua6is/data, CLI privat și state/control s4-6s7mt9bt, fără recreare de fixture/config, build, reluarea RELEASE ori alt owner. Preflight-ul nou a confirmat status0 STOPPED/generation2/UUID fd7d96a8-2441-4176-bc34-de8b2e5e8e31/origin60349; preflight_port real fără reuse, constructor ControlRuntime, profil/daemon/imagine/manifest/PG și proiect fără resurse. Toate131 fișierele prepared și6 observatori au hashes conforme. Claimul admission.json este nou, exclusiv O_EXCL|O_NOFOLLOW/0600, fsync înaintea Start; root QA0700.

Execuția reală proc_817ddd0160c4, prin CLI-ul privat, fără pipeline:
  start --no-open --json: exit0, READY/DEVELOPMENT, același UUID/origin, release0.1.1/schema0017_model_removal, generation3, supervisor_epoch2, assessment_ready=false.
  Canalul control.request/status:90.094752369s,84 citiri, identitate/epoch/generation/admission stabile. Censusul read-only existent system_operation/model_dispatch_v2:0|0.
  stop --json: exit0, STOPPED/DEVELOPMENT, același UUID/origin, generation4. Exact un Start și un Stop; nicio încercare repetată, fault injection, rescue sau recovery.

Defectul anvelopei QA și limita procedurală: după Stop ACK, invoke.py a cerut eronat câmpurile release/schema din răspunsul public Stop, care nu le expune. A rezultat KeyError, runner exit1 la117.988s și result.json FAIL_OR_INCOMPLETE_RETAINED/cleanup inițial UNCERTAIN. Fișierul și codul anvelopei nu au fost rescrise/rerulate. Numai settlement/readback a fost continuat într-o invocare read-only separată, cu deadline-ul600s ORIGINAL din claim, nu resetat. Așadar, cerința literală „totul într-o singură invocare” nu este îndeplinită integral; părintele adjudecă această abatere, fără a transforma vechiul FAIL în PASS. Release/schema au fost confirmate prin producerii reali ControlRuntime și status, nu inventate în Stop JSON.

Readbackul suplimentar: exit0, încheiat la157.980105310s de la începutul original. Status final0 STOPPED/generation4; același daemon94260307-c33f-46ac-af7c-8a5ac1a7ffdc. Receiptul produs stop-cdf10c51-d466-4fb5-954e-3e90cb752593.json este COMPLETED și trece completed_receipt/validate_inventory/validate_grant. ACK-urile tuturor etapelor și absența identităților originale owner/launcher/forwarder sunt verificate; existing assert_resources_absent confirmă proiectul, CIDs exacte, network și IPC absente; listenerul60349 absent. PGDATA păstrat, configurația și originalele anterioare hash-identice. Nu deduc drain numai din flagurile constructorului.

Observație nativă: raw-sol-events.jsonl păstrează envelopele originale, PID/cycle/tag și ceasurile occurrence/receipt. Readerul existent summarize() a trecut: ModelOwner real1,16 callback returns,92 heartbeat commits, observer end și martor settled fără thread/packet parțial/overflow. Nu s-a reprodus interval multi-second; cauza rămâne UNKNOWN, fără remediu demonstrat. observed-signal-excerpts.json conține un ciclu raw COMMIT begin→protocol success→driver success→pool checkin→service return; nu atribui cauza după simplul maxim driver.

Originale noi:
  /home/kali/.hermes/cache/scratch/settings-sol-team-b45fd55/stopped-continuation-qa/
  result.json — FAIL-ul original al anvelopei, nemodificat
  readback-continuation.json — settlement verificat, aceeași limită600s
  02-start-result.json și04-stop-result.json — stdout/stderr/coduri private înaintea aserțiunilor
  observer-summary.json, observed-signal-excerpts.json, raw-sol-events.jsonl
Raw SHA256:bc9eb63e98bf1d71ada9e56b4862a3db2964e56e838009a04d139ad027452b9a.

Limite: fixture-ul este acum oprit intenționat; nu instalația operatorului recuperată. Fără produs/provider/Refresh/target/browser, secrete personale, fișiere protejate, editări repo/config/observatori, commit sau push. Istoricul2/2+1/1+team-normal1FAIL+direct-prefix1FAIL rămâne. Nu închid T1/T2/canonical și nu atribui PORT_CONFLICT trecut lui TIME_WAIT. Acceptarea scoped și integrarea aparțin părintelui.
