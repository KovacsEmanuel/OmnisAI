"""No-DB calibration of the existing observer's return/outcome boundary."""
import ast
import asyncio
import functools
from pathlib import Path
from types import SimpleNamespace

HERE = Path(__file__).parent


def driver_control(path):
    tree = ast.parse(path.read_text())
    wrap = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'wrap_driver')
    rows = []

    class Connection:
        info = SimpleNamespace(backend_pid=42)
        pgconn = SimpleNamespace(transaction_status=0)
        outcome = 'success'

        async def commit(self):
            if self.outcome == 'error':
                raise ValueError('synthetic-private-payload')
            if self.outcome == 'cancel':
                raise asyncio.CancelledError()
            return 'accepted'

    namespace = dict(asyncio=asyncio, functools=functools,
                     psycopg=SimpleNamespace(AsyncConnection=Connection),
                     TAG=SimpleNamespace(get=lambda: 'heartbeat:1'),
                     emit=lambda kind, **kw: rows.append(dict(kind=kind, **kw)))
    exec(compile(ast.Module(body=[wrap], type_ignores=[]), str(path), 'exec'), namespace)
    namespace['wrap_driver']('commit')

    async def check():
        for outcome in ('success', 'error', 'cancel'):
            rows.clear()
            connection = Connection()
            connection.outcome = outcome
            try:
                result = await connection.commit()
                assert result == 'accepted' and outcome == 'success'
            except ValueError:
                assert outcome == 'error'
            except asyncio.CancelledError:
                assert outcome == 'cancel'
            endings = [row['kind'] for row in rows if row['kind'] != 'driver_commit_begin']
            assert endings == ['driver_commit_' + outcome], (outcome, endings)
            assert 'synthetic-private-payload' not in repr(rows)
    asyncio.run(check())
    print('DRIVER_OUTCOMES success/error/cancel exact; no finally-as-ACK')


def channel_control():
    import json
    import os
    import tempfile
    import time
    import sys
    sys.path.insert(0, str(HERE))
    from run_native import preflight
    options = preflight()
    sys.path.insert(0, str(Path(options['workspace']) / 'api/src'))
    from omnis.supervisor import _sol_native_bootstrap as boot
    from omnis.supervisor import _sol_observe_existing as obs
    from unittest.mock import patch

    with tempfile.TemporaryDirectory(prefix='sol-control-', dir=HERE) as name:
        output = Path(name) / 'events.jsonl'
        with boot.attach(SimpleNamespace(__file__=__file__), inert_output=output):
            async def controls():
                for outcome in ('success', 'error', 'cancel'):
                    token = obs.TAG.set('heartbeat:' + outcome)
                    class Connection:
                        info = SimpleNamespace(backend_pid=42)
                        pgconn = SimpleNamespace(transaction_status=0)
                    def original_command(self, command, *a, **kw):
                        yield 'protocol-progress'
                        if outcome == 'error':
                            raise ValueError('synthetic-private-payload')
                        if outcome == 'cancel':
                            raise asyncio.CancelledError()
                        return SimpleNamespace(status=obs.psycopg.pq.ExecStatus.COMMAND_OK, command_status=b'COMMIT')
                    async def commit(self):
                        iterator = obs.observed_command(self, b'COMMIT')
                        assert next(iterator) == 'protocol-progress'
                        await asyncio.sleep(.08)
                        try:
                            next(iterator)
                        except StopIteration as returned:
                            assert returned.value.command_status == b'COMMIT'
                            return 'accepted'
                    Connection.commit = commit
                    class Service:
                        async def heartbeat(self):
                            value = await Connection().commit()
                            obs.checkin(SimpleNamespace(driver_connection=Connection()), None)
                            return value
                    with patch.object(obs.psycopg, 'AsyncConnection', Connection), patch.object(obs, 'original_command', original_command), patch.object(obs, 'InstanceService', Service):
                        obs.wrap_driver('commit')
                        obs.install_service('heartbeat', Service.heartbeat)
                        try:
                            value = await Service().heartbeat()
                            assert outcome == 'success' and value == 'accepted'
                        except ValueError:
                            assert outcome == 'error'
                        except asyncio.CancelledError:
                            assert outcome == 'cancel'
                    obs.TAG.reset(token)
            asyncio.run(controls())
            for outcome, value in [('queued', None), ('not_acknowledged', SimpleNamespace(status=obs.psycopg.pq.ExecStatus.COMMAND_OK, command_status=b'ROLLBACK'))]:
                def no_ack(*a, **kw):
                    yield from ()
                    return value
                token = obs.TAG.set('control:' + outcome)
                with patch.object(obs, 'original_command', no_ack):
                    iterator = obs.observed_command(SimpleNamespace(info=SimpleNamespace(backend_pid=42)), b'COMMIT')
                    try:
                        next(iterator)
                    except StopIteration:
                        pass
                obs.TAG.reset(token)
            async def inert_run():
                await asyncio.sleep(.12)
            accepted = []
            async def inert_connect(cls, conninfo='', **kwargs):
                accepted.append(True)
                return 'accepted'
            consumer = SimpleNamespace(run=inert_run)
            raw = 'postgresql+psycopg://omnis:synthetic@db:5432/omnis'
            with patch.dict(os.environ, {'OMNIS_DATABASE_URL': raw}), patch.object(obs.psycopg.AsyncConnection, 'connect', classmethod(inert_connect)):
                boot.install(consumer)
                async def connect_controls():
                    from omnis.core.db import database_engine
                    engine = database_engine(raw)
                    args, kwargs = engine.sync_engine.dialect.create_connect_args(engine.url)
                    assert await obs.psycopg.AsyncConnection.connect(*args, **kwargs) == 'accepted'
                    for changed in ({'host': 'other.invalid'}, {'hostaddr': '127.0.0.1'}, {'port': 5433}):
                        try:
                            await obs.psycopg.AsyncConnection.connect(*args, **{**kwargs, **changed})
                        except PermissionError:
                            pass
                        else:
                            raise AssertionError('DB guard admitted wrong endpoint')
                    assert accepted == [True]
                    await engine.dispose()
                    await consumer.run()
                asyncio.run(connect_controls())
            print('INSTALLED_ATTACHMENT_CONTROL imports/hooks/SQLAlchemy DB args; 1 synthetic allowed / 3 refused; native loop signal')
            boot.no_network('socket.getaddrinfo', ('db', 5432, 0, 0, 0))
            denied = 0
            for args in [('other.invalid', 443, 0, 0, 0), ('db', 443, 0, 0, 0)]:
                try:
                    boot.no_network('socket.getaddrinfo', args)
                except PermissionError:
                    denied += 1
            assert denied == 2
        rows = [json.loads(line) for line in output.read_text().splitlines()]
        events = [row['event'] for row in rows if row['kind'] == 'native_event_received']
        for index, outcome in enumerate(('success', 'error', 'cancel'), start=1):
            same = [row for row in events if row['tag'] == 'heartbeat:' + str(index)]
            assert any(row['kind'] == 'service_' + ('return' if outcome == 'success' else outcome) for row in same)
            assert [row['kind'] for row in same if row['kind'].startswith('driver_commit_')] == ['driver_commit_begin', 'driver_commit_' + outcome]
            assert [row['kind'] for row in same if row['kind'].startswith('protocol_COMMIT_')] == ['protocol_COMMIT_begin', 'protocol_COMMIT_' + outcome]
            assert any(row['kind'] == 'pool_checkin' for row in same) == (outcome == 'success')
        for outcome in ('queued', 'not_acknowledged'):
            same = [row for row in events if row['tag'] == 'control:' + outcome]
            assert [row['kind'] for row in same] == ['protocol_COMMIT_begin', 'protocol_COMMIT_' + outcome]
        assert rows[-1]['kind'] == 'independent_process_settled'
        assert not rows[-1]['thread_alive'] and not rows[-1]['partial_packet']
        assert any(row['kind'] == 'independent_process_progress' for row in rows)
        assert all(row['observer_pid'] != row['event']['pid'] and row['mono_ns'] >= row['event']['mono_ns'] for row in rows if row['kind'] == 'native_event_received')
        assert 'synthetic-private-payload' not in output.read_text()
        assert not any(row['kind'] in {'independent_private_db', 'native_backend_sample'} for row in rows)
        from observe_native_case import summarize
        try:
            summarize(output)
        except ValueError as error:
            assert str(error) == 'OBSERVATION_IDENTITY_OR_CLOSURE_MISSING'
        else:
            raise AssertionError('Synthetic calibration became installed evidence')
        print('CHANNEL_CONTROL success/error/cancel; queued/ROLLBACK not ACK; protocol/driver/pool/service; occurrence<=receipt; independent PID; zero DB; synthetic rejected as native')
    read_fd, write_fd = os.pipe()
    os.set_blocking(write_fd, False)
    start = time.monotonic()
    previous = obs.dropped
    try:
        obs.fd = write_fd
        for _ in range(2000):
            obs.emit('bounded_saturation_control')
        assert obs.dropped > previous
        assert time.monotonic() - start < 2
        print('BACKPRESSURE_CONTROL nonblocking; dropped=' + str(obs.dropped - previous))
    finally:
        obs.fd = None
        os.close(write_fd)
        os.close(read_fd)


if __name__ == '__main__':
    import sys
    if sys.argv[1:] == ['--channel']:
        channel_control()
    else:
        driver_control(Path(sys.argv[1]))
