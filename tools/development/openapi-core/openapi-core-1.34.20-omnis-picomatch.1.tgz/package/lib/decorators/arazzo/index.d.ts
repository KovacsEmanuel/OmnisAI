export declare const decorators: {};
