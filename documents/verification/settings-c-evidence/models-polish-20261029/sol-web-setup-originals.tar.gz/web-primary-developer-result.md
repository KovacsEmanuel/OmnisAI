VERDICT: CANDIDAT TEST-ONLY VERIFICAT SCOPED, REVIEW INDEPENDENT PENDING. Nu este remediu cauzal al FAIL-ului istoric și nu închide full-web/T1.

1. Demonstrat versus UNKNOWN

Unica invocare SOURCE diagnostică admisă a calibrat același consumer App: origine capturată înaintea creării promisiunii; hold pre-Save observat cu zero POST și fără mesaj 413; după release au trecut oracle-ul original, exact două mutații, payloadul salvat și verificările suplimentare ale autorizării/originii sintetice. POST/PUT neforțate au trecut. Nu am reprodus timeoutul de 5000ms și nu am fabricat un RED.

În POST neforțat, setupul celor cinci câmpuri a ocupat 565.858ms din 827.816ms consumer, adică 68.356% (11.317% din limita testului). Save→413 vizibil: 19.329ms. După înlocuirea exclusivă a setupului, aceeași instrumentare/oracle a măsurat setup 22.401ms și consumer 293.833ms; name-edit a rămas 118.538→119.477ms. Eșantioane unice, nu benchmark sau atribuire CPU/VM. Demonstrează cost auxiliar dispensabil în traseul actual, nu explicația retrospectivă a celor patru FAIL-uri.

Cauza întârzierii istorice POST și bootstrapurile Provider/Settings rămân UNKNOWN, neinvestigate suplimentar. Dispoziția justificabilă actuală: costul măsurat al setupului 413 este eliminat fără slăbirea obligației sale; celelalte blocaje și originalul FAIL rămân separate.

2. Delta și FREEZE

Worktree: /home/kali/.hermes/cache/scratch/settings-web-primary-sol
Branch: fix/settings-web-primary-sol
HEAD/bază: b45fd552cd8c5c45eefbe2d47127fd02365f73c1
Singura cale modificată: web/src/app/Wizard.test.tsx:58–62, cinci user.type auxiliare → cinci fireEvent.change target-bound, aceleași câmpuri și valori.
Base blob: 7799f370ecca9bc3c4051a3a78d1d0f69fbf45ad
Candidate blob: d13bffe967645dac3ce561cb4300e1b114418323
Candidate SHA256: 6d8e6a25e9b72ebb6721643cf7964c78373008293bc21363dcc8584125e5b4e6

Egalitatea programatică față de baseline confirmă exact aceste cinci înlocuiri și nicio altă schimbare. fbb379e, tastarea numelui, 413, retenția, enabled actions, lipsa autosave, saved-payload/denials și restul fișierului sunt byte-identice. Instrumentarea/gate-ul temporar au fost retrase integral; produs/config/setup/limite/workeri/dependențe neschimbate. Fără stage/commit; candidatul este intenționat necomis pentru integrarea părintelui, nu declarat livrat în proiect.

3. Execuții reale și control negativ

Mediu explicit: PATH=/home/kali/.local/share/omnis-toolchains/bin:/usr/bin:/bin; TMPDIR=/home/kali/.hermes/cache/scratch. Node v24.21.0/npm11.19.0, pinuri existente; manifestul setează NODE_ENV=test. Toate exiturile sunt returncode ale subprocessului capturat, nu exitul wrapperului.

Comanda îngustă, înainte și după schimbarea setupului:
/home/kali/.local/share/omnis-toolchains/bin/npm --prefix web test -- src/app/Wizard.test.tsx -t '^keeps local edits actionable after a definite (POST|PUT) body-size refusal' --reporter=verbose

Baseline calibrat: 3PASS/22not-selected, Vitest7.10s, proces8.965s, exit0; buget diagnostic nou1/1 consumat.
Schimbare + control afectat: 3PASS/22not-selected, Vitest3.09s, proces3.723s, exit0. Pozitivul reținut are POST=0; negativul eliberat ajunge la 413 cu writes1, apoi Saved cu writes2, fără pierderea editărilor. Acest al doilea run are bytes de setup schimbați, nu este retry diagnostic neschimbat. RED istoric: NOT_REPRODUCED; nu numesc cele două PASS-uri RED→GREEN.

4. Checks afectate, limite și predare

Pe bytes finali, fără instrumentare:
- npm --prefix web test -- src/app/Wizard.test.tsx: 24PASS/24, Vitest9.42s, test body8.00s, exit0; cazul POST300ms.
- npm --prefix web run typecheck: exit0.
- npm --prefix web run lint: exit0, zero warnings/errors.
- git diff --check: exit0.

Prima verificare fără efecte a egalității baseline a refuzat un număr greșit de ocurențe indentate, înainte de freeze/teste; am corectat numai verificarea pe callerul exact. Refuzul este păstrat, nu raportat drept test rulat.

Originale private/read-only: /home/kali/.hermes/cache/scratch/settings-sol-team-b45fd55/web-primary-fix/
09-originals-manifest.json inventariază35 fișiere/225087bytes, fără manifestul însuși; surse baseline/calibrate/changed/final, diff, argv, stdout/stderr, exituri, spanuri și freeze. Director0700/fișiere0400. Freeze-ul final precede cleanupul. Cele două linkuri proprii node_modules au fost retrase și absența verificată; țintele comune sunt păstrate. Tracked delta este numai fișierul de test; index gol, HEAD neschimbat.

Urmează exclusiv reviewul independent al părintelui pe acest blob/diff și adjudecarea scoped. Nu există acceptare independentă nouă încă. Vechile bugete rămân consumate; această felie nu admite full-web/canonical sau extindere la alte frontiere. Nu am executat native/DB/browser/live-provider/model/Refresh/ținte, nu am modificat main/servicii/date/protected files și nu am folosit alți agenți, install/fetch/push. SOURCE nu certifică aplicația reală sau finalizarea T1.
