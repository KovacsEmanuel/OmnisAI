import asyncio,json; from types import SimpleNamespace; from contextlib import asynccontextmanager; from unittest.mock import Mock,AsyncMock; from omnis.modules.settings.provider_key_models import KeySettingsControl,KeySettingsView,SelectionViewV2; from omnis.modules.settings.provider_key_service import ProviderSettingsOwner,ConnectionRevision,SettingsConflict; from omnis.modules.settings.provider_model_service import require_removable; from omnis.modules.settings.provider_model_models import ModelEntry; from omnis.modules.runs.model_test_contract import Snapshot
A="11111111-1111-4111-8111-111111111111"; B="22222222-2222-4222-8222-222222222222"; C="33333333-3333-4333-8333-333333333333"; D="44444444-4444-4444-8444-444444444444"
choice={"connection_id":A,"connection_revision":1,"model":"Default/Model","output_tokens":64}; recon={**choice,"connection_id":B,"model":"Recon/Model","output_tokens":37}
rows=[]; receipts={}; sql=[]
async def execute(statement,params):
 s=str(statement); sql.append(s); r=Mock(); r.first.return_value=None
 if "SELECT selection_id" in s: r.mappings.return_value.one_or_none.return_value=rows[-1] if rows else None
 elif "SELECT request_digest" in s: r.mappings.return_value.one_or_none.return_value=receipts.get(params["command"])
 elif "SELECT 1 FROM public.provider_model_entry" in s: r.scalar_one_or_none.return_value=1
 elif "INSERT INTO public.provider_selection_revision" in s: rows.append({"selection_id":params["id"],"revision":params["revision"],"payload":json.loads(params["payload"])})
 elif "INSERT INTO public.provider_settings_command" in s: receipts[params["command"]]={"request_digest":params["digest"],"result":json.loads(params["result"])}
 elif "SELECT 1 FROM public.system_operation" not in s: raise AssertionError(s)
 return r
db=Mock(execute=AsyncMock(side_effect=execute))
@asynccontextmanager
async def admitted(*args): yield db
service=SimpleNamespace(engine=SimpleNamespace(connect=admitted),owned_status=AsyncMock(return_value=SimpleNamespace(instance_id=A,generation=1)),admission=admitted)
owner=ProviderSettingsOwner(service,A,1,SimpleNamespace(instance_id=A))
conn=ConnectionRevision(connection_id=A,provider="openrouter",revision=1,enabled=True,secret_id=C,credential_revision=1)
owner.connections=AsyncMock(return_value=[conn,conn.model_copy(update={"connection_id":B,"provider":"orcarouter"})])
async def view(db,command): return KeySettingsView(command_id=command,vault_status="UNCONFIGURED",connections=[],selection=await owner.selection(db))
owner.view=view
v2={"action":"save_selection_v2","command_id":C,"expected_revision":0,"default":choice,"brain":None,"investigator":None,"validator":None,"recon":recon}
legacy={k:v for k,v in v2.items() if k!="recon"}; legacy.update(action="save_selection",command_id=D,expected_revision=1)
async def main():
 first=await owner.handle(KeySettingsControl(op="provider_settings",request=v2))
 snap=Snapshot(selection=first.selection,connection=conn,capabilities_ref={"instance_id":A,"kind":"model-capabilities-v2","id":C,"revision":1,"digest":"a"*64},endpoint="https://openrouter.ai/api/v1")
 assert snap.model_dump(mode="json")["selection"]["recon"]==recon
 owner.connections.return_value=[conn]
 try: await owner.resolve_role(db,first.selection,"recon")
 except SettingsConflict as e: before=e.code
 else: raise AssertionError("stale Recon unexpectedly resolved")
 entry=ModelEntry.model_validate({**recon,"entry_id":B,"revision":1})
 try: await require_removable(owner,db,entry)
 except SettingsConflict as e: remove_before=e.code
 else: raise AssertionError("expected Remove guard")
 second=await owner.handle(KeySettingsControl(op="provider_settings",request=legacy))
 resolved=await owner.resolve_role(db,second.selection,"recon")
 await require_removable(owner,db,entry)
 assert resolved.model=="Default/Model" and "recon" not in second.selection.model_dump()
 replay=await owner.handle(KeySettingsControl(op="provider_settings",request=v2)); assert replay==first
 print(json.dumps({"boundary":"SOURCE: SQL/authority/vault seams doubled; no I/O", "snapshot_model_instance_roundtrip":"PASS", "before":{"recon_resolution":before,"remove":remove_before},"legacy_save_accepted":True,"after":{"selection_revision":second.selection.revision,"selection_type":type(second.selection).__name__,"recon_resolution":resolved.model,"remove":"ALLOWED"},"historical_receipt_unchanged":replay==first,"selection_writes":len(rows),"receipt_writes":len(receipts)},indent=2))
asyncio.run(main())
