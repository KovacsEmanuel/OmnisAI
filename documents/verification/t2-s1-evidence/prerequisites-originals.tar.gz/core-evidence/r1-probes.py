"""Read-only U02 review: fresh synthetic SOURCE fixtures only, no DB/services."""
import asyncio
import json
import os
import sys
import tempfile
from pathlib import Path
from uuid import uuid4

ROOT = Path('/home/kali/.hermes/cache/scratch/omnis-s1-20261104')
sys.path[:0] = [str(ROOT / 'api/src'), str(ROOT / 'api/tests'), str(ROOT / 'integrations/hermes/src')]
import pytest
import yaml
from omnis.modules.settings import candidate_catalog as candidates
from omnis.modules.settings import catalog_publication as publication
from omnis.modules.settings import skill_catalog
from omnis.modules.settings import candidate_store as store
from omnis.modules.settings.candidate_material import private_root, capture, finalize
from omnis.modules.settings.candidate_index import compile_material, bind_catalog, resolved_index
from omnis.modules.settings.catalog_models import CatalogError
from omnis.modules.settings.catalog_schema import canonical
from omnis.modules.runs import pure_probe
from test_agent_core_publication import storage_seam, publish_core
from test_b06a_release_product import seed, external, binding


def deny_network(event, args):
    if event in ('socket.connect', 'socket.getaddrinfo', 'subprocess.Popen'):
        raise AssertionError('Review probe forbids external effects: ' + event)
sys.addaudithook(deny_network)


async def legacy_new_admission(directory):
    with pytest.MonkeyPatch.context() as mp:
        engine = storage_seam.__wrapped__(mp)
        source = ROOT / 'api/tests/fixtures/b06b_publication/source'
        with pytest.MonkeyPatch.context() as old:
            for module in (candidates, publication):
                old.setattr(module, 'COMPILER_REVISION', candidates.LEGACY_COMPILER_REVISION)
            old.setattr(candidates, 'EVALUATOR_REVISION', candidates.LEGACY_EVALUATOR_REVISION)
            catalog, owner, ref = await publish_core(
                engine, directory / 'catalog', package=source / 'b06b-publish-contract',
                profile=source / 'profile.yaml', pure_input={'capture': '[]'},
            )
        before = await catalog.dispatch('readback', {'schema_version': 1, 'owner_id': owner, 'publication_ref': ref})
        def request(**values):
            return {'schema_version': 1, 'owner_id': owner, 'command_id': str(uuid4()), **values}
        denied = None
        try:
            await catalog.candidates.dispatch('evaluate', request(
                snapshot_ref=store.reference(before['snapshot']), evaluation_kind='PURE', input={'capture': '[]'}))
        except CatalogError as error:
            denied = error.reason
        result = await catalog.dispatch('snapshot', request(publication_ref=ref))
        probe = pure_probe.PureProbe(engine, catalog.root)
        async with engine.connect() as connection:
            _, _, profile, _ = await catalog.load_probe(connection, owner, result['snapshot_ref'])
        selected = await probe.dispatch('select', request(snapshot_ref=result['snapshot_ref'], recipe_key=profile.agent_recipes[0].key))
        calls = []
        def forbidden_execute(compiled, value):
            calls.append({'input': value, 'handlers': [s.handler for s in compiled.steps]})
            raise AssertionError('NEW_LEGACY_EXECUTION_REACHED')
        mp.setattr(pure_probe, 'execute_outputs', forbidden_execute)
        try:
            await probe.dispatch('execute', request(selection_ref=selected['selection_ref'], input={'capture': '[]'}))
        except AssertionError as error:
            assert str(error) == 'NEW_LEGACY_EXECUTION_REACHED'
        after = await catalog.dispatch('readback', {'schema_version': 1, 'owner_id': owner, 'publication_ref': ref})
        assert canonical(before) == canonical(after)
        assert denied == 'LEGACY_READ_ONLY' and len(calls) == 1
        return {'direct_evaluate': denied, 'new_run_snapshot': result['snapshot']['kind'],
                'new_execution_selection': selected['selection']['kind'], 'execution_sink_calls': calls,
                'original_publication_readback_unchanged': True,
                'qualification': 'fresh synthetic records stamped with exact legacy pair as existing source test; storage seams, no PostgreSQL; execution stopped before handler'}


async def legacy_release_reexecution(directory):
    with pytest.MonkeyPatch.context() as mp:
        root = private_root(directory / 'catalog')
        package, profile = seed(directory, 'external')
        with pytest.MonkeyPatch.context() as old:
            old.setattr(candidates, 'COMPILER_REVISION', candidates.LEGACY_COMPILER_REVISION)
            old.setattr(candidates, 'EVALUATOR_REVISION', candidates.LEGACY_EVALUATOR_REVISION)
            dependency = external(root, package, profile)
        local, local_profile = seed(directory, 'local')
        manifest_path = local / 'omnis.yaml'
        manifest = yaml.safe_load(manifest_path.read_bytes())
        manifest['input_schema_ref'] = {'kind': 'RELEASE', 'ref': binding(dependency, 'schema', 'capture')}
        manifest_path.write_text(yaml.safe_dump(manifest, sort_keys=False))
        material, sources, sha = capture([str(local)], str(local_profile))
        for source in sources:
            source['material_digest'] = sha
        records = [store.envelope('source-draft', s) for s in sources]
        frozen = finalize(root, 'drafts', str(uuid4()), material)
        bindings = []
        for source in sources:
            for kind, key in source['identities']:
                bindings.append({'package_key': source.get('package_key', 'profile'), 'entity_kind': kind,
                                 'key': key, 'ref': {'kind': kind, 'id': str(uuid4()), 'revision': 1,
                                                  'digest': source.get('package_digest', sha)}})
        refs = [b['ref'] for b in bindings]
        # Reuse actual compiler to establish a valid index, then observe only reader replay.
        index = resolved_index(bind_catalog(compile_material(frozen, sources, dependencies=(dependency,)), bindings))
        async def loaded(*args, **kwargs):
            return (dependency,)
        async def reserved(*args, **kwargs):
            return bindings
        mp.setattr(candidates, 'load_dependencies', loaded)
        mp.setattr(store, 'reservation_bindings', reserved)
        calls = []
        def forbidden_eval(compiled, value, **kwargs):
            calls.append({'input': value, 'handlers': [s.handler for s in compiled.steps]})
            raise AssertionError('LEGACY_DEPENDENCY_EVALUATOR_REACHED')
        mp.setattr(skill_catalog, 'evaluate_pure', forbidden_eval)
        instance = object.__new__(candidates.CandidateCatalog)
        instance.root = root
        try:
            await instance.compile_pinned(None, str(uuid4()), frozen, records, refs, index)
        except AssertionError as error:
            assert str(error) == 'LEGACY_DEPENDENCY_EVALUATOR_REACHED'
        assert len(calls) == 1
        return {'reader': 'CandidateCatalog.snapshot_readback -> compile_pinned -> compile_catalog',
                'qualification_compiler': json.loads(dependency.qualification_json)['payload']['compiler_revision'],
                'qualification_evaluator': json.loads(dependency.qualification_json)['payload']['evaluator_revision'],
                'evaluator_sink_calls': calls,
                'qualification': 'fresh private synthetic external release; dependency/reservation DB joins replaced; actual compiler/evaluator dispatch; intercepted before historical-input execution'}


async def main():
    base = Path(tempfile.mkdtemp(prefix='r1-source-', dir='/home/kali/.hermes/cache/scratch'))
    results = {'fixture_root': str(base), 'scope': 'SOURCE_ONLY_NO_DB_NO_NETWORK_NO_SERVICES', 'cases': {}}
    for name, operation in [('legacy_new_admission', legacy_new_admission), ('legacy_release_reexecution', legacy_release_reexecution)]:
        directory = base / name
        directory.mkdir(mode=0o700)
        results['cases'][name] = await operation(directory)
    print(json.dumps(results, indent=2))

asyncio.run(main())
