# Review independent SAFETY — delta legal-prefix, READ-ONLY

Verdict: APPROVED_SCOPED_SOURCE pentru cele două fișiere frozen. Findings noi blocante demonstrate: niciunul. Reutilizarea instalației proprii este eligibilă la nivel SOURCE, cu revalidările produsului păstrate, nu autorizată de acest review. Apelul real rămâne NOT_ADMITTED/NOT_RUN; nu este PASS al aplicației, remediu al cauzei supervisor sau închidere T1/T2.

## Identitate verificată

Worktree: /home/kali/.hermes/cache/scratch/settings-supervisor-tcp-20261030
HEAD/base: 028781897a8bb4c4277be7d33a3a24eac8121004
Singurele WIP raportate de Git:
- cli/integration/installed_stop.py SHA256 e9ea1dc575388330ab75d6f0fcf30c93cbba8c8e8d017f48d83e9c0c1750254e
- cli/integration/test_installed_stop_lock_oracle.py SHA256 bc535aee64ea18ad6e1ce28831fe9c49ecd73d35ecf405881ba0f6987f53d1c6
FREEZE: /home/kali/.hermes/cache/scratch/settings-sol-team-b45fd55/installed-legal-prefix/FREEZE.json
SHA256 FREEZE: 1e60a9aa2ab85acc64c63a6f56da77c97a2ab18a9ca9b5d1d0f30b512611612f
SHA256 candidate.patch: fc4e3799c15cf2511becf88d19c5486287b0bbfe992bb9611488ebb74ba8a3a9

## Cerință → risc → decizie

1. Prefix legal, fără relaxarea produsului → fresh DEVELOPMENT refuzat sau pornire înainte de retragerea RELEASE → ACCEPTAT SOURCE. installed_stop.py:188–190 păstrează configul inițial port-only. :415–467 execută RELEASE Start, Stop public, răspuns STOPPED, jurnal phase STOPPED, readback de absență și family settled înainte de config/Start DEVELOPMENT. Controlul din test_installed_stop_lock_oracle.py:95–131 compilează guardul real start.py:1263–1270; trecerea acelui guard nu este prezentată drept READY autentic. Invaliditatea fresh DEV este demonstrată SOURCE; motivul exact al vechiului CLI2 pierdut nu este reconstruit retrospectiv.

2. Două etape, același owner și deadline → interval scurtat, etapă2 lansată tardiv sau cleanup vechi creditat noului Start → ACCEPTAT SOURCE. installed_stop.py:140–153, :191–202, :233–262 și :419–432 păstrează rezerva integrală 310+210+30 în deadline600, cu recheck după logarea durabilă și după schimbarea configului prin intrarea în command. Nu este promisă încadrarea ambelor cicluri la worst case; etapa2 poate refuza cu primul STOPPED deja verificat. cleanup devine True numai după primul Stop/readback/settlement (:456–467), apoi False înaintea următoarei lansări (:262). După fiecare Start se reîncarcă attempt/selection/snapshot/journal și se resetează runtime.deadline (:435–455); după Stop se setează deadline de readback. Finalizerul existent rămâne singura cale de retragere.

3. Excepții, rezultate și confidențialitate → fals STOPPED/PASS sau pierderea unui nou refuz → ACCEPTAT SOURCE. :230–298 numerotează logurile în state privat, persistă argv înainte de efect și returncode/stdout/stderr înainte de assert. write_record existent (:83–100 în lifecycle.py) folosește director privat, mkstemp, fsync și publicare exclusivă inițială; rezultatul înlocuiește numai logul propriu. Mediul explicit (:177–184) nu moștenește HOME/XDG/credentiale ale operatorului, iar argv este Start --no-open --json sau Stop --json. Timeout/excepție păstrează returncode:null/error, nu inventează rezultat complet. Rezultat necunoscut sau eșecul persistării post-lansare lasă driver_pending=True; finalizerul :1102–1200 nu certifică retragerea prin simpla absență fizică. Un refuz înainte de lansare restabilește pendingul anterior; primul cleanup verificat poate rămâne valid dacă etapa2 nu a început. Persistarea însăși poate eșua; nu afirm rezistență universală la crash/disc sau prezența unui rezultat final după timeout.

4. Reutilizare numai a instalației proprii → metadata-only adoption ori atingerea operatorului → ELIGIBIL SOURCE, admitere la părinte. Funcția creează state/control/config noi prin mkdtemp (:168–184), nu selectează vechiul s4-er07xzhw. ControlRuntime(data, prepare_until) este apelat efectiv înainte de primul command (:201–202), nu înlocuit cu un predicat din raport. Constructorul start_runtime.py:209–311 verifică manifest/receipt/profil/platformă/endpoint/daemon, identitatea imaginii/labels/proiect/tag și pinul PG. Start păstrează refuzul PREEXISTING_RESOURCES_REFUSED la start.py:1272–1276; apelul direct nu sare aceste verificări ale produsului. Source review nu certifică starea actuală a daemonului sau codul executat în viitoarea tentativă.

Inputul propus rămâne exact data_home /home/kali/.hermes/cache/scratch/omnis-bundle-xi8ua6is/data și CLI-ul privat din aceeași rădăcină, proiect omnis-local-ea23cc8205dd499a89a6eaf7ebcf72a9, imagine sha256:f33c4c2fe8072d9a8f66979d9114114b3a24bcd5522ebb751c64f902b9ed2151, manifest f09766be6239f6eed62c0e22aed0b5acd6ee2a3658f239e6e78636ff99260262. Egalitatea celor131 fișiere pregătite și censusul live gol sunt dovezile anterioare ale părintelui, nu verificări live noi ale mele. Nu este necesară reconstruirea/instalarea din nou pentru a executa aceste validări. Orice nepotrivire ori resursă reapărută trebuie să refuze, nu să fie adoptată.

## Dispoziții, dovezi și limite

Aprobarea SAFETY anterioară a lui028 este reutilizată exclusiv pe bytes neschimbate; nu am reauditat ACK sau buildul normal. Nu propun schimbarea guardului de produs, alte timeouturi, framework, wheel, imagine, backup ori opțiune publică. Nu există finding de retenție bazat pe supraviețuirea directoarelor/logurilor: IPC settlement/absența resurselor și ștergerea directoarelor sunt proprietăți diferite.

Verificări executate de reviewer: Git HEAD/status/diff stat și git diff --check, exit0; SHA256-uri identice cu mandatul; citirea patchului, callerului/finalizerului, validărilor de produs, testelor și logului final. final-checks.log leagă aceleași SHA-uri de 3 teste SOURCE PASS/0.280s și Ruff check/format/diff exit0. Aceste execuții sunt ale autorului, citite și reutilizate, nu rerulate de reviewer. Cele12 scenarii sunt doubles SOURCE plus guard AST, nu12 probe native. Nicio întrebare concretă rămasă nu a justificat alt harness sau rerulare.

Old2/2 + diagnostic1/1 + team-normal-attempt1/1 FAIL rămân consumate. Părintele deține orice nouă admitere distinctă, claim, captură a exitului și integrare. Nu au fost executate Docker/build/install/DB/network/Start/Stop/browser/provider/model/target/operator și nu au fost citite secrete sau fișiere protejate; fără editări de sursă, commit, push, fetch ori schimbări de skill. Singura scriere a reviewerului este acest raport scratch. Reticle NOT_APPLICABLE; Chisel BLOCKED_NO_GO.

Nu am verificat runtime-ul sau settlementul real al noii secvențe. Riscul rămas: etapa2 ori observația pot refuza legitim în600s; orice timeout/pending sau identitate schimbată rămâne FAIL/UNCERTAIN, nu permisiune de retry/adopție sau dovadă de remediere a operatorului.
