# R2 re-review focalizat — R2-F01 și continuarea B terminal

## Verdict: APPROVED_SCOPED_SOURCE — R2-F01 CLOSED_SCOPED_SOURCE

Nu am identificat un blocker rezidual concret în delta `db6ab2bc4ff04f71cb101ca4f815fb74ccae0bd7` → `e730e3f002c9675835b8690f856e7856e31f9373` pentru perechea delayedReload stale-A/active-B și continuarea B terminal fără reactivarea A. Închiderea propusă include ambele faze ale findingului original, nu numai apariția Cancel pentru B. Părintele deține adjudecarea/admiterea QA și integrarea; acest review nu este PASS de consumator real sau instalat.

**Findings blocante curente în scope: niciunul identificat.** Nu cer modificări de produs/test ori un harness nou.

## Identitate verificată independent

- Checkout: `/home/kali/.hermes/cache/scratch/settings-inline-feedback-20261029`; branch `feat/settings-inline-feedback-20261029`.
- Bază: `db6ab2bc4ff04f71cb101ca4f815fb74ccae0bd7`.
- HEAD: `e730e3f002c9675835b8690f856e7856e31f9373`.
- Tree: `1b458b1b56ddb03d14e78d0ebd98c55b8b5041cf`.
- Exact două căi, **+73/−4**: Page +9/−4; test +64/−0.
- `web/src/features/engagement/SettingsModelsPage.tsx`: blob `5d05eb66e205fa4b076ab0bde8e6c822eeca5654`; SHA256 `212360c6ef12e619d94716718c6a2cff3924051c612d6591b7c417d0b79390e2`.
- `web/src/app/SettingsWizard.test.tsx`: blob `7baea788b1a645ea68a8be5ee3f4065718c15a2f`; SHA256 `896a9fb52615b7381f4236ff2afce710948bf4b106b8ac6391724bff52af6e6d`.
- Diff binar generat din Git este byte-equal cu `astra-evidence/r2-fix.delta.diff`; SHA256 `bfc792b7f72b5c1c3a7af6027c8d16d1280bf35996fed0ec5a8a559fe4dc9160`. Manifestul CURRENT `astra-evidence/freeze.json` corespunde.
- Tracked/index curate la început și la verificarea finală. Numai cele patru symlinkuri untracked declarate; tip/ținte identice cu freeze, verificate exclusiv prin `lstat/readlink`, fără dereferențiere/adoptare/alterare.
- Wizard `a9ddccfa4867aef0f3352c2f6eab01a18acca769` și E2E `f9436bdb7d9fb6dd0ffad165806b561e7e9726ac` sunt neschimbate față de bază; aprobările lor rămân scoped, fără reauditare. Comparația extrasului original `SOURCE healthy direct Test` între bază și working tree este **identică**.
- Identitate build existent verificată, nu browser executat: manifest SHA256 `649e1593f6c330e62e56a8c513331106d09aeb8fb34237cdfb2c9b4435ebdf14`; `index-k_w5N4AQ.js` SHA256 `71b2d0c1070ff9f772bbf66fbee051eced9c8db20312236799620261b98e0a26`, ambele conforme freeze.

## Cerință → consumator → risc → decizie

Contract: `web/design/settings-final.md:25–39,46,54–56,88–92,136–142`. Cancel/readback trebuie să urmărească operația efectiv nesettled, nu istoricul; Reload nu autorizează Start sau reluarea secvenței. Consumator: App → `ProviderSettings.tsx:20–22` → `SettingsModelsPage`, query exact scope+operation și biblioteca existentă. Riscurile adjudecate sunt mascarea B de A stale și reselectarea A după terminalul B.

Am citit originalele `direct-terminal-r2-review.md`, `direct-terminal-r1-review.md`, CURRENT din `astra-result.md`, delta exactă, contractul și definițiile/usages afectate: hidratare/proiecție, `startTest`, `readTest`, `readCheck`, `connectEntries`, `stopRemaining`, controalele de rând/orphan, client/decoder/`exactCheck` și fixture-ul HTTP SOURCE. README CURRENT/harta rămân context de orientare, nu acceptare a candidatului.

| Obligație | Cod/control inspectat și decizie |
|---|---|
| A stale nu maschează B activă | Page `:111–123`: după bariere, reconcilierea terminalului A precede selecția; excluderea ID-ului deja selectat este **în predicatul `find`**. Nu se mai oprește la A înainte să examineze B. |
| B terminal nu readuce A RUNNING | Page `:113–116`: FINISHED deja observat este păstrat în cache-ul existent numai pentru aceeași operation ID și revizie de bibliotecă strict mai mică; apoi efectul revine înainte de schimbarea selecției. La rerender A este terminală, deci după B terminal nu mai există A activă de selectat. `observed` este dependență explicită. Nu este suficientă singură mutarea predicatului; continuarea RED demonstrează de ce. |
| Cancel/Read aparțin B, cu details închise | Test `:1039–1102`: două controale `false/true`, App StrictMode, HTTP fixture reală SOURCE. A exact ajunge FINISHED3 înainte de admiterea sintetică B RUNNING2 și release Reload. `:1081–1085` cer Cancel și Read vizibile, disclosure `aria-expanded=false`, GET exact B și zero mutații înainte de click. |
| Cancel numai B/rev2; nicio reactivare A | Test `:1062–1066,1086–1096`: Cancel verifică revizia, produce B FINISHED4/NOT_SENT/CANCELLED; query B și biblioteca trebuie să fie terminale, A Connected, niciun Cancel vizibil, niciun GET exact A suplimentar și exact o mutație — Cancel B cu `expected_state_revision:2`. GET A neașteptat este ținut numai ca să nu ascundă reactivarea; citirile se numără înainte de intercept, deci nu poate trece neobservat. Nu se injectează terminalul A/B direct în QueryClient. |
| Pending/sending/connecting și istoricul nu fură identitatea | Page `:98,111,289–295` păstrează barierele înaintea reconcilierii și selecției; `readTest :271–286` capturează ID-ul, Cancel folosește revizia observată, readbackul rămâne receive-only. Controalele `expands history… :976–1038` verifică pending/single/sequence/hydrated, read exact activ, istoric disabled și Cancel pe ID/rev2 activ. |
| Fresh/UNKNOWN/orphan/Stop/no-resend | Testele `:1103–1172` păstrează fresh recovery, FINISHED/UNKNOWN istoric, NEEDS_RECONCILIATION recuperabil și orphan receive-only. `:176–199` cere Cancel orphan la revizia7 citită, nu pe A istorică; `:201–230` păstrează Stop orphan la admitere ținută și zero reluări. `:852–930` verifică manual UNKNOWN și abandonarea nesentului inclusiv după remount. Page `:283–286,297–334,371,398–401,442–449,512–515` păstrează aceleași mecanisme. |

Noua scriere este exclusiv reconciliere QueryClient, nu DB/provider/autoritate. Guardul nu copiază peste alt ID sau revizie egală/mai nouă și nu inventează succes: păstrează rezultatul exact deja observat, inclusiv unul nereușit/UNKNOWN. `testUnknown`/eroarea mențin `operationPending`, deci noua reconciliere nu ocolește incertitudinea manuală. Query keys rămân scope+operation; clientul `shared/api/client.ts:83–102` și decoderul `modelTest.ts:49–63` validează identitatea exactă; `SettingsModels.ts:32–34` și Page `:518–527` păstrează Connected condiționat de identități/revizii curente și rezultat terminal reușit. Nu s-au schimbat CAS, generation pin, deadline, consent, dispatch sau Stop.

## Dovezi originale citite — fără rerulare

Am inspectat `.command.json`, stdout/stderr relevante și aserțiunile efective, nu numai numerele din raportul autorului. Prefixele următoare sunt în `astra-evidence/`:

- **`r2-parent-repro`**: payloadul original R2 verbatim, exit1, **1PASS/1FAIL/109skipped**. Markerul parsat independent: exact A FINISHED3/COMPLETED, library A RUNNING2, library B RUNNING2, exactBReads0, cancelButtons0, writes[]. Confirmă findingul inițial, nu lipsa fazei terminale A.
- **`r2-fix-red`**: perechea permanentă înainte de fix, exit1, **1PASS/1FAIL/109skipped**, aceleași stări discriminante.
- **`r2-fix-predicate-only`**: exit1, **1PASS/1FAIL**; B citită/anulată, dar GET A suplimentar (așteptat3, primit4). Nu este acceptat drept fix complet.
- **`r2-fix-continuation-red`**: exit1, **1PASS/1FAIL**; GET-ul neașteptat ținut expune exactA RUNNING/libraryA RUNNING/libraryB FINISHED, un Cancel vizibil și numai Cancel B/rev2 în mutații. Demonstrează continuarea aceleiași clase.
- **`r2-fix-green`**: selecția pereche + original healthy direct Test, exit0, **3PASS/108skipped**; dovadă intermediară, nu singura dovadă finală.
- **`r2-fix-regression-final`**, după ultima editare: `npm test -- src/app/SettingsWizard.test.tsx -t 'SOURCE R2 delayed library|SOURCE healthy direct Test|recovers the actual active check|expands history without replacing|remote UNKNOWN|manual read uncertainty|ends the unsent sequence|does not claim Connected|orphan RUNNING Cancel|SOURCE missing local projection|Save & connect waits|preserves receive-only recovery for an orphan|never resurrects an older stored green'` → exit0, **37PASS/74skipped**, stderr gol.
- **`r2-fix-lint`** exit1 este păstrat: dependența `updateCheck` lipsea. Fixul final folosește scrierea clientului existent și declară dependențele, fără ignore/cast/helper nou. **`r2-fix-lint-final`**, **`r2-fix-typecheck-final`**, **`r2-fix-build-final`**: `npm run lint/typecheck/build`, toate exit0 și stderr gol, după ultima editare; buildul include contract/design/tsc/Vite reale.

Executat de mine: status/base/head/tree/diff/numstat, `git diff --check`, comparație byte-exact diff/freeze, blobs/SHA256 ale celor două fișiere, comparație test direct original, identitate build, readback final tracked/index și lstat/readlink. Toate verificările finale au exit0. Nu am executat Vitest/npm sau alt consumer în acest re-review; GREEN/regresiile sunt execuțiile originale ale developerului, iar repro vechi aparține părintelui. Nu exista o suspiciune reziduală concretă care să justifice încă o probă SOURCE.

## Dispoziții și predare

1. **R2-F01/HIGH original:** **CLOSED_SCOPED_SOURCE** pe HEAD/tree/blobs de mai sus, inclusiv B terminal/no A resurrection. Remediul atinge cauza locală și controlul pereche păstrează fazele/oracolul original, întărit cu continuarea necesară.
2. **Predicate-only insuficient:** respins corect și conservat ca RED; reconcilierea terminalului deja observat completează aceeași remediere, fără extinderea autorității.
3. **Healthy PG istoric:** rămâne FAIL istoric, cauză **UNKNOWN/NEATRIBUITĂ**. Remediul SOURCE nu dovedește retrospectiv starea workerului/peerului din acea execuție. QA native/browser/API/PG pe e730e3f este **NOT_RUN aici**, nu moștenită din alt snapshot sau din Stop-read PASS.
4. **R1 anterior/Add/Wizard/E2E:** limitele aprobărilor neschimbate sunt păstrate; acest raport nu le extinde și nu substituie reviewul complementar curent sau decizia părintelui.

Original unic creat: acest raport scratch. Produs/teste/fixture/config/index/harta/skilluri nemodificate; zero commit, agent nou, servicii, PG/OCI/operator/provider/model/target effects. Main și cele două fișiere protejate nu au fost deschise/hashuite/staged; nu am citit env/cookies/DSN/secrete. Nu există cleanup propriu de efectuat. Reticle NOT_INTEGRATED/NOT_RUN; Chisel BLOCKED_NO_GO.

Am omis rerulările SOURCE/full, auditul Add/Wizard/E2E și QA nativă/PG/instalată; admiterea și integrarea rămân la părinte.
Risc: verdictul închide numai reproducerul și continuarea SOURCE revizuite, nu monotonicitatea universală a tuturor răspunsurilor întârziate; cauza PG istorică rămâne necunoscută.
