# S0 technical candidate — FROZEN, not reviewed/integrated

Technical base: 4bb942047b5a16c8d3f821a97fcac722dc7c4717. Parent documentary HEAD at final readback: 7ace4f034e81a8753bf294b6f2243352730e64d2. Relevant api/src, main pyproject/uv.lock and existing test_model_sender unchanged from technical base. No commit by child; no main manifest/env changes. Parent-owned isolated checkout was not used.

## Outcome and decision

Developer evidence supports **scoped SDK compatibility/admission candidate**: public openai-agents0.19.0 + OpenAI2.45.0 → actual HTTPX request → existing Omnis Transport/ResponseStream works with predetermined permitted composition. Independent review/QA and parent dependency admission remain required. No S1 runtime, persistence/SENT/Brain consumption, real model/provider/target, installed upgrade or global canonical claim.

Owned files and exact identities are in freeze.json:
- api/tests/test_agent_sdk_admission.py: SHA256 56a69cd1b8d913c3c48be9f24e86f11a3f5b5d6a4c4494069b59c5dcc4e0b134; Git blob 4afec8420c02798f8c2cc9fc228837ea700705f8.
- api/tests/fixtures/agent_sdk_admission.json: SHA256 48790f0b4cfc2d1a605ed9b2e914e75085d9f8cce2da07859df4c30e9edcf1a5; Git blob b2871cef114ffee9f3fe4ec199b1626c1cb1e7a6.

Name deliberately differs from future test_agent_loop.py: this tests SDK admission, not a product loop with durable consumption.

## Exact proof boundary

Public Agent.model is explicit OpenAIChatCompletionsModel, no RunConfig.model override; one FunctionTool, handoffs=[]/mcp_servers=[], session=None/context_management=None, store=False, tracing_disabled=True/trace_include_sensitive_data=False, client max_retries=0 and ModelRetrySettings(max_retries=0), empty organization/project, fixed admitted OpenRouter endpoint, trust_env=False/redirects off/identity encoding. No ModelSender.send ACK parser for this loop.

Initial/history/continued expected JSON projection is constructed **before** any request from fixed instructions, fixture input, tool schema and scripted result. The test request-local callback sets that independent Permit and calls the captured original Transport.handle_async_request; it never authorizes bytes read from the request. Only the lower httpcore pool is a bounded scripted sink. Scripted synthetic replies cause a real Runner tool invocation and second serialized request, not inference. The guard callback aborts any unexpected relay attempt. CURRENT is reset in finally and checked per request/failure. No live ref lookup/authorization or persistence is claimed from the synthetic reference metadata.

## Input composition and measured bytes

Fixture: exact literal source sections at Strix6b7ae2ebe4d47037a927aade23265ff4e4f27e84, source/selection digests in fixture; Apache-2.0 license locator retained. system_prompt.jinja lines4–10,27–30; root_agent.md lines13–37,72–85,94–99. No Jinja/runtime import. An explicit inert S0 preface is added. Complete selected instruction content reaches Agent.instructions; brief/role/non-goals/constraints/completion/context/ref, user and history reach actual model messages. This is a fixed sizing selection, **not the whole U02 catalog, published package or approved S1 prompting**. One selected context ref, not a claim that all32 maximum refs fit.

| Component / wire case | Bytes |
|---|---:|
| Agent.instructions, complete selected UTF-8 | 5953 |
| User + complete brief/context/ref UTF-8 | 906 |
| Prior assistant history UTF-8 | 87 |
| FunctionTool parameter schema compact JSON | 317 |
| Scripted tool result incl. metadata UTF-8 | 8192 |
| Actual initial full SDK body | 7917 |
| Actual second full SDK body incl. call/result | 16500 |
| Remaining room in this second-body exemplar | 16268 |
| Unicode-padded initial / exact second body | 24185 / 32768 (accepted) |
| Unicode-padded initial / overflow second body | 24186 / 32769 (second refused) |
| 8192-byte NUL result after JSON escaping, full second body | 57434 (refused) |
| Response bound / one-byte overflow | 131072 accepted / 131073 RESPONSE_LIMIT |

Extra-body model override and unadmitted field produce zero sink requests. Foreign-ref tool result, aggregate overflow and worst escaping allow only the unchanged initial request and deny the next. Failure503/network/cancellation do not retry. The test's10s whole-probe timeout is a test safety bound, not proof of the future300s operation owner deadline. S1 must re-admit complete actual prompt/tool/history/reference selection and diagnose/paginate optional retrieval;8KiB storage does not promise an arbitrary8KiB escaped value fits32KiB wire. No T1 cap increase is needed by this exemplar.

## IPC / HTTP sizes — measured existing schemas, not Needs-you

Actual KeySettingsControl/SaveSelection and CatalogControl/SearchCatalog → ControlRequest.model_dump_json → decode_control_frame; HTTPX request-body JSON encoder is measured without sending. No HTTP route/effect/authorization claim.
- ASCII quote/backslash selection: complete command2777, body2740, frame2882 bytes.
- Unicode/escaping catalog query: command696, body660, frame801 bytes.
- Valid command padded **with JSON whitespace** to3600 → complete envelope+newline3705 bytes, decoded successfully.
- Complete real-schema frame padded to4096 accepted;4097 rejected as `Oversized legacy frame`; extra envelope field rejected by actual schema.
- Padding demonstrates envelope capacity only, **not enforcement of a raw command3600 cap or a future Needs-you schema**. That schema/endpoint does not exist and must receive positive/negative tests in S1. Do not cite these exemplars as a universal S1 guarantee.

## Commands and results

Every invocation has `<name>.json` with exact argv/cwd/exit plus original stdout/stderr. Python3.13.15 in candidate project/.venv, clean env, -I -B, bwrap --unshare-net, explicit pytest_asyncio/no cache/plugin autoload disabled and API manifest pythonpath. No DB fixture was provisioned.
- red-baseline: exit1, current api/.venv importlib spec agents=None/assertion fails. Read-only baseline dependency RED; no fabricated product defect.
- complete-sdk-ipc: `python -I -B -m pytest -p pytest_asyncio.plugin -p no:cacheprovider -c api/pyproject.toml api/tests/test_agent_sdk_admission.py -q -s --tb=short`: **14PASS/exit0** on frozen files.
- t1-regression: same pytest flags + api/tests/test_model_sender.py: **40PASS/7FAIL exit1**. Failures all exact private-dir ancestor ownership rejection before relay start, not SDK behavior.
- t1-relay-regression: corrected private mount preflight + only `::test_tls_handshake_cut_allows_explicit_healthy_metadata_attempt` and `::test_sdk_tcp_readiness_outside_guard_and_current_write_veto`: **7PASS/exit0**. Together47 distinct existing tests pass, including15 original usage-coercion tests and all6 readiness/write-veto modes. Not claimed as one47/47 fresh run.
- quality-mypy-final: strict `mypy --config-file api/pyproject.toml --no-incremental` on new test and T1 model_sender: exit0,2files.
- quality-ruff-final/quality-format-final: pinned Ruff check --no-fix and format --check on same2files: exit0.
- git diff --check: exit0; source/main manifest unchanged; no Any/type-ignore/noqa/skip/xfail in new test.

## Preserved failures and recovery

1. First collection and first attempted producer both stopped on /dev/null permissions under full-root ro-bind, before tests. Same prerequisite defect; one repair adding private --dev /dev. Corrected collect1 and first real producer1PASS; all later SDK controls pass. The dependent test command should have stopped after collection failure; no provider/target effect occurred.
2. First T1 regressions: bwrap maps host root ancestors to65534; existing private_dir rejects them. Host paths are properly private. Read-only namespace stat identified the cause. Corrected namespace uses private tmpfs root and explicit readonly /usr, /etc/ssl, repository, candidate project and Python mounts; only own scratch writable. private_dir preflight passed before the7 affected tests; no guard bypass/change or host chmod.
3. Intermediate Ruff preflight found import ordering and imports reserved for not-yet-added IPC test. Fixed only owned test formatting; final strict/lint green.

Harness-only repair budget: SDK row1 repair followed by real producer progress; T1-regression row1 repair followed by real existing-consumer progress. No unresolved harness blocker and no retry loop.

Owned short scratch `/home/kali/.hermes/cache/scratch/s0-k6x` verified empty then removed; no background processes launched. Evidence/candidate retained. Parent closure licenses/5906 RECORD checks and2 PyPI+lock wheel identities remain at root package-closure.json/sdk-artifacts.json; not duplicated or reattributed to these tests.

Reusable tooling lesson for parent (no out-of-scope skill edit): bwrap --ro-bind / / can map host-owned ancestors to nobody under user namespaces; a private minimal root with explicit mounts preserves the application's ancestor-ownership checks. Use a private /dev and short owned TMPDIR; do not weaken product guards.

**Next owner decision:** independent review/QA on freeze.json identities, then explicit permission before main manifest/lock adoption. Full canonical and installed/operator effects remain parent-owned and separately admitted. Reticle NOT_APPLICABLE; Chisel BLOCKED_NO_GO.
