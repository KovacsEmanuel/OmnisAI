"""Focused SOURCE proof of the changed read-count oracle; no UDS/native/PG.

Reuse the existing setup prefix. Execute real prepare/reserve/mark_sent/settle
and ModelDispatch.read; stop reserve at create_budget and qualified callers at
read_configuration, after their real read. This is not complete protocol QA.
"""
import ast
import asyncio
import json
import sys
import tempfile
from pathlib import Path
from unittest.mock import AsyncMock
from uuid import uuid4

REPO = Path('/home/kali/.hermes/cache/scratch/omnis-s1-20261104')
blocked = []


def guard(event, args):
    if event in {'socket.connect', 'socket.bind', 'socket.getaddrinfo',
                 'subprocess.Popen', 'os.system', 'os.fork', 'os.posix_spawn', 'os.exec'}:
        blocked.append(event)
        raise AssertionError('SOURCE effect denied: ' + event)


sys.addaudithook(guard)
sys.path[:0] = [str(REPO / 'api/src'), str(REPO / 'api/tests')]
import pytest
import test_model_admission as fixtures
from omnis.modules.instance.schemas import NativeTaskCommand
from omnis.modules.runs import model_protocol
from omnis.modules.runs.model_dispatch import ModelDispatch
from omnis.modules.settings import candidate_store as records
from omnis.modules.settings.catalog_models import CatalogError
from omnis.modules.tasks import managed_store
from omnis.policy import budgets
from omnis.supervisor.runtime_client import FrozenPreflight
from test_model_admission_pg import ProtocolTiming
from test_ready_model_configuration import configuration

source = ast.parse(Path(fixtures.__file__).read_text())
setup = next(n for n in source.body if isinstance(n, ast.AsyncFunctionDef)
             and n.name == 'test_qualified_projection_reaches_cold_admission_without_model_reservation')
stop = next(i for i, n in enumerate(setup.body) if isinstance(n, ast.If)
            and ast.unparse(n.test) == 'catalog_boundary is not None')
setup.body = setup.body[:stop] + [ast.Return(value=ast.Call(
    func=ast.Name(id='locals', ctx=ast.Load()), args=[], keywords=[]))]
setup.decorator_list = []
setup.name = 'source_setup'
namespace = dict(vars(fixtures))
exec(compile(ast.fix_missing_locations(ast.Module(body=[setup], type_ignores=[])),
             str(fixtures.__file__), 'exec'), namespace)
timing_test = next(n for n in source.body if isinstance(n, ast.AsyncFunctionDef)
                   and n.name == 'test_protocol_phase_timing_existing_source_consumer')
old_assertion = next(n for n in timing_test.body if isinstance(n, ast.Assert)
                     and 'reads' in ast.unparse(n) and "'sender'" in ast.unparse(n))


class AfterQualifiedRead(Exception):
    pass


async def main(root):
    with pytest.MonkeyPatch.context() as mp:
        state = await namespace['source_setup'](root, mp)
        conn, consumer = state['connection'], state['consumer']
        owner, run, binding = state['owner'], state['run'], state['binding']
        prepared, graph = state['prepared'], state['graph']
        command = NativeTaskCommand.model_validate({
            **fixtures.preflight_command(), 'owner_id': owner,
            'manifest_ref': records.reference(state['manifest']),
            'action': 'model_protocol_prepare', 'protocol_id': str(uuid4()),
            'provider_config_ref': records.reference(records.envelope('provider-config', {})),
            'protocol_caps': {'calls': 1, 'output_tokens': 64, 'wall_seconds': 3},
        })
        descriptor = records.envelope('model-dispatch-owner', {
            'version': 1, 'provenance': model_protocol.PROVENANCE,
            'owner_id': owner, 'run_id': run, 'manifest_ref': command.manifest_ref,
            'binding_ref': records.reference(binding), 'authority': binding['payload']['authority'],
            'runtime_boot': binding['payload']['runtime_boot'], 'purpose': 'PREPARE',
            'provider_config_ref': command.provider_config_ref,
            'execution_selection_ref': records.reference(state['sources'][0].selection),
            'prepared': prepared, 'requested_caps': command.protocol_caps,
            'admitted_caps': command.protocol_caps, 'request_id': str(uuid4()),
            'body_digest': 'a' * 64, 'frame_digest': 'b' * 64, 'body': '{}',
            'deadline': '2030-01-01T00:00:00+00:00', 'deadline_ns': 1,
        })
        refs = {'descriptor_ref': records.reference(descriptor),
                'dispatch_ref': records.reference(records.envelope('model-dispatch', {}))}
        mp.setattr(managed_store, 'owned', AsyncMock(return_value=(run, descriptor)))
        budget_sink = AsyncMock(side_effect=AfterQualifiedRead)
        config_sink = AsyncMock(side_effect=AfterQualifiedRead)
        mp.setattr(budgets, 'create_budget', budget_sink)
        mp.setattr(consumer, 'read_configuration', config_sink)
        for module, name in ((managed_store, 'put'), (managed_store, 'command_complete'),
                             (budgets, 'reserve'), (budgets, 'mark_sent'), (budgets, 'settle')):
            mp.setattr(module, name, AsyncMock(side_effect=AssertionError('write denied')))
        frozen = FrozenPreflight(str(uuid4()), binding['payload']['runtime_boot'],
                                 0, 1, 1, 3, b'{}', b'{}')
        timing = ProtocolTiming()
        timing.handlers[asyncio.current_task()] = 'sender'
        mp.setattr(ModelDispatch, 'read', timing.delegate('dispatch.read', ModelDispatch.read))
        before = fixtures.canonical(graph)
        phases = []
        actual = await consumer.prepare(conn, owner, records.reference(state['manifest']),
                                        records.reference(binding), state['decision'])
        assert fixtures.canonical(actual) == fixtures.canonical(prepared)
        phases.append({'phase': 'prepare', 'reads': len(timing.snapshot())})
        for label in ('reserve', 'mark_sent', 'settle'):
            with pytest.raises(AfterQualifiedRead):
                if label == 'reserve':
                    await model_protocol.reserve(conn, consumer, command, prepared,
                                                 configuration(), frozen)
                elif label == 'mark_sent':
                    await model_protocol.mark_sent(conn, consumer, command, refs, frozen)
                else:
                    await model_protocol.settle(conn, consumer, command, refs, {})
            phases.append({'phase': label, 'reads': len(timing.snapshot())})
        reads = timing.snapshot()
        assert len(reads) == 4 and all(row['outcome'] == 'RETURNED' for row in reads)
        with pytest.raises(AssertionError):
            exec(compile(ast.Module(body=[old_assertion], type_ignores=[]),
                         str(fixtures.__file__), 'exec'), {'reads': reads})
        assert fixtures.canonical(graph) == before
        # Independently exercise the new canonical equality gate before budget creation.
        changed = json.loads(fixtures.canonical(prepared))
        changed['payload']['policy_digest'] = '0' * 64
        before_sink = budget_sink.await_count
        with pytest.raises(CatalogError, match='^MODEL_PROTOCOL_REJECTED$'):
            await model_protocol.reserve(conn, consumer, command, changed, configuration(), frozen)
        assert budget_sink.await_count == before_sink
        assert fixtures.canonical(graph) == before
        return {
            'snapshot': 'e3c148daeab44abb3b06f4c61829ab35731dec0d',
            'phases': phases,
            'original_assertion': ast.unparse(old_assertion),
            'original_assertion_result': 'AssertionError',
            'actual_reader_calls': len(reads), 'expected_by_existing_test': 3,
            'reserve_exact_prepared': 'passed equality and reached blocked create_budget sink',
            'reserve_changed_prepared': 'MODEL_PROTOCOL_REJECTED before create_budget',
            'retained_graph_unchanged': True,
            'limit': 'Real sequential caller/read invocations with existing SOURCE graph/material doubles; sentinel stops before ledger/effects. Does not run original UDS timing test or prove full replay/settlement.'
        }


with tempfile.TemporaryDirectory(prefix='u02-r1-r3-timing-',
                                 dir='/home/kali/.hermes/cache/scratch') as temp:
    result = asyncio.run(main(Path(temp)))
assert not blocked
result['blocked_external_effect_attempts'] = blocked
result['owned_temp_absent'] = not Path(temp).exists()
assert result['owned_temp_absent']
print(json.dumps(result, indent=2))
