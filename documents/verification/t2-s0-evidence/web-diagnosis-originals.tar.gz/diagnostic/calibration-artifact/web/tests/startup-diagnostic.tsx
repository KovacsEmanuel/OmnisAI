// Scratch-only SOURCE diagnostic; never part of the product.
import { Profiler, type ReactNode } from 'react';
import { Query, QueryCache, CancelledError, notifyManager, defaultScheduler } from '@tanstack/react-query';
import { vi } from 'vitest';
import { api } from '../src/shared/api/client';

type Fields = Record<string, string | number | boolean | undefined>;
type Event = Fields & { t: number; kind: string };
let current: { mark: (kind: string, fields?: Fields) => void } | undefined;
export function phase() {
  const text = document.body.textContent ?? '';
  return { bootstrap: text.includes('Checking local session…'), dashboardLoading: text.includes('Loading dashboard…'), bindingLoading: text.includes('Loading current settings…'), configured: !!document.querySelector('[aria-label="Configured models"]') };
}
function label(query: Query) {
  const [first, second] = query.queryKey;
  return first === 'session' ? 'session' : first === 'private' && second === 'dashboard' ? 'dashboard' : first === 'private' && second === 'settings-model-library' ? 'model-library' : 'other';
}
export function diagnosticApp(app: ReactNode) {
  const owner = current;
  return owner ? <Profiler id="startup" onRender={(_id, commitPhase) => owner.mark('react.commit', { commitPhase, ...phase() })}>{app}</Profiler> : app;
}
export function begin(caseLabel: string, holdNotify = false) {
  const started = performance.now(), events: Event[] = [], held: (() => void)[] = [];
  let active = true, sequence = 0, dropped = 0;
  const mark = (kind: string, fields: Fields = {}) => {
    if (!active) return;
    if (events.length >= 250) { dropped++; return; }
    events.push({ t: Number((performance.now() - started).toFixed(3)), kind, ...fields });
  };
  function observe<T>(promise: Promise<T>, boundary: string, fields: Fields = {}) {
    mark(boundary + '.enter', fields);
    void promise.then(() => mark(boundary + '.resolved', fields), error => mark(boundary + '.rejected', {
      ...fields, cancelled: error instanceof CancelledError,
      silent: error instanceof CancelledError ? error.silent === true : false,
      revert: error instanceof CancelledError ? error.revert === true : false,
    }));
    return promise;
  }
  const queryFetch = Query.prototype.fetch;
  const fetchSpy = vi.spyOn(Query.prototype, 'fetch').mockImplementation(function (this: Query, ...args) {
    return observe(queryFetch.apply(this, args), 'query.fetch', { query: label(this) });
  });
  const cacheNotify = QueryCache.prototype.notify;
  const cacheSpy = vi.spyOn(QueryCache.prototype, 'notify').mockImplementation(function (this: QueryCache, event) {
    if (label(event.query) !== 'other') mark('query.cache', { query: label(event.query), event: event.type, status: event.query.state.status, fetchStatus: event.query.state.fetchStatus });
    return cacheNotify.call(this, event);
  });
  const session = api.session, dashboard = api.dashboard;
  const sessionSpy = vi.spyOn(api, 'session').mockImplementation(signal => {
    signal?.addEventListener('abort', () => mark('api.session.abort'), { once: true });
    return observe(session.call(api, signal), 'api.session');
  });
  const dashboardSpy = vi.spyOn(api, 'dashboard').mockImplementation((after, signal) => {
    signal?.addEventListener('abort', () => mark('api.dashboard.abort'), { once: true });
    return observe(dashboard.call(api, after, signal), 'api.dashboard');
  });
  const digest = crypto.subtle.digest;
  const digestSpy = vi.spyOn(crypto.subtle, 'digest').mockImplementation((algorithm, data) => observe(digest.call(crypto.subtle, algorithm, data), 'digest'));
  notifyManager.setScheduler(callback => {
    const id = ++sequence;
    mark('notify.enqueue', { id });
    const run = () => { mark('notify.run', { id }); callback(); };
    if (holdNotify) held.push(run); else defaultScheduler(run);
  });
  const release = () => {
    holdNotify = false;
    mark('control.notify.release', { count: held.length });
    held.splice(0).forEach(callback => defaultScheduler(callback));
  };
  const result = { events, mark, release, finish() {
    mark('before.cleanup', phase());
    console.log('STARTUP_DIAGNOSTIC ' + JSON.stringify({ case: caseLabel, events, dropped }));
    active = false;
    if (held.length) release();
    notifyManager.setScheduler(defaultScheduler);
    for (const spy of [fetchSpy, cacheSpy, sessionSpy, dashboardSpy, digestSpy]) spy.mockRestore();
    current = undefined;
  } };
  current = result;
  mark('begin', { synthetic: caseLabel.startsWith('SOURCE') });
  return result;
}
