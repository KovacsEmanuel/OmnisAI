# Rezultat developer — T1 Models și confirmarea Assignments

## CURRENT — Assignments confirmation reparată SOURCE/native, candidat a1857dd

HEAD `a1857ddd6ac3b3bcfd0a07d4402d0df6abde46a0`, tree `69032e28c99379eba9023c6af600e679aeeeae2a`. Candidat comis, neintegrat/neinstalat; reviewul noii delte și QA healthy reală rămân la părinte. Fixul schimbă un predicat de vizibilitate, plus regresia nativă în probe-ul existent. Nu schimbă CSS/layout, fluxul Save, expiry, focus sau oracolul API/PG.

### Progresul admis și diagnosticul discriminant

- Am citit cele două originale `r2-fix-r1-rereview.md`, `r2-fix-r2-rereview.md`: APPROVED_SCOPED, R2-F01 CLOSED_SCOPED_SOURCE inclusiv B terminal/no A resurrection. Fixurile Add/hidratare nu sunt redeschise sau modificate.
- Noile originale `models-real-evidence/healthy-e730e3f-{browser-fail-original.txt,gate-fail-original.txt,result-original.json}` confirmă FAIL-ul ulterior la `settings-models.mjs:273`: Settings notification absentă din arborele accesibil după release receipt, exit2/1FAIL77.35s/family_drained=true. Părintele comunică prefixul ambelor teste automate Connected și exact/current/latest/cap64 trecut. Keys/census/restart finale rămân NOT_REACHED. Nu am accesat/adoptat DB-ul păstrat; cleanupul este confirmarea părintelui.
- Captura reală identificată prin inventarul fișierelor, `pytest-of-kali/pytest-24/test_api_pg_sdk_protocol_and_r0/settings-save-local-pending.png`, a fost inspectată vizual:320×1000, formular lung, Output controls deschis și Save aproape de marginea inferioară. Este PRE-receipt, nu dovada stării toastului după Save.
- Contractul `settings-final.md:68–75,125–128` cere confirmare scurtă după receipt/readback, fără ocluzie/focus furat și fără panou normal sus. Cerința E2E de feedback utilizabil nu a fost înlocuită cu o aserțiune includeHidden sau cu scroll spre un loc gol.

### Cauza reprodusă și schimbarea minimă

Reproducerul folosește exact buildul e730, App/StrictMode original,19 modele (două Connected), selectors/Output controls/cap0 refuzat→64 și Save cu Enter/focus, apoi ține numai GET-ul receiptului exact. Fără API/PG/provider; HTTP exclusiv sintetic allowlisted în browser nativ, prin structura existentă `provider-settings-focus.mjs`.

La320px: PUT=1, receipt GET=1, settings GET=2, revizia salvată2, caps/roluri identice cu payloadul cerut, Save neocupat și focalizat. În DOM există „Assignments saved.”, dar visibility=hidden și top=-2087.109375; rolul accesibil are count0. Deci în această reproducere nu lipsește Save/readbackul și nu expiră textul: plasarea îl ascunde.390/1280/1440 treceau înainte de fix.

Geometria păstrată arată că butonul Replace key din Connection options ÎNCHIS are dreptunghi nenul, deși `checkVisibility` este false. Walkerul îl considera obstacol și depășea viewportul; fără acel obstacol nevizibil, există un loc liber la top159.875/bottom209.875. Este comportament nativ al disclosure-ului, nu necesitatea de a elimina protecția textelor vizibile.

- `web/src/features/engagement/SettingsModelsPage.tsx:142–143`: filtrul comun ignoră numai elementele raportate nevizibile de API-ul nativ `checkVisibility({visibilityProperty:true})`. Dacă metoda nu există, comportamentul conservator anterior rămâne. Nu schimbă targets, algoritmul de deplasare, timerul5s, pauza pe focus/absența spațiului, receipt/CAS sau eroarea persistentă.
- `web/tests/e2e/provider-settings-focus.mjs:17–116`: test nou bounded în probe-ul existent, nu framework nou. Patru viewporturi320/390/1280/1440; readback/rol/cap/focus, confirmare accesibilă în viewport și fără ocluzii. Control negativ: deschide Connection options și cere ca Replace key/Disable să rămână neacoperite; filtrează invizibilitatea, nu ignoră toate obstacolele. Zero model Start/Refresh, zero cereri neașteptate/page errors.
- `web/tests/e2e/settings-models.mjs`, CSS, Wizard și testele R2/direct-Test rămân byte-identice cu e730. Nu am schimbat oracle-ul real pentru verde.

### Verificări reale și capturi

Director `astra-evidence/assignments-*`: argv/cwd/returncode/timestamps UTC start/end/duration și stdout/stderr originale, distincte de toate dovezile vechi. Uneltele pinned rămân Node24.21.0/npm11.19.0, Playwright1.63.0/Chromium1243; cwd web. Preflight a verificat sintaxa și egalitatea hashurilor buildului RED cu freeze-e730 înainte de browser.

- `assignments-native-red`, 10:30:52.753–10:31:03.722Z: `node --test --test-name-pattern='Assignments SOURCE' tests/e2e/provider-settings-focus.mjs`, exit1. Control320 FAIL,390/1280/1440 PASS; sumar runner3PASS/2FAIL include failure-ul părintelui testului, nu două viewporturi defecte. `assignments-native-red-images` păstrează capturile pending/confirmed.
- `assignments-unit`, 10:34:22.824–10:34:28.185Z: `npm test -- src/app/SettingsModels.test.tsx src/app/ProviderKeySettings.test.tsx -t 'notification|passive feedback|assignment .*text clear|quiet reload|expires confirmations|actionable save recovery|completed check Connected during an assignment|assignment drafts quiet|assignment save preserves|single-model assignment needs' --cache=false --configLoader=runner` → exit0,22PASS/50skipped. Comenzi cache/configLoader verificate în help; nu schimbă manifestul sau profilul. Acoperă expiry numai pe timp vizibil, focus pause, no-safe-space, feedback local și receipt/readback/UNKNOWN fără resend.
- `assignments-lint` 10:34:28.186–10:34:29.411Z, `npm run lint` → exit0; `assignments-typecheck` 10:34:29.415–10:34:36.698Z, `npm run typecheck` → exit0; `assignments-build` 10:34:36.702–10:34:45.806Z, `npm run build` → exit0, contract/design/tsc/Vite reale.
- `assignments-native-green`, 10:34:56.057–10:35:01.695Z: aceeași comandă nativă, exit0,4 viewporturi PASS (sumar5PASS include părintele). La320 notificarea este vizibilă/accesibilă, top159.875; focus Save și scrollY2416 neschimbate. După deschiderea Connection options se repoziționează la top275.875, fără acoperirea butoanelor devenite vizibile. Toate celelalte viewporturi rămân pozitive.
- Capturile curente confirmed320/390/1280/1440 și expanded320 au fost inspectate vizual: confirmarea este lizibilă, fără ocluzie de labels/hints/identități/controale. Poate suprapune conturul/fundalul panoului, nu conținutul protejat. Nu este aprobare estetică.
- Limită explicită: la390, Save și inelul său ating/tăie marginea de jos. Bounding box Save bottom1000.390625 și scrollY1906 sunt IDENTICE în RED/GREEN; focusul DOM rămâne pe Save. Această tăiere preexistentă nu este introdusă de fix, nu a fost reparată și nu revendic certificare generală de focus/viewport.

### Freeze și pasul următor

- Commit unic `a1857ddd6ac3b3bcfd0a07d4402d0df6abde46a0`, numai Page + probe nativ (+102/−1). Diff verificat, stage numai aceste căi; tracked/index curate și cele4symlinkuri preexistente păstrate.
- CURRENT `astra-evidence/freeze.json`; vechile `freeze-e730e3f.json` și `candidate-e730e3f.diff` au fost conservate byte-exact înaintea actualizării. Toate freeze-urile/diff-urile și rezultatele mai vechi rămân.
- Delta e730→a185: `astra-evidence/assignments.delta.diff`, SHA256 `cb653acb3952b4f64e3571761099a99ee44efb4f254c23bc64f7eb5fb8385186`; cumulativ b1→a185 `candidate.diff`, SHA256 `54a08e8662dade4581393bd85451e07e2e7da0a6aa1d12e16ea905893888cbfe`.
- Blob Page `c83c2f17002ed76c9fe890ef4ebc105eb70aafd2`; probe `06566bd1fa36e587e3d6168ea6aef5c40429d98d`. Freeze-ul include celelalte blobs neschimbate și SHA256 pentru12capturi native curente.
- Build manifest SHA256 `91debd6215494bb17540014bfe16c098c88aaa7cfbd6400b6b63f57e8cb9befc`; `index-IMLILQux.js` SHA256 `9ba1b80ae2ca513e283903e6dff69f7196ce938f3258326a4295d9c73b580c50`.

Părintele face review scoped al predicatului și al probei, apoi decide următoarea invocare healthy `test-settings-remove-ui-pg` pe acest freeze, cu oracolul neschimbat: confirmare accesibilă/focus, receipt/current exact, roluri/caps și ulterior keys/census/restart. Nu este rerun autorizat aici. Cauza clasei SOURCE este demonstrată; în FAIL-ul PG istoric lipsesc DOM/style/readback post-release, deci atribuirea retrospectivă rămâne limitată. Nu redeschid R2 sau diagnosticul supervisor și nu resetez contoare.

Am omis PG/API/OCI/operator/canonical, integrarea/instalarea/push și suitele neafectate; Reticle NOT_INTEGRATED, Chisel BLOCKED_NO_GO.
Risc rămas: QA healthy reală și acceptarea estetică nu sunt livrate de SOURCE; tăierea preexistentă a focusului la390 rămâne explicită.

## Istoric păstrat — R2-F01 reparat SOURCE, candidat e730e3f

Dispoziție developer: FIXED_SOURCE_AWAITING_COMPLEMENTARY_REVIEW. R2-F01/HIGH rămâne finding de închis de părinte prin re-review, nu este anulat de R1 APPROVED_SCOPED. Am citit ambele originale și `r2-parent-repro.*`; controlul permanent reproduce findingul înainte de fix. Nu am lansat real QA, integrare sau instalare.

HEAD `e730e3f002c9675835b8690f856e7856e31f9373`, tree `1b458b1b56ddb03d14e78d0ebd98c55b8b5041cf`. Commit coerent fix+regresie peste `db6ab2bc4ff04f71cb101ca4f815fb74ccae0bd7`; numai Page și SettingsWizard.test schimbate (+73/−4). Wizard/Add și E2E sunt byte-identice cu freeze-ul acceptat anterior.

### Remediu complet al aceleiași clase

- `SettingsModelsPage.tsx:109–123`: excluderea operației deja selectate este în predicatul `find`, nu după primul rezultat. O proiecție stale A nu mai maschează B activă.
- Mutarea filtrului singură NU era completă: după Cancel B, biblioteca încă avea A RUNNING2 și hidratarea o selecta din nou. Mai întâi am observat un GET A suplimentar; controlul întărit ține numai acel GET neașteptat, ca rereadul să nu mascheze regresia. Originalul arată exactA RUNNING/libraryA RUNNING/libraryB FINISHED, un Cancel vizibil și singura mutație Cancel B/rev2. Este un al doilea RED al continuării aceleiași perechi, nu alt audit sau o relaxare de test.
- Înainte de schimbarea selecției, aceeași hidratare reține în cache-ul existent de bibliotecă citirea FINISHED deja observată, numai când operation_id coincide și revizia din bibliotecă este strict mai mică. Nu rescrie identități diferite ori revizii egale/mai noi și nu inventează rezultat terminal. Nu adaugă owner/cache/loop/timer.
- Barierele operationPending/sending/connecting rămân înaintea reconcilierii; protecția direct-Test contra reseedului aceleiași operații rămâne. Pollingul, receipt/CAS, current/identity, Stop, UNKNOWN și neresendul nu au fost slăbite.
- `SettingsWizard.test.tsx:1039–1102`: aceeași pereche `staleSelected=false/true` prin App StrictMode și HTTP fixture existentă. Reload capturează A RUNNING2, exactA ajunge FINISHED3, B devine RUNNING2, apoi sosește Reload. B trebuie citită exact și să ofere Cancel/Read cu details închise. Înainte de click: writes[]. Cancel vizează numai B cu revizia2 observată; B ajunge FINISHED4/CANCELLED, A rămâne terminală/Connected, fără reselecție/GET A sau Cancel A. Niciun Start ori altă mutație. Regresia originală healthy direct-Test nu a fost modificată.

### RED → GREEN și originale

Toate originalele noi sunt `astra-evidence/r2-fix-*`; `.command.json` păstrează exact argv/cwd/returncode și timestamps UTC start/end/duration pentru corelarea hostload cu Sol. Cwd web; Node24.21.0/npm11.19.0 și PATH pinned neschimbate. Nu am folosit slotul sau checkoutul Sol.

- `r2-fix-red`: `npm test -- src/app/SettingsWizard.test.tsx -t 'SOURCE R2 delayed library'`, 10:09:50.207–10:09:55.085Z, exit1,1FAIL/1PASS109skipped. A exact FINISHED, libraryA/B RUNNING, exactBReads0, cancelButtons0, writes[].
- `r2-fix-predicate-only`: aceeași comandă, 10:10:15.046–10:10:19.482Z, exit1,1FAIL/1PASS; B recuperată/anulată corect, dar GET A suplimentar după terminalul B.
- `r2-fix-continuation-red`: aceeași comandă, 10:11:31.337–10:11:36.380Z, exit1,1FAIL/1PASS; ținerea GET-ului neașteptat demonstrează A reactivată RUNNING/Cancel. Limitele și aserțiunile rămân; nu este sleep ori polling workaround.
- `r2-fix-green`: selecția `SOURCE R2 delayed library|SOURCE healthy direct Test`, 10:12:13.950–10:12:18.809Z, exit0,3PASS108skipped. LSP a semnalat apoi optionalitatea state_revision; guardul nullish a fost corectat, fără cast/ignore.
- `r2-fix-regression`: exit0,37PASS; primul `r2-fix-lint` a refuzat dependența instabilă updateCheck, exit1. Am folosit scrierea QueryClient existentă direct în efect, fără abstracție/callback nou. Typecheck/build din acea încercare au exit0; toate originalele sunt păstrate, dar freeze-ul final folosește verificările de mai jos.
- `r2-fix-regression-final`: 10:14:37.036–10:14:59.191Z, exit0,37PASS74skipped după ultima editare. Comanda exactă: `npm test -- src/app/SettingsWizard.test.tsx -t 'SOURCE R2 delayed library|SOURCE healthy direct Test|recovers the actual active check|expands history without replacing|remote UNKNOWN|manual read uncertainty|ends the unsent sequence|does not claim Connected|orphan RUNNING Cancel|SOURCE missing local projection|Save & connect waits|preserves receive-only recovery for an orphan|never resurrects an older stored green'`.
- `r2-fix-lint-final`: `npm run lint`, 10:14:59.192–10:15:00.255Z, exit0.
- `r2-fix-typecheck-final`: `npm run typecheck`, 10:15:00.255–10:15:06.829Z, exit0.
- `r2-fix-build-final`: `npm run build`, 10:15:06.829–10:15:15.471Z, exit0, contract/design/tsc/Vite reale. Toate stderr-urile finale goale. `git diff --check` exit0.

### FREEZE curent

- Manifestul acestui checkpoint istoric: `astra-evidence/freeze-e730e3f.json`. Predecesorul a fost păstrat byte-exact înainte de înlocuire: `freeze-db6ab2b.json`, `candidate-db6ab2b.diff`. Freeze/diff ea78ee2 și `direct-terminal.delta.diff` rămân de asemenea păstrate.
- Delta db6ab2b→e730e3f: `astra-evidence/r2-fix.delta.diff`, SHA256 `bfc792b7f72b5c1c3a7af6027c8d16d1280bf35996fed0ec5a8a559fe4dc9160`.
- Diff cumulativ b1d276e→e730e3f: `astra-evidence/candidate-e730e3f.diff`, SHA256 `d5d34b5c9abef4d6fc24da569443ce8b77191fa05e10392867c13e944f25b1c7`.
- Blob Page `5d05eb66e205fa4b076ab0bde8e6c822eeca5654`; test `7baea788b1a645ea68a8be5ee3f4065718c15a2f`.
- Wizard neschimbat `a9ddccfa4867aef0f3352c2f6eab01a18acca769`; E2E neschimbat `f9436bdb7d9fb6dd0ffad165806b561e7e9726ac`.
- Build manifest SHA256 `649e1593f6c330e62e56a8c513331106d09aeb8fb34237cdfb2c9b4435ebdf14`; `index-k_w5N4AQ.js` SHA256 `71b2d0c1070ff9f772bbf66fbee051eced9c8db20312236799620261b98e0a26`.
- Tracked/index curate; numai cele patru symlinkuri originale, tip/ținte confirmate neschimbate. Fără main/source/operator/protected-file access sau schimbări în API/backend/E2E/config/dependețe.

Decizia următoare: re-review complementar focalizat pe delta R2 și continuarea B terminal/A păstrată; numai după clearance și Sol drain părintele admite consumatorul real healthy existent (`test-settings-remove-ui-pg`, comanda reținută mai jos). R1 vechi nu închide R2. PASS-ul parent stop-read și dovezile108/base172 rămân scoped pe bytes/cazuri neschimbate, nu certificate pentru noua hidratare. Nu s-au resetat contoare sau șters FAIL-uri.

Am omis PG/API/OCI/operator/canonical, native-browser, integrarea/instalarea și rerulările full neafectate; acestea rămân separate de acest fix SOURCE.
Risc: R2 este reparat în reproducer și regresiile afectate, dar clearance-ul independent și QA healthy pe noul freeze sunt încă necesare; cauza PG istorică rămâne neatribuită.

## Istoric păstrat — follow-up healthy Test, candidat db6ab2b

Defectul de hidratare al operației selectate este reprodus și reparat SOURCE. Commit candidat `db6ab2bc4ff04f71cb101ca4f815fb74ccae0bd7`, tree `74ae52e6139714df1472aca01b79395cc61a9826`. Delta nouă: numai `web/src/features/engagement/SettingsModelsPage.tsx` și `web/src/app/SettingsWizard.test.tsx`. Review focalizat al noii delte și QA reală healthy: NOT_RUN de developer, aparțin părintelui. Nu este integrare/instalare sau acceptare T1/T2.

### Dovezi primite și păstrate

- Reviewul independent `models-independent-review.md` a fost citit: APPROVED_SCOPED pe delta Add/E2E a lui ea78ee2.
- Conform rezultatului comunicat de părinte, `test-settings-stop-read-ui-pg` pe ea78ee2 a trecut exit0/1PASS13.16s: operația `9ecbc9c0-ab23-4224-bfc9-f5266709d568`, un Start202, Stop pentru al doilea nesent, exact/latest FINISHEDrev3/COMPLETED/currenttrue, al doilea latest404/NOT_FOUND, fără Cancel. Cleanupul fixture-ului `db-bcde200a3e7f4e52` este confirmat de părinte. Nu am rerulat această probă.
- Originalele `models-real-evidence/healthy-ea78ee2-browser-fail-original.txt`, `healthy-ea78ee2-gate-fail-original.txt`, `healthy-ea78ee2-result-original.json` au fost citite: outer2, 1FAIL63.66s; prima Save&connect ajunge Connected, al doilea Test direct rămâne Connecting/Cancel/Read la `settings-models.mjs:238`, bound15000ms neschimbat. Receiptul spune family_drained=true. Nu am adoptat/redeschis DB-ul `db-6a083d1420a04c1e`; absențele resurselor sunt confirmarea părintelui, nu o nouă inspecție a mea.
- Logul istoric healthy nu păstrează operația exactă/terminalul/workerul celui de-al doilea Test. Cauza acelei execuții nu este atribuită retrospectiv; remediul de mai jos repară clasa demonstrată în App.

### Cauză reprodusă, nu schimbare de oracle

Cerință → consumer → risc → decizie: Test direct sănătos trebuie să proiecteze citirea exactă terminală fără Read manual, iar istoricul nu poate reactiva o operație terminată. Consumerul este App → SettingsModelsPage, query `['private','settings-entry-test',scope,operation]` și biblioteca locală. Regresia impune mai întâi Save&connect pentru A → Connected, apoi Test explicit B, păstrând identitatea activă și doar două Starts.

În `SettingsModelsPage.tsx:109–118`, efectul de hidratare rula înaintea proiecției observed→library (`:153–159`). Când GET-ul lui B întorcea FINISHED/rev3, `operationPending` devenea false, dar biblioteca încă avea RUNNING/rev2 pentru aceeași B. Hidratarea copia vechiul RUNNING în query-ul B; proiecția următoare îl putea copia înapoi în bibliotecă. Nu era necesară altă operație sau altă cheie de query pentru a reproduce.

RED real prin App/HTTP synthetic: `SOURCE_DIRECT_TERMINAL` păstrat înainte de cleanup arată aceeași operație `906c8b4e-f405-413e-9311-edd23695e497`, fixture FINISHED/rev3, query RUNNING/rev2, două GET-uri exacte și numai două Starts, visibility=visible. Primul model rămăsese Connected, al doilea Connecting/Cancel. Astfel, în reproducer nu este poll suspendat prin visibility, lipsă de terminal la producer sau identitate greșită; este suprascriere locală.

Am urmărit definițiile/callerii startTest, readTest, readCheck, connectEntries, query/hidratare/proiecție, readPrivate/client/decodere și semantica din settings-final.md. Fixture-ul real are `remove_peer_release.set()` înainte de scenariu; `clear()` aparține ramurii ulterioare entry_remove, după return-ul healthy UI. Nu am găsit în SOURCE o barieră comună care ține intenționat al doilea Test healthy; aceasta nu dovedește starea fizică a peerului din FAIL-ul istoric.

Remediul este un singur guard de identitate: hidratarea nu mai rescrie operația deja selectată din proiecția bibliotecii, care poate fi mai veche; continuă să recupereze o operație activă diferită. Dependența `operation` este declarată în efect și un comentariu explică ordinea. `working={busy}`, polling/deadline, guardurile active/Cancel, Stop/UNKNOWN/read manual și dispatch nu au fost modificate. Nu s-a schimbat niciun oracle E2E și nu s-a introdus read manual ca workaround.

### Verificări follow-up și intervale UTC pentru host load

Originale noi distincte: `astra-evidence/direct-*.command.json`, `.stdout.txt`, `.stderr.txt`; fiecare command JSON are argv/cwd/returncode/started_utc/ended_utc/duration_seconds. Toate npm rulează din web cu PATH și binarele pinned din raportul istoric. Intervalele nu dovedesc singure suprapunerea cu diagnosticul Sol; permit părintelui corelarea fără acces la fixture-ul lui.

- `direct-red`: 09:49:09.010–09:49:12.822Z, `npm test -- src/app/SettingsWizard.test.tsx -t 'SOURCE healthy direct Test'`, exit1. Eșec al noului test înainte de fază: lookup sincron pentru rândul încă nesalvat. Corectat numai prin await pe rândul existent, fără timeout mărit. Original păstrat, nu product RED.
- `direct-red-2`: 09:49:32.878–09:49:37.112Z, aceeași comandă, exit1/1FAIL108skipped. RED comportamental curat: FINISHED3 la fixture vs RUNNING2 în query.
- `direct-green`: 09:50:19.200–09:50:22.142Z, aceeași comandă, exit0/1PASS108skipped. Fără Read/Reload/Cancel, query+library+UI sunt terminale simultan, primul rezultat păstrat, două Starts distincte și nicio mutație în plus.
- `direct-regression`: 09:51:06.255–09:51:27.398Z, `npm test -- src/app/SettingsWizard.test.tsx -t 'SOURCE healthy direct Test|recovers the actual active check|expands history without replacing|remote UNKNOWN|manual read uncertainty|ends the unsent sequence|does not claim Connected|orphan RUNNING Cancel|SOURCE missing local projection|Save & connect waits'` → exit0,27PASS/82skipped. Acoperă hidratare fresh/istoric, Cancel activ exact, Stop, UNKNOWN și read manual, serializare healthy/latest. Stderr gol.
- `direct-lint`: 09:51:50.871–09:51:52.183Z, `npm run lint` → exit0.
- `direct-typecheck`: 09:51:52.184–09:52:00.767Z, `npm run typecheck` → exit0.
- `direct-build`: 09:52:00.769–09:52:10.397Z, `npm run build` → exit0, contract/design/tsc/Vite reale, fără main build. Asset nou `web/dist/assets/index-CnipzoFp.js`.

Nu am rerulat full108 sau base172 doar pentru număr; păstrez probele neschimbate la scope-ul anterior. Nu am rerulat proba nativă Add pe buildul nou și nu o prezint ca test al noului guard; noua UI/browser/API/PG are poarta separată a părintelui. Nu a fost necesar un nou observer/harness al eșecului PG: clasa locală are deja RED→GREEN discriminant, iar limita atribuirii istorice rămâne explicită.

### Freeze curent și conservarea istoricului

- Commit nou coerent: `db6ab2bc4ff04f71cb101ca4f815fb74ccae0bd7` — fixModels hydration + o regresie prin App, fără alte căi.
- HEAD/tree curente: cele din CURRENT de mai sus. Tracked/index curate; doar cele patru symlinkuri preexistente, tip/ținte confirmate neschimbate; `git diff --check ea78ee2..HEAD` exit0.
- Manifestul acestui checkpoint istoric este acum `astra-evidence/freeze-db6ab2b.json`. Freeze-ul mai vechi a fost copiat byte-exact înainte de înlocuire în `freeze-ea78ee2.json`; diff-ul vechi în `candidate-ea78ee2.diff`, cu SHA256 original păstrat.
- `astra-evidence/direct-terminal.delta.diff`, ea78ee2→db6ab2b, SHA256 `7c91cfe788c156964110c504ccfd1ec6f381ddd0627643a86b65a55ba53d5ebd`.
- `astra-evidence/candidate-db6ab2b.diff`, cumulativ b1d276e→db6ab2b, SHA256 `baed21c71c2a166d3ae4d054d27ad45ecb640c17c504de4c585c9083bba7aee1`.
- Blob Page nou `a3d799db11051d14c7bc8754055b1eb736cf6c25`; blob test nou `834934e9cc6adb97336f861a24a54accd020f6d7`.
- Wizard `a9ddccfa4867aef0f3352c2f6eab01a18acca769` și E2E `f9436bdb7d9fb6dd0ffad165806b561e7e9726ac` rămân identice cu ea78ee2.
- Build manifest SHA256 `c1a0ba960ec48b2f3d1f427725ab1895170645ddd2fb0aaf3b364d4d66b9f96a`; JS SHA256 `d96ea4540841d43fa2be2b66754a7d0888cbb04206a87ebbe5c3497c522bc0b1`.

### Decizia următoare

Părintele obține re-review focalizat pe guardul de hidratare și regresie, apoi — numai după drain Sol și preflight fără efecte — decide QA reală `test-settings-remove-ui-pg` pe acest freeze. Comanda existentă, NEEXECUTATĂ de mine:

`PATH=/home/kali/.local/share/omnis-toolchains/bin:/usr/bin:/bin TMPDIR=/home/kali/.hermes/cache/scratch api/.venv/bin/python -I -B ops/run_test_db_gate.py --check --target test-settings-remove-ui-pg --uv /home/kali/.local/share/omnis-toolchains/bin/uv --timeout-seconds 600`

Criteriul rămâne automat: primul Save&connect Connected, apoi al doilea Test direct Connected fără Stop sau Read manual; abia apoi exact/current/latest/identități/revizii/cap64 pentru ambele, peer counts și census/restart existente. Nu înlocuiți cu succesul primei operații sau cu PASS Stop-read. Nu se resetează contoarele istorice și nu este autorizare de retry orb; un nou FAIL cere observația exactă a acelei execuții.

Reviewul vechi Add și PASS-ul parent stop-read rămân acceptări scoped ale ea78ee2, nu acceptarea automată a noului Page. Supervisorul/default-web/canonical și instalarea rămân la părinte. Revertul noului commit nu cere operații DB, dar reintroduce defectul de cache demonstrat. Nu am folosit fixture-ul/checkoutul Sol, conturi, credentiale, main, fișierele protejate, agenți sau setări Hermes.

Am omis PG/API/OCI/operator/canonical conform limitei de autoritate; native-browser SOURCE pe noul guard nu a fost rerulat după reproducerea prin App, iar QA reală rămâne la părinte.
Risc rămas: cauza clasei SOURCE este demonstrată; atribuirea FAIL-ului PG vechi și acceptarea healthy pe bytes noi nu sunt încă probate.

## Istoric păstrat — livrarea Add la ea78ee2, înainte de follow-up

Candidat implementat și comis; SOURCE PASS scoped. Review independent: NOT_RUN de developer, revine părintelui pe freeze-ul de mai jos. QA reală: NOT_RUN aici, neintegrat/neinstalat. Nu este închidere T1 sau admitere T2.

## Schimbarea finită

1. `web/src/features/engagement/SettingsModelWizard.tsx:108,148,152`
   - Cei doi calleri ai `add()` sunt butonul catalog și `Add model ID`; definiția și toate utilizările au fost urmărite înainte de editare.
   - Ambele expun `aria-disabled` și `aria-busy` din același `transient = working || loading`. Bariera efectivă rămâne în handler, iar blocările ferme rămân native. Busy nu scoate controlul din ordinea tastaturii.
   - `add()` întoarce admiterea booleană; ID-ul manual se golește numai după selecție reușită. Refuzurile transient, duplicat/configurat și plafon64 păstrează textul; validarea și plafonul nu sunt relaxate.
2. `web/src/app/SettingsWizard.test.tsx:75,135`
   - Șase regresii noi prin App real → SettingsModelsPage → wizard/client/decodere cu fixture HTTP SOURCE existentă, nu teste ale unui helper izolat.
   - Refetch Query, Reload manual și Refresh ținut: Add refuzat, zero chips, text/focus păstrate, fără replay după eliberare; apoi Add explicit catalog/manual, chips și Continue → Review. Testele de duplicat selectat/configurat și plafon64 verifică aceeași păstrare a inputului.
3. `web/tests/e2e/settings-models.mjs:156–207,343–355`
   - Stop-read așteaptă separat catalogul și terminarea lucrului wizard/bibliotecă; verifică Add enabled, fiecare chip exact, total2 și Continue enabled.
   - Callerul sănătos `runSettingsRemove` primește aceleași precondiții la deschiderea wizardului și postcondiții pentru Add catalog/manual; nimic schimbat în Remove sau în operațiile ulterioare.

Caller nemodificat: `SettingsModelsPage.tsx:101,399`, inclusiv `working={busy}`. Blob identic cu baza: `ff6e4a65e259199ecfedd6b4eb702f0e61d1bc78`.
Nicio altă cale tracked, fixture, dependență, backend, schemă, timeout, Stop/Cancel, receipt/CAS, rol/cap sau politică UNKNOWN/no-resend nu a fost modificată. Nu s-a lansat alt agent.

## Commituri și FREEZE

Checkout unic: `/home/kali/.hermes/cache/scratch/settings-inline-feedback-20261029`
Branch: `feat/settings-inline-feedback-20261029`
Bază verificată înainte de lucru: `b1d276e66455dca0939cfcb42eeca5af7b1fe515`
Tree de bază: `347be9def5348a680017d141155c938b95e6d65c`

- `cda914e7f676a6d8d86473fc02c2d674ecf0d4ef` — fix Add și regresii inseparabile.
- `ea78ee2705156af88f53df92549f93a99ef71149` — corecție E2E separată, fără schimbare de produs.

HEAD final: `ea78ee2705156af88f53df92549f93a99ef71149`
Tree final: `257e2207fe44d5bdb15eb619a33155911895664c`
Diff binar exact bază→HEAD istoric: `astra-evidence/candidate-ea78ee2.diff`
SHA256 diff: `6e54a9de23b21d3f9f4567d9ebb0cde5437223a67bf9eb67cc5ba2877686d594`

Blobs finale:
- Wizard: `a9ddccfa4867aef0f3352c2f6eab01a18acca769`
- Test componente: `a0b67f9400c4a9de447b190c5cedd2bf813fa714`
- E2E: `f9436bdb7d9fb6dd0ffad165806b561e7e9726ac`

`astra-evidence/freeze-ea78ee2.json` include și SHA256 ale fișierelor/buildului/probei native istorice. Tracked și index curate la acel freeze; `git diff --check` exit0. Au rămas numai cele patru symlinkuri untracked originale, cu țintele neschimbate: `api/.venv`, `cli/.venv`, `web/node_modules`, `tools/development/anti-slop/node_modules`. Nu au fost adoptate, înlocuite sau șterse. Main și cele două fișiere protejate nu au fost modificate/accesate.

## Execuții reale și originale păstrate

Director absolut de probe: `/home/kali/.hermes/cache/scratch/t1-parallel-20261030/astra-evidence/`.
Pentru fiecare prefix de mai jos există `.command.json` cu argv/cwd/returncode și `.stdout.txt`/`.stderr.txt` originale. Nu sunt transcrieri reconstruite. Toate comenzile npm au cwd `.../settings-inline-feedback-20261029/web`; executabil npm absolut `/home/kali/.local/share/omnis-toolchains/bin/npm`, PATH pinned `/home/kali/.local/share/omnis-toolchains/bin:/usr/bin:/bin`. Node24.21.0/npm11.19.0 verificate.

- `add-red`: `npm test -- src/app/SettingsWizard.test.tsx -t 'SOURCE Add controls'` → exit1, 3FAIL/102skipped. Prima încercare include un timeout inițial de montare în cazul query și o referință DOM desprinsă după Refresh; cazurile manual/Refresh au demonstrat deja lipsa ARIA și ștergerea inputului. Originalul este păstrat, nu prezentat drept trei RED-uri comportamentale curate.
- `add-red-2`: `npm test -- src/app/SettingsWizard.test.tsx -t 'SOURCE (Add controls|manual Add)'` → exit1, 6FAIL/102skipped, toate pe defectele așteptate ale produsului vechi. Corecția testului recitește butonul după terminarea catalogului, fără sleep/timeout mărit. Produsul era încă nemodificat la acest RED.
- `add-green`: `npm test -- src/app/SettingsWizard.test.tsx -t 'SOURCE (Add controls|manual Add|wizard exposes)'` → exit0, 8PASS/100skipped. Include cele două bariere Save/readback existente.
- `wizard-regression`: `npm test -- src/app/SettingsWizard.test.tsx` → exit0, 108PASS, fără stderr. Include Save/readback, secvență/Stop/UNKNOWN, caps, validare și cele șase regresii noi. Nu s-au repetat celelalte suite componente neafectate; baza acceptată172 rămâne dovadă istorică scoped.
- `lint`: `npm run lint` → exit0.
- `typecheck`: `npm run typecheck` → exit0.
- `build`: `npm run build` → exit0, contract/design checks, tsc și Vite reale; build numai în checkoutul candidat.
- `e2e-lint`: `npm run lint` → exit0 după editarea E2E.
- `e2e-syntax`: `/home/kali/.local/share/omnis-toolchains/bin/node --check tests/e2e/settings-models.mjs` → exit0.
- `add-native-source`: `/home/kali/.local/share/omnis-toolchains/bin/node --test /home/kali/.hermes/cache/scratch/t1-parallel-20261030/astra-evidence/add-native-source.mjs` → exit0, 1PASS, fără stderr. Chromium nativ prin Playwright1.63.0, build instalat Chromium1243; `1.63.0` este versiunea Playwright, nu versiunea Chromium (formularea prescurtată din mesajul celui de-al doilea commit nu trebuie interpretată altfel).

## Ce demonstrează proba nativă SOURCE

Preflight: binare pinned, Chromium existent, modul parsabil și `web/dist` al candidatului nesymlink. Proba reutilizează structura diagnosticului `/home/kali/.hermes/cache/scratch/models-add-b1-native-diagnostic.mjs`; originalul nu a fost schimbat. Noul fișier este în directorul de probe, nu produs/harness instalat. Server local preview cu envDir/publicDir dezactivate, numai asseturi locale și HTTP sintetic allowlisted; nicio API/PG/OCI sau instanță operator.

Pe `web/dist/assets/index-_Hxlo098.js`:
- Catalogul are aria-busy=false, dar GET-ul bibliotecii este ținut și Continue are aria-busy=true. Add catalog/manual sunt recunoscute disabled de Playwright prin ARIA, fără native disabled pentru transient.
- Enter/Space reale păstrează focusul, nu adaugă chips și nu șterg `manual/preview`.
- După eliberarea GET-ului: zero chips și Continue încă disabled din lipsa selecției, nu din busy. Nu există replay automat.
- Enter explicit admite ID-ul manual și golește inputul; chip-ul poate fi eliminat. Apoi cele două Add catalog produc exact chips `fixture/01`, `fixture/02`; Continue ajunge în Review.
- Un Refresh sintetic, un search sintetic, exact un GET ținut/eliberat, zero Save, zero Start, zero cereri neașteptate și zero erori pagină. Browser/context/preview sunt închise în finally, procesul termină exit0.

Aceasta verifică aceleași selectoare/oracol ca prefixul E2E corectat, NU execută driverul API/PG complet și NU aprobă aspectul vizual. Nu au fost capturi sau certificare screen-reader/cross-browser. Reticle NOT_INTEGRATED; Chisel BLOCKED_NO_GO.

## Oracolul și următoarea poartă, exclusiv la părinte

Cerință → consumer → risc → decizie: Add trebuie să fie utilizabil numai când handlerul îl admite; wizardul și `settings-stop-read` nu trebuie să avanseze pe clickuri ignorate. Catalog aria-busy=false singur este insuficient. Continue aria-busy=false reflectă `working || loading`, inclusiv reading/refetch din pagina părinte. Add enabled (ARIA + native), chip exact după fiecare click, totalul2 și Continue enabled sunt postcondițiile pozitive. Negativul SOURCE ține numai citirea bibliotecii după catalog gata și cere zero chips/Save/Start plus input/focus păstrate. Nu există polling workaround, force-click, sleep sau timeout extins.

După clearance independent pe freeze, părintele poate admite proba îngustă existentă, din checkoutul candidat, NU executată aici:

`PATH=/home/kali/.local/share/omnis-toolchains/bin:/usr/bin:/bin TMPDIR=/home/kali/.hermes/cache/scratch api/.venv/bin/python -I -B ops/run_test_db_gate.py --check --target test-settings-stop-read-ui-pg --uv /home/kali/.local/share/omnis-toolchains/bin/uv --timeout-seconds 600`

Targetul din Makefile37–39 folosește opt-in `OMNIS_SETTINGS_STOP_READ_UI=1` și testul `api/tests/test_model_test_v2.py::test_api_pg_sdk_protocol_and_replay[entry_stop_read_ui]`. Driverul real este `web/tests/e2e/run.mjs settings-stop-read` prin fixture-ul existent, nu invocat direct fără owner/prerechizite.

Aserțiuni ulterioare păstrate: un Save cu două modele, un singur Start admis202 pentru primul, Stop abandonează modelul nesent, citire explicită receive-only pe aceeași operation ID și latest-entry; FINISHED/state_revision3/COMPLETED/current=true, entry/connection rev1 și cap64 exacte, al doilea latest404/NOT_FOUND, nicio retrimitere. Ownerul cere numai un Start, două GET metadata și un POST către peerul sintetic, primul model terminat, workers goi și census existent. Nu s-a schimbat acest oracol sau bugetul de efecte.

Scenariul sănătos fără Stop rămâne separat: `--target test-settings-remove-ui-pg` cu același runner/limita600, numai dacă părintele îl admite după review și diagnosticul necesar. Aserțiunile lui terminal/current/latest, identitate, CAS, peer/census/restart sunt neschimbate. Nu se revendică executarea lui prin SOURCE.

## Limite și blocante rămase

- Remediul Add este verificat scoped; acceptarea candidatului așteaptă reviewul independent al părintelui și QA reală admisă. Nu am făcut autoreview de acceptare sau integrare.
- Cele două eșecuri PG care nu au ajuns la Save/Start/Stop nu sunt atribuite retrospectiv acestei cauze. Logul PG vechi dovedește busy inițial și disabled persistent, nu busy=true timp de30s.
- Eșecul Stop→Connected vechi NU este declarat reparat. SOURCE nu dovedește terminarea workerului/peerului din acea execuție.
- Supervisorul și slotul DB al investigatorului nu au fost atinse. Cauza supervisor/default-web și canonicalul rămân la mandatul părintelui; contoarele istorice nu se resetează.
- Fără PG/API/OCI/native-installed acceptance, canonical, Start/Stop/recover operator, build main, instalare, push, provider/model/target traffic sau T2. Nu s-au folosit credentiale personale; nu s-au afișat env/cookies/DSN. Rularea execute_code a fost refuzată înaintea oricărui efect; fișierul scratch a fost creat ulterior prin unealta normală write_file, fără schimbarea setărilor Hermes.
- Revert: cele două commituri sunt coerente și separate; E2E poate fi revertat independent. Revertul fixului reintroduce defectul demonstrat, fără efecte DB de inversat.

Am omis deliberat QA PG/instalată, canonicalul și aprobarea vizuală: aparțin părintelui după review.
Risc rămas: SOURCE verde nu închide eșecurile istorice Stop/supervisor și nu certifică aplicația operatorului.
