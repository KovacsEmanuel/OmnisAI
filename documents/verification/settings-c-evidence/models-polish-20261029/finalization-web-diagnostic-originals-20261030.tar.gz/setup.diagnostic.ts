import '@testing-library/jest-dom/vitest';
import { cleanup } from '@testing-library/react';
import { QueryCache } from '@tanstack/react-query';
import { beforeEach, afterEach, vi } from 'vitest';

// SOURCE_FINALIZATION_DIAGNOSTIC: temporary, no response bodies or query data retained.
let current = '';
let ended = false;
const signalOwners = new WeakMap<AbortSignal, string>();
const queryOwners = new WeakMap<object, string>();
const responsePaths = new WeakMap<Response, string>();
let events: object[] = [];
function record(value: object) {
  events.push(value);
  if (ended || ('owner' in value && value.owner !== current)) console.error('SOURCE_FINALIZATION_LATE ' + JSON.stringify(value));
}
const label = (path: string) => path.replace(/[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}/g, ':id').split('?')[0];

beforeEach(context => {
  current = context.task.name; ended = false; events = [];
  vi.stubGlobal('scrollTo', vi.fn());
  const combine = AbortSignal.any.bind(AbortSignal);
  vi.spyOn(AbortSignal, 'any').mockImplementation(signals => {
    const owner = signals.map(signal => signalOwners.get(signal)).find(Boolean) ?? current;
    for (const signal of signals) if (!signalOwners.has(signal)) signalOwners.set(signal, owner);
    const combined = combine(signals); signalOwners.set(combined, owner); return combined;
  });
  const stub = vi.stubGlobal.bind(vi);
  vi.spyOn(vi, 'stubGlobal').mockImplementation((name, value) => {
    if (name === 'fetch' && vi.isMockFunction(value)) {
      const implementation: typeof fetch = value.getMockImplementation()!;
      value.mockImplementation(async (input: RequestInfo | URL, init?: RequestInit) => {
        const path = label(String(input)), owner = init?.signal ? signalOwners.get(init.signal) ?? current : current;
        record({ boundary: 'request', path, method: init?.method ?? 'GET', owner, current, ended, aborted: init?.signal?.aborted ?? false });
        const response = await implementation(input, init);
        responsePaths.set(response, path ?? 'unknown');
        record({ boundary: 'response', path, status: response.status, owner, current, ended });
        return response;
      });
    }
    return stub(name, value);
  });
  const json = Response.prototype.json;
  vi.spyOn(Response.prototype, 'json').mockImplementation(async function (this: Response) {
    const path = responsePaths.get(this), owner = current;
    record({ boundary: 'json-start', path, owner });
    const value: unknown = await json.call(this);
    record({ boundary: 'json-complete', path, owner, current, ended });
    return value;
  });
  const notify = QueryCache.prototype.notify;
  vi.spyOn(QueryCache.prototype, 'notify').mockImplementation(function (this: QueryCache, event) {
    const query = event.query;
    if (!queryOwners.has(query)) queryOwners.set(query, current);
    if (event.type === 'updated') record({ boundary: 'query', label: query.queryKey[0] === 'private' ? query.queryKey[1] : query.queryKey[0], owner: queryOwners.get(query), current, ended, status: query.state.status, fetchStatus: query.state.fetchStatus, error: query.state.error?.name ?? null });
    return notify.call(this, event);
  });
});

afterEach(() => {
  record({ boundary: 'dom-before-cleanup', current, models: !!document.querySelector('[aria-label="Configured models"]'), wizard: !!document.querySelector('[aria-label="Draft setup"]'), inputCount: document.querySelectorAll('input').length });
  ended = true;
  cleanup();
  console.error('SOURCE_FINALIZATION_DIAGNOSTIC ' + JSON.stringify({ test: current, events }));
  vi.unstubAllGlobals();
});
