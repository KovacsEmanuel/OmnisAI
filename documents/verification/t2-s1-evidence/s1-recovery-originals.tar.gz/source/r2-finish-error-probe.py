"""Fault at the actual SDK return after the committed owner finish callback."""
import json
from unittest.mock import AsyncMock

import pytest
from sqlalchemy.ext.asyncio import AsyncConnection

from omnis.modules.runs import run_store as store
from omnis.supervisor.agent_runner import AgentStep
from omnis.supervisor.model_sender import SendDenied
from test_run_controls_source import owned as owned
from test_run_finish_source import test_finish_sdk_waits_for_owner_receipt_and_settlement_never_duplicates as journey

@pytest.mark.asyncio
async def test_finish_timeout_after_txa_persists_non_running_state(owned, monkeypatch):
    original_run = AgentStep.run
    original_finish = owned.owner.finish_step
    original_tool = owned.owner.execute_tool
    retained = {}
    async def capture_tool(identity, scope, attempt_id, snapshot, name, arguments, call_id):
        result = await original_tool(identity, scope, attempt_id, snapshot, name, arguments, call_id)
        retained.update(identity=identity, scope=scope, attempt_id=attempt_id)
        return result
    monkeypatch.setattr(owned.owner, 'execute_tool', capture_tool)
    async def lost_sdk_return(self, *args, **kwargs):
        async def deadline_fault(value):
            if isinstance(value, str) and 'result_ref' in value:
                assert owned.writes[-1] == 'commit'
                raise TimeoutError('SYNTHETIC deadline during post-commit finish-feedback DATA check')
        try:
            await original_run(self, *args, **kwargs, check_data=deadline_fault)
        except SendDenied as error:
            assert str(error) == 'MODEL_OUTPUT_DENIED'
            assert owned.run.state == 'RUNNING' and owned.run.active_attempt_id is None
            retained['before'] = owned.run.model_dump()
            # SDK wraps tool failure; work maps SendDenied to MODEL_RESPONSE_UNKNOWN.
            with monkeypatch.context() as fault:
                fault.setattr(AsyncConnection, 'scalar', AsyncMock(return_value='UNKNOWN'))
                fault.setattr(store, 'dispatch_event', AsyncMock())
                again = await original_finish(object.__new__(AsyncConnection), retained['identity'], retained['attempt_id'], retained['scope'], None, 'MODEL_RESPONSE_UNKNOWN', admitted=True)
            retained['after'] = owned.run.model_dump()
            retained['again'] = again
            raise
        raise AssertionError('Expected actual SDK callback timeout')
    monkeypatch.setattr(AgentStep, 'run', lost_sdk_return)
    with pytest.raises(SendDenied, match='MODEL_OUTPUT_DENIED'):
        await journey(owned, monkeypatch, 'valid')
    print('FINISH_POST_TXA_ERROR', json.dumps({key: retained[key] for key in ('before', 'after', 'again')}))
    assert retained['again'] is False
    assert retained['after']['state'] != 'RUNNING', 'work exits after SDK error but RUNNING/RESULT_READY is never persisted as reconciliation'
