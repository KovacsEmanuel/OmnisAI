# Review independent — Models Add / transient / manual-input

## Verdict și decizie

**APPROVED_SCOPED** pe candidatul `ea78ee2705156af88f53df92549f93a99ef71149`, tree `257e2207fe44d5bdb15eb619a33155911895664c`, exclusiv delta față de `b1d276e66455dca0939cfcb42eeca5af7b1fe515`.

**Findings noi: niciunul.** Nu am identificat un defect concret care să blocheze această remediere. Findingul existent Add/transient/manual-input este **remediat și închis în scope-ul SOURCE revizuit**; închiderea nu transferă PASS asupra QA API/PG sau asupra FAIL-urilor istorice Stop/supervisor.

**Prima probă reală îngustă existentă poate fi admisă după preflight fără efecte și confirmarea eliberării/drain-ului DB de către Sol.** Nu am verificat acea eliberare și nu am lansat proba. Candidatul nu este integrare/instalare, acceptare T1 ori autorizare T2.

Cerință → consumer → risc → decizie: Add din wizard trebuie să expună aceeași barieră tranzientă pe care o aplică handlerul, fără pierderea textului/focusului; consumerii sunt App → SettingsModelsPage → SettingsModelWizard și prefixele E2E stop-read/healthy-remove. Riscul este click ignorat urmat de selecție goală/Continue indisponibil sau input manual șters. Clearance-ul acestei delte permite QA afectată; un reproducer contrar ar reveni developerului Astra, nu ar autoriza reviewerul să editeze produsul.

## FREEZE verificat independent

Checkout: `/home/kali/.hermes/cache/scratch/settings-inline-feedback-20261029`; branch `feat/settings-inline-feedback-20261029`.

- Bază: `b1d276e66455dca0939cfcb42eeca5af7b1fe515`.
- Commituri candidate: `cda914e7f676a6d8d86473fc02c2d674ecf0d4ef` și `ea78ee2705156af88f53df92549f93a99ef71149`.
- HEAD/tree: cele din verdict, confirmate și la ultima verificare.
- Delta exactă: **3 fișiere, 103 inserări / 6 ștergeri**; niciun alt fișier tracked schimbat.
- SHA256 `git diff --binary <base>..HEAD`: `6e54a9de23b21d3f9f4567d9ebb0cde5437223a67bf9eb67cc5ba2877686d594`, identic manifestului autorului.

| Fișier | Blob HEAD, confirmat și prin `git hash-object` pe fișierul curent |
|---|---|
| `web/src/features/engagement/SettingsModelWizard.tsx` | `a9ddccfa4867aef0f3352c2f6eab01a18acca769` |
| `web/src/app/SettingsWizard.test.tsx` | `a0b67f9400c4a9de447b190c5cedd2bf813fa714` |
| `web/tests/e2e/settings-models.mjs` | `f9436bdb7d9fb6dd0ffad165806b561e7e9726ac` |
| Caller neschimbat `web/src/features/engagement/SettingsModelsPage.tsx` | `ff6e4a65e259199ecfedd6b4eb702f0e61d1bc78`, identic bazei |

`git diff --exit-code`, `git diff --cached --exit-code` și `git diff --check <base>..HEAD`: exit0. Tracked/index curate. Singurele untracked sunt symlinkurile preexistente `api/.venv`, `cli/.venv`, `web/node_modules`, `tools/development/anti-slop/node_modules`; tipul lor a fost verificat prin lstat, fără ștergere/înlocuire. Main nu a fost folosit pentru operațiuni de produs; fișierele protejate nu au fost deschise/hashedate/staged.

## Conformitate și dispoziția findingului Add

| Criteriu afectat | Cod / control direct | Concluzie |
|---|---|---|
| Disponibilitatea Add în timpul library refetch / Reload / Refresh | `SettingsModelsPage.tsx:100–101,399` transmite `working={busy}`, unde busy include sending/reading/current.isFetching. `SettingsModelWizard.tsx:49–50,110,148,152` folosește același `transient = working || loading` în ARIA și în refuzul efectiv. CSS existent `SettingsModels.module.css:54` semnalizează aria-disabled. | Remediul nu confundă catalog gata cu bibliotecă settled. Ambele Add devin semantic indisponibile/busy fără native disabled pentru tranzient; guardul rămâne efectiv pentru click/Enter/Space. |
| Păstrarea inputului refuzat | `SettingsModelWizard.tsx:108–115,152`: toate ieșirile de refuz întorc false; inputul se golește numai dacă add întoarce true. Validarea ASCII și guardurile locked/duplicat/configurat/plafon64 rămân. | Refuzul nu mai consumă textul. Nu se relaxează validarea, limita sau statutul UNVERIFIED. |
| Focus și lipsa replay-ului | `SettingsWizard.test.tsx:75–133`: query/manual/refresh țin lucrul, activează catalog cu Enter și manual cu Space, verifică focus/text/zero chips înainte și după release, apoi cer o nouă activare explicită. Proba Chromium SOURCE existentă verifică aceeași secvență pe build. | Tranzientul nu scoate controlul din Tab order și nu reexecută automat intentul refuzat. Focusul verificat aici este cel al refuzului tranzient, nu certificare generală de accesibilitate. |
| Refuz duplicat/configurat/cap64 | `SettingsWizard.test.tsx:135–152` verifică textul exact păstrat și zero modificări ale bibliotecii/cheilor; cap64 păstrează alerta. | Findingul privind ștergerea inputului este acoperit și pe aceste refuzuri. Nu introducem un contract nou de validare live/disabled pentru orice text manual invalid. |
| Postcondiții E2E stop-read | `settings-models.mjs:343–354`: catalog aria-busy=false **și** Continue aria-busy=false, Add enabled, chip exact după fiecare click, total2, Continue enabled. | Oracol pozitiv după efectul UI, nu simpla executare a unui click; fără force-click, sleep sau timeout mărit. |
| Consumer healthy fără Stop | `settings-models.mjs:156–174,202–206`: aceleași bariere la deschidere, chips catalog/manual și golirea manualului numai după succes; chip exact și total1 înainte de Review pentru verificarea sănătoasă. | Prefix întărit, fără schimbarea Remove sau a verificărilor terminale ulterioare. |

Au fost urmărite definiția `add()` și ambii calleri existenți; nu există caller suplimentar care să consume noul boolean. Nu sunt necesare exporturi, configurări, fixtures sau dependențe noi. Diff-ul nu schimbă Remove/backend/receipt/CAS/Stop/capuri/timeouts. Aprobările istorice pentru autoritate/Stop/dispatch se reutilizează în scope-ul lor neschimbat, fără un audit general nou.

## Dovezi originale citite și verificări proaspete

Director originale: `/home/kali/.hermes/cache/scratch/t1-parallel-20261030/astra-evidence/`. Am citit codul și controalele relevante, stdout/stderr RED2, stdout GREEN/suita wizard și proba nativă, plus argv/cwd/returncode din fișierele `.command.json` corespunzătoare; nu am tratat raportul autorului ca substitut pentru acestea.

- RED2: `npm test -- src/app/SettingsWizard.test.tsx -t 'SOURCE (Add controls|manual Add)'` → **exit1, 6 FAIL / 102 skipped**. Eșecurile directe includ ARIA absent și valoarea manuală devenită goală pe refuz. Prima încercare RED cu probleme de test rămâne istorică, nu este promovată drept RED curat.
- GREEN: `npm test -- src/app/SettingsWizard.test.tsx -t 'SOURCE (Add controls|manual Add|wizard exposes)'` → **exit0, 8 PASS / 100 skipped**.
- Regresia wizard: `npm test -- src/app/SettingsWizard.test.tsx` → **exit0, 108 PASS**.
- Lint/typecheck/build și lint/syntax după E2E: returncode0 în originalele autorului; build stdout confirmă contract/design checks, tsc și Vite. Nu am rerulat aceste suite fără o suspiciune nouă concretă.
- `add-native-source.mjs`, Node `--test` → **exit0, 1 PASS** în original: Chromium real, HTTP exclusiv sintetic allowlisted; library GET ținut după catalog gata, Enter/Space refuzate cu focus/text păstrate, zero replay, apoi selecție manuală și două chips catalog exacte → Review. **Zero Save/Start**, unexpected/errors goale. Este SOURCE/native-browser, nu API/PG și nu aprobare vizuală.
- Am confirmat proaspăt SHA256-urile buildului/probei față de freeze: manifest `202c3e9792727a57166a24c5a70dc0a1441c0df83725c6b0900c1d83afc259cc`, JS `76cd600ae6570bb4e432131d76926b1e82161240c5dfd53ee6b7096f226039aa`, probă `735d9f0412df49c405a2d9f44839c68377554f13a029a597ca18af648f8997ad`.
- Control independent proaspăt: `/home/kali/.local/share/omnis-toolchains/bin/node --check web/tests/e2e/settings-models.mjs` → **exit0**; identitățile Git/diff și starea curată au fost reverificate. Toolchain observat: Node24.21.0/npm11.19.0. Nu am lansat teste PG/OCI/API/operator, agenți sau inferență.

## Oracolul real păstrat și admiterea QA

`Makefile:37–39` selectează exact `test-settings-stop-read-ui-pg`, build-web și opt-in-ul scenariului `test_api_pg_sdk_protocol_and_replay[entry_stop_read_ui]` (`api/tests/test_model_test_v2.py:126–131`). Runnerul existent admite targetul și limita în parser (`ops/run_test_db_gate.py:1038–1039,1068`). Acestea sunt citiri SOURCE, nu un preflight complet și nu o lansare.

Oracolul neschimbat din `settings-models.mjs:355–410` și `test_model_test_v2.py:613–615,699–755` cere:

- un Save cu exact două modele, un singur Start admis202 pentru primul, identitate/revizii/generation corecte;
- Stop remaining checks abandonează al doilea nesent, fără Cancel/Start nou;
- read-only exact operation și latest-entry identice: FINISHED/state_revision3, COMPLETED/COMPLETED, current=true, entry/connection rev1, fixture/01/cap64;
- latest pentru al doilea:404/NOT_FOUND; intenturile rămân refresh/save_models/start o singură dată;
- ownerul vede exact două metadata GET și un POST sintetic, primul peer completat, workers goi/fără settlement_failed, două intrări/un system_operation/un SENT și assignments absente.

Prin urmare este admisibilă, **numai după preflight și drain-ul Sol**, comanda deja consemnată de autor, din checkoutul înghețat:

```sh
PATH=/home/kali/.local/share/omnis-toolchains/bin:/usr/bin:/bin TMPDIR=/home/kali/.hermes/cache/scratch api/.venv/bin/python -I -B ops/run_test_db_gate.py --check --target test-settings-stop-read-ui-pg --uv /home/kali/.local/share/omnis-toolchains/bin/uv --timeout-seconds 600
```

Atenție de argv pentru preflight: parserul definește `--timeout-seconds` cu valoare separată; tokenul condensat `--timeout-seconds600` din context nu este acea opțiune și nu trebuie executat ca atare. Aceasta nu este un finding de produs.

Înainte de efecte, părintele/QA confirmă bytes neschimbați, source/library/pin și accesul/căile, fixture fresh proprie, deadline/cleanup/readback și eliberarea resursei Sol. Nicio resetare a contoarelor istorice harness-only și niciun retry orb. `test-settings-remove-ui-pg` rămâne scenariul sănătos separat, nu este certificat de stop-read. Instanța operatorului UNAVAILABLE nu se pornește/recuperează/oprește pentru această verificare.

## Predare

Cod: remediu implementat pe candidat neintegrat. Dovadă: SOURCE/component/browser existente verificate ca scope și identitate; QA reală afectată **NOT_RUN în acest review**. Review: **APPROVED_SCOPED** pentru delta Add și postcondițiile E2E pe freeze-ul de mai sus. Singurul fișier creat de reviewer este acest raport; nicio modificare de produs, commit, instalare sau tranziție de aprobare T1/T2. Reticle NOT_INTEGRATED; Chisel BLOCKED_NO_GO.

Am omis PG/OCI/operator, QA completă healthy, capturi/aprobare vizuală și screen-reader/cross-browser; nu am făcut audit general sau rerulări redundante.
Risc rămas: SOURCE verde nu explică retrospectiv FAIL-urile PG/Stop/supervisor și nu garantează trecerea viitoarei probe reale; T1 rămâne neînchis.
