// SOURCE only; adapted from models-add-b1-native-diagnostic.mjs, original unchanged.
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import test from 'node:test';
import { instance } from '/home/kali/.hermes/cache/scratch/settings-inline-feedback-20261029/web/tests/fixtures.ts';
const root = '/home/kali/.hermes/cache/scratch/settings-inline-feedback-20261029/web';
const require = createRequire(`${root}/package.json`);
const { preview } = await import(require.resolve('vite'));
const { chromium, expect } = require('@playwright/test');
const check = expect.configure({ timeout: 5000 });
const id = '11111111-1111-4111-8111-111111111111';
const catalogId = '33333333-3333-4333-8333-333333333333';
const connection = { connection_id: id, provider: 'openrouter', revision: 1, enabled: true, credential_present: true };
const current = { schema_version: 2, command_id: null, vault_status: 'UNLOCKED', connections: [connection], selection: null, reachable: 'NOT_VERIFIED' };
const registry = { schema_version: 1, command_id: null, registry_revision: 1, total: 0, after: null, next_after: null, entries: [] };
const paint = page => page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
await test('SOURCE Add refuses transient work without losing input/focus; settled native selection reaches Review', { timeout: 90000 }, async () => {
  const server = await preview({ configFile: false, envDir: false, publicDir: false, root, preview: { host: '127.0.0.1', port: 0, strictPort: true, cors: false } });
  const origin = `http://127.0.0.1:${server.httpServer.address().port}`;
  let browser, context, page, refreshed = 0, held = 0, completedHeld = 0;
  const gate = Promise.withResolvers(), counts = {}, unexpected = [], errors = [];
  try {
    browser = await chromium.launch();
    context = await browser.newContext({ viewport: { width: 1440, height: 1000 }, reducedMotion: 'reduce', serviceWorkers: 'block' });
    await context.route('**/*', async route => {
      const request = route.request(), url = new URL(request.url()), path = url.pathname, method = request.method();
      if (url.origin !== origin) { unexpected.push(`${method} ${url.origin}`); return route.abort(); }
      if (!path.startsWith('/api/') && !path.startsWith('/health/')) {
        if (method === 'GET' && (path === '/settings/providers' || path === '/index.html' || path.startsWith('/assets/'))) return route.continue();
        unexpected.push(`${method} ${path}`); return route.abort();
      }
      const key = `${method} ${path}`; counts[key] = (counts[key] ?? 0) + 1;
      if (method === 'GET' && path === '/api/session') return route.fulfill({ json: { authenticated: true, csrf_token: 'a'.repeat(64) } });
      if (method === 'GET' && path === '/api/instance') return route.fulfill({ json: { ...instance, generation: 1, admission_open: true } });
      if (method === 'GET' && path === '/health/ready') return route.fulfill({ json: { api_ready: true, dashboard_ready: true, assessment_ready: false, reason: null, dashboard_reason: null } });
      if (method === 'GET' && path === '/api/v1/settings/providers') return route.fulfill({ json: current });
      if (method === 'GET' && path === '/api/v1/settings/models') {
        if (refreshed) { held++; await gate.promise; completedHeld++; }
        return route.fulfill({ json: registry });
      }
      if (method === 'POST' && (path.endsWith('/provider-catalog/search') || path.endsWith('/provider-catalog/refresh'))) {
        const body = request.postDataJSON(); if (body.action === 'refresh') refreshed++;
        const entries = ['fixture/01', 'fixture/02'].map(model => ({ model, name: model, max_output_tokens: 4096, supports_max_tokens: true, reason: null }));
        return route.fulfill({ json: { schema_version: 1, connection_id: id, connection_revision: 1, provider: 'openrouter', catalog_command_id: body.command_id ?? body.catalog_command_id ?? catalogId, state: 'READY', reason: null, query: body.query ?? '', offset: body.offset ?? 0, next_offset: null, total: entries.length, entries } });
      }
      // No Save, Start, Cancel, peer, upstream or unknown endpoint is permitted.
      unexpected.push(key); return route.abort();
    });
    page = await context.newPage(); page.setDefaultTimeout(5000); page.on('pageerror', error => errors.push(error.message));
    await page.goto(`${origin}/settings/providers`);
    const open = page.getByRole('button', { name: 'Add models', exact: true });
    await check(open).toHaveAttribute('aria-disabled', 'false'); await open.click();
    const wizard = page.getByRole('region', { name: 'Add models wizard', exact: true });
    const next = wizard.getByRole('button', { name: 'Continue', exact: true });
    await next.click();
    await check.poll(() => held).toBeGreaterThan(0);
    const providerList = wizard.getByRole('list', { name: 'Provider models', exact: true });
    await check(providerList).toHaveAttribute('aria-busy', 'false');
    await check(next).toHaveAttribute('aria-busy', 'true');
    const chips = wizard.getByRole('list', { name: 'Selected models', exact: true });
    const add = model => wizard.getByRole('button', { name: `Add ${model}`, exact: true });
    for (const model of ['fixture/01', 'fixture/02']) {
      const button = add(model); await check(button).toBeDisabled();
      assert.equal(await button.evaluate(node => node.disabled), false);
      await button.focus(); await page.keyboard.press('Enter'); await check(button).toBeFocused();
    }
    await wizard.getByText('Enter a model ID', { exact: true }).click();
    const manual = wizard.getByLabel('Exact model ID', { exact: true });
    await manual.fill('manual/preview');
    const manualAdd = wizard.getByRole('button', { name: 'Add model ID', exact: true });
    await page.keyboard.press('Tab'); await check(manualAdd).toBeFocused(); await check(manualAdd).toBeDisabled();
    assert.equal(await manualAdd.evaluate(node => node.disabled), false);
    await page.keyboard.press('Space'); await paint(page);
    await check(manualAdd).toBeFocused(); await check(manual).toHaveValue('manual/preview');
    await check(chips.getByRole('listitem')).toHaveCount(0); await check(next).toBeDisabled();
    assert.equal(completedHeld, 0);
    console.log('SOURCE_ADD_TRANSIENT ' + JSON.stringify({ catalogReady: true, libraryHeld: held, chips: 0, manualRetained: true, keyboardFocusRetained: true, save: 0, start: 0 }));
    gate.resolve();
    await check(next).toHaveAttribute('aria-busy', 'false'); await check(open).toHaveAttribute('aria-disabled', 'false');
    await check(chips.getByRole('listitem')).toHaveCount(0); await check(next).toBeDisabled();
    await check(manualAdd).toBeFocused(); await check(manual).toHaveValue('manual/preview'); await check(manualAdd).toBeEnabled();
    await page.keyboard.press('Enter');
    const manualChip = chips.getByRole('button', { name: 'Remove selected manual/preview', exact: true });
    await check(manualChip).toBeVisible(); await check(manual).toHaveValue(''); await manualChip.click();
    // Same readiness and exact-chip oracle as the corrected settings-stop-read prefix.
    await check(providerList).toHaveAttribute('aria-busy', 'false'); await check(next).toHaveAttribute('aria-busy', 'false');
    for (const model of ['fixture/01', 'fixture/02']) {
      await check(add(model)).toBeEnabled(); await add(model).click();
      await check(chips.getByRole('button', { name: `Remove selected ${model}`, exact: true })).toBeVisible();
    }
    await check(chips.getByRole('listitem')).toHaveCount(2); await check(next).toBeEnabled(); await next.click();
    await check(wizard.getByRole('button', { name: 'Save models', exact: true })).toBeVisible();
    await check(wizard.getByRole('button', { name: 'Save & connect', exact: true })).toBeDisabled();
    assert.deepEqual(unexpected, []); assert.deepEqual(errors, []);
    assert.equal(refreshed, 1); assert.equal(held, 1); assert.equal(completedHeld, 1);
    assert.equal(Object.keys(counts).some(key => key.startsWith('PUT ') || key.includes('/model-test/')), false);
    console.log('SOURCE_ADD_SETTLED ' + JSON.stringify({ classification: 'PASS_SOURCE_NATIVE_NOT_PG', manualSelectedAndRemoved: true, selected: ['fixture/01', 'fixture/02'], reviewReached: true, counts, unexpected, errors, modelStarts: 0, modelSaves: 0 }));
  } finally {
    gate.resolve(); await context?.unrouteAll({ behavior: 'wait' }); await context?.close(); await browser?.close();
    await new Promise((resolve, reject) => server.httpServer.close(error => error ? reject(error) : resolve()));
  }
});
