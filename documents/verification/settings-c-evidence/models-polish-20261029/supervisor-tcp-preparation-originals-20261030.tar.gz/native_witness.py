"""Adapted independent witness: private installed TCP, receive-only telemetry."""
import json
import os
from pathlib import Path
import select
import sys
import threading
import time


def main():
    fd = int(sys.argv[1])
    output = Path(sys.argv[2])
    inert = sys.argv[3:] == ['--inert']
    if not inert and (sys.argv[3:] or output != Path('/run/omnis-control/sol-events.jsonl')):
        raise ValueError('WITNESS_SCOPE_REFUSED')
    writer = output.open('x')
    os.chmod(output, 0o600)
    lock = threading.Lock()
    targets = {}
    stopped = threading.Event()
    count = 0
    overflow = False

    def emit(kind, **fields):
        nonlocal count, overflow
        row = dict(kind=kind, mono_ns=time.monotonic_ns(), wall_ns=time.time_ns(),
                   observer_pid=os.getpid(), **fields)
        with lock:
            if count >= 30000:
                overflow = True
                return
            writer.write(json.dumps(row, separators=(',', ':')) + '\n')
            writer.flush()
            count += 1

    def backend():
        connection = None
        try:
            import psycopg
            from omnis.core.db import validated_database_url
            url = validated_database_url(os.environ['OMNIS_DATABASE_URL'])
            if (url.host, url.port, url.username, url.database) != ('db', 5432, 'omnis', 'omnis'):
                raise ValueError('WITNESS_DB_SCOPE_REFUSED')
            connection = psycopg.connect(host=url.host, port=url.port, user=url.username,
                                         password=url.password, dbname=url.database,
                                         autocommit=True, connect_timeout=2,
                                         options='-c default_transaction_read_only=on -c statement_timeout=500')
            row = connection.execute("SELECT system_identifier::text, current_setting('server_version'), current_setting('fsync'), current_setting('synchronous_commit'), current_setting('default_transaction_read_only') FROM pg_control_system()").fetchone()
            emit('independent_private_db', system_identifier=row[0], version=row[1],
                 fsync=row[2], synchronous_commit=row[3], read_only=row[4])
            while not stopped.wait(.05):
                with lock:
                    pids = list(targets)
                if not pids:
                    continue
                began = time.monotonic_ns()
                rows = connection.execute("SELECT pid,backend_start,state,wait_event_type,wait_event,clock_timestamp(),query_start,xact_start,pg_blocking_pids(pid),CASE WHEN upper(btrim(query)) IN ('COMMIT','ROLLBACK') THEN upper(btrim(query)) ELSE 'OTHER' END FROM pg_stat_activity WHERE pid=ANY(%s)", (pids,)).fetchall()
                for row in rows:
                    emit('native_backend_sample', backend_pid=row[0], backend_start=row[1].isoformat(),
                         state=row[2], wait_type=row[3], wait=row[4], db_now=row[5].isoformat(),
                         query_start=row[6].isoformat() if row[6] else None,
                         xact_start=row[7].isoformat() if row[7] else None,
                         blocking_pids=row[8], query_class=row[9], sample_begin_ns=began)
        except BaseException as error:
            emit('independent_backend_error', error_type=type(error).__name__)
        finally:
            if connection is not None:
                connection.close()

    thread = None if inert else threading.Thread(target=backend, daemon=True)
    if thread:
        thread.start()
    emit('independent_process_ready', inert=inert)
    print('SOL_WITNESS_READY', flush=True)
    buffer = b''
    last = time.monotonic_ns()
    deadline = last + 400_000_000_000
    try:
        while time.monotonic_ns() < deadline:
            ready, _, _ = select.select([fd], [], [], .05)
            now = time.monotonic_ns()
            emit('independent_process_progress', gap_ns=now-last, process_cpu_ns=time.process_time_ns())
            last = now
            if not ready:
                continue
            data = os.read(fd, 65536)
            if not data:
                break
            buffer += data
            while b'\n' in buffer:
                packet, buffer = buffer.split(b'\n', 1)
                if len(packet) > 4096:
                    raise ValueError('WITNESS_PACKET_LIMIT')
                row = json.loads(packet)
                pid = row.get('backend_pid')
                if type(pid) is int and pid > 0:
                    with lock:
                        targets[pid] = row['mono_ns']
                        # Only the bounded fixture's most recent backend identities.
                        if len(targets) > 32:
                            del targets[min(targets, key=targets.get)]
                emit('native_event_received', event=row)
            if len(buffer) > 4096:
                raise ValueError('WITNESS_PACKET_LIMIT')
        else:
            raise TimeoutError('WITNESS_DEADLINE')
    finally:
        stopped.set()
        if thread:
            thread.join(timeout=3)
        emit('independent_process_settled', thread_alive=bool(thread and thread.is_alive()),
             partial_packet=bool(buffer), overflow=overflow)
        writer.close()
        os.close(fd)
    return 2 if overflow or buffer or (thread and thread.is_alive()) else 0


if __name__ == '__main__':
    try:
        code = main()
    except BaseException:
        print('SOL_WITNESS_REFUSED', file=sys.stderr)
        code = 2
    raise SystemExit(code)
