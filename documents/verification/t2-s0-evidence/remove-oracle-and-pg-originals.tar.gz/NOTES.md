# Remove negative-control repair — SOURCE-only candidate

## Scope and result
- Entry HEAD: b4ccdb5df14d08a2309cefc3c4d6c31c9592b4cf. Parent advanced HEAD to 13a0b9d0825ec4b0dda18f7521f26101a861cf2c while this task ran, adding only the second canonical failure evidence. The owned file's HEAD blob is unchanged across those commits: c340dee15808bda50fa97d9dac330705e1f43bcb.
- Sole repository modification: api/tests/test_model_test_v2.py, +2 lines at the existing model_record_v2 negative-control branch. No commit/staging by this child.
- Requirement -> existing Remove overlap negative control -> a retained shared record can be mislabelled foreign -> make the synthetic canary's identity foreign, not change ownership/permitted write sets.
- This is the second admitted minimal harness-only repair on the existing S0 row; not a new harness project or a reset of that counter. No PG/native/provider/target/operator effects, no canonical rerun.

## Diagnosis
The exact nested unchanged_except_start helper follows Operation.config_snapshot_ref -> model-entry-snapshot-v1.capabilities_ref -> model-entry-capabilities-v1.catalog_ref. provider_model_test.prepare reuses the catalog-result selected by catalog_command_id. Consequently, an older catalog record can legitimately belong to the new operation's reference closure. The original negative control changes only payload.unrelated_bait and preserves the entire typed identity tuple. If this shared record is first in history, the added row is classified owned and pytest.raises fails. If an unreferenced older projection is first, the same control succeeds.

The minimal correction gives only the synthetic model_record_v2 canary a fresh UUID id before retaining the original bait mutation. The original referenced row remains intact in the census. No production resolver, permitted-write set, assertion, timeout, skip, replay, Cancel/Stop or sink rule changed.

The historical canonical failure does not print its selected table/row. This reproduces a source-established failure mechanism, not the historical row identity and not a production RED. The original quiet and real-overlap assertions precede the failing negative challenge; later cancellation/settlement assertions were NOT_REACHED in that run. Earlier no-write attribution findings remain separate; this fix does not retrospectively certify their reachability or the full gate.

## Reproduction and isolation
- test_remove_oracle_source.py compiles the exact nested oracle and exact record-challenge body from the current repository file. The effectful test body is never executed by this reproduction.
- Operation, Ref, EntrySnapshot, EntryCapabilities, CatalogResult, ConnectionRevision, ModelEntry and Projection use actual Pydantic models; record digests use the existing pure digest function. Synthetic row JSON preserves migration 0015 column ordering (instance_id, id, kind, ...), allowing fixed IDs to select both possible history orders.
- Both order cases first exercise a quiet census and an owned PENDING->RUNNING/state_revision transition plus own start-command insertion. The shared catalog is reached through actual typed references. A same-instance unreferenced record with operation-ID bait is rejected. Thirteen additional foreign-instance canaries challenge all census tables; these are synthetic oracle row deltas, not valid SQL inserts or actual PG observations.
- Existing SOURCE regressions selected: production-consumer presence, cancel_observation, retained latest-entry projection, and generation admission with an explicit refusal before writes. Their fixtures are absent or monkeypatch-only. The module's PG fixture is not autouse; no migrated_database_url was executed.
- Commands run in bwrap --unshare-all --clearenv, isolated network (only lo), restricted read-only source/interpreter mounts, private HOME/TMPDIR/cache, no DB credentials/socket mount. API candidate venv has OpenAI 2.45.0, pytest 9.1.1, Ruff 0.16.9, mypy 2.3.1. Exact argv/exit are saved per command in JSON, stdout/stderr separately.

## Results
- collect-source-exact-tables: 16 collected, exit 0.
- source-red-two-orders: 1 failed / 15 passed, exit 1. Only shared-first fails with DID NOT RAISE AssertionError at original line1625.
- source-green: 16 passed, exit 0, same source-cut tests after the two-line fix.
- source-regressions: 4 passed, exit 0.
- ruff-check, ruff-format, mypy: exit 0 on api/tests/test_model_test_v2.py; strict repository mypy configuration, no-incremental.
- collect-remove-target: 4 cases, exit 0 (three schema parameters plus entry_remove). COLLECTION ONLY, not PG acceptance.
- git diff --check: exit 0. Whole-file AST comparison removing only the new id assignment equals the original AST: all 345 assert statements and all original control flow preserved. candidate.json contains file/blob/diff/reproducer hashes; minimum.diff is the review delta.

## Retained unsuccessful preparation attempts
- Initial bwrap interpreter launch refused because the venv symlink used the cpython-3.13 alias, while only the resolved cpython-3.13.15 directory was mounted. Added that exact alias inside the sandbox; no host/interpreter changes.
- Initial AST discovery selected another tables assignment. Restricted it to the literal tuple; no test body ran during that collection failure.
- Initial synthetic record JSON followed Ref field order (kind before id), so the foreign-first setup assertion failed. Bound serialization order to actual migration0015 column order; source-red-two-orders is the valid deterministic RED. Earlier outputs remain saved; they are preparation failures, not product failures.

## Handoff
Independent focused review and the parent's existing bounded test-settings-remove-pg target remain NOT_RUN. No broad gate is claimed GREEN. The original canonical log is untouched; canonical-failure-excerpt.txt preserves lines1833-1981. Source before-image, exact commands, exits and diff are retained here. Separately updated the loaded global systematic-debugging reference with the general shared-history negative-canary lesson; no other repository path changed.
