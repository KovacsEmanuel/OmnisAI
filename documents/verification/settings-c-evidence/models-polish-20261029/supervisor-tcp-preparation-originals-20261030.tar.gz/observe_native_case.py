"""Adapted receive-only readback of the existing native observer's same-cycle events."""
import json
from pathlib import Path


def summarize(path):
    path = Path(path)
    if path.stat().st_size > 32 * 1024 * 1024:
        raise ValueError('OBSERVATION_LIMIT')
    rows = [json.loads(line) for line in path.read_text().splitlines()]
    events = [row['event'] for row in rows if row['kind'] == 'native_event_received']
    identities = [row for row in events if row['kind'] == 'native_identity']
    settled = [row for row in rows if row['kind'] == 'independent_process_settled']
    if len(identities) != 1 or len(settled) != 1:
        raise ValueError('OBSERVATION_IDENTITY_OR_CLOSURE_MISSING')
    if settled[0]['thread_alive'] or settled[0]['partial_packet'] or settled[0]['overflow']:
        raise ValueError('OBSERVATION_INCOMPLETE')
    if not events or events[-1]['kind'] != 'native_observer_end':
        raise ValueError('OBSERVATION_END_MISSING')
    if any(row['dropped'] for row in events) or any(b['seq'] != a['seq'] + 1 for a, b in zip(events, events[1:])):
        raise ValueError('OBSERVATION_DROPPED')
    if any(row['kind'] == 'independent_backend_error' for row in rows):
        raise ValueError('BACKEND_OBSERVER_FAILED')
    if any(row['kind'] == 'forbidden_provider_boundary' for row in events):
        raise ValueError('PROVIDER_BOUNDARY_REACHED')
    metadata = [row for row in rows if row['kind'] == 'independent_private_db']
    if len(metadata) != 1 or metadata[0]['read_only'] != 'on':
        raise ValueError('READ_ONLY_DB_WITNESS_MISSING')
    if not any(row['kind'] == 'real_model_owner_constructed' for row in events):
        raise ValueError('REAL_MODEL_OWNER_MISSING')
    if not any(row['kind'] == 'model_owner_callback_return' for row in events):
        raise ValueError('MODEL_OWNER_CALLBACK_MISSING')
    samples = [row for row in rows if row['kind'] == 'native_backend_sample']
    if not samples:
        raise ValueError('BACKEND_SAMPLES_MISSING')
    spans = []
    for begin in events:
        if begin['kind'] != 'driver_commit_begin' or not str(begin['tag']).startswith('heartbeat:'):
            continue
        same = [row for row in events if (row['pid'], row['cycle'], row['tag']) == (begin['pid'], begin['cycle'], begin['tag'])]
        endings = [row for row in same if row['kind'] in {'driver_commit_success', 'driver_commit_error', 'driver_commit_cancel'} and row['mono_ns'] >= begin['mono_ns']]
        if not endings:
            spans.append(dict(cycle=begin['cycle'], tag=begin['tag'], outcome='NOT_RETURNED'))
            continue
        end = endings[0]
        correlated = [row for row in samples if row['backend_pid'] == begin['backend_pid'] and begin['mono_ns'] <= row['mono_ns'] <= end['mono_ns']]
        spans.append(dict(cycle=begin['cycle'], tag=begin['tag'], backend_pid=begin['backend_pid'],
            outcome=end['kind'], elapsed_ns=end['mono_ns']-begin['mono_ns'],
            protocol_success=any(row['kind'] == 'protocol_COMMIT_success' and row['backend_pid'] == begin['backend_pid'] for row in same),
            pool_checkin=any(row['kind'] == 'pool_checkin' and row['backend_pid'] == begin['backend_pid'] and row['mono_ns'] >= end['mono_ns'] for row in same),
            service_return=any(row['kind'] == 'service_return' for row in same),
            loop_progress=sum(row['kind'] == 'native_loop_progress' and begin['mono_ns'] <= row['mono_ns'] <= end['mono_ns'] for row in events),
            independent_progress=sum(row['kind'] == 'independent_process_progress' and begin['mono_ns'] <= row['mono_ns'] <= end['mono_ns'] for row in rows),
            backend_samples=[{key: row[key] for key in ('mono_ns', 'sample_begin_ns', 'backend_start', 'state', 'wait_type', 'wait', 'query_class', 'query_start', 'xact_start', 'blocking_pids')} for row in correlated]))
    if not any(row.get('protocol_success') and row.get('pool_checkin') and row.get('service_return') and row['outcome'] == 'driver_commit_success' for row in spans):
        raise ValueError('CLIENT_PROTOCOL_POOL_SUCCESS_NOT_OBSERVED')
    slow = [row for row in spans if row.get('elapsed_ns', 0) >= 2_000_000_000 or row['outcome'] == 'NOT_RETURNED']
    return dict(cause='UNKNOWN', multisecond_reproduced=bool(slow),
                heartbeat_commits=len(spans), slow_spans=slow,
                max_commit_ns=max(row.get('elapsed_ns', 0) for row in spans),
                receipt_clock='outer mono_ns/wall_ns', occurrence_clock='event mono_ns/wall_ns',
                decision='STOP; no second diagnostic or product remedy without causal evidence')
