"""SOURCE-only synthetic reproduction; never imports or calls the PG test body."""

import ast
import json
from datetime import UTC, datetime
from pathlib import Path
from types import SimpleNamespace
from uuid import UUID, uuid4

import pytest

from omnis.modules.runs.model_test_contract import (
    EntryCapabilities,
    EntrySnapshot,
    Operation,
    Projection,
    Ref,
)
from omnis.modules.runs.model_test_store import digest
from omnis.modules.settings.provider_catalog_models import CatalogModel
from omnis.modules.settings.provider_catalog_runtime import CatalogResult
from omnis.modules.settings.provider_key_service import ConnectionRevision
from omnis.modules.settings.provider_model_models import ModelEntry

SOURCE = Path("/home/kali/OmnisAI/api/tests/test_model_test_v2.py")
TREE = ast.parse(SOURCE.read_text())
TABLES_NODE = next(
    node for node in ast.walk(TREE)
    if isinstance(node, ast.Assign) and isinstance(node.value, ast.Tuple)
    and any(isinstance(target, ast.Name) and target.id == "tables" for target in node.targets)
)
TABLES = ast.literal_eval(TABLES_NODE.value)
assert len(TABLES) == 13
ORACLE = next(
    node for node in ast.walk(TREE)
    if isinstance(node, ast.FunctionDef) and node.name == "unchanged_except_start"
)
CHALLENGE = next(
    node for node in ast.walk(TREE)
    if isinstance(node, ast.For)
    and isinstance(node.target, ast.Name) and node.target.id == "table"
    and any(isinstance(child, ast.Name) and child.id == "challenged" for child in ast.walk(node))
)


def case(shared_first):
    instance, identity = str(UUID(int=100)), str(UUID(int=101))
    connection = ConnectionRevision(
        connection_id=str(UUID(int=102)), provider="openrouter", revision=1,
        enabled=True, secret_id=str(UUID(int=103)), credential_revision=1,
    )
    entry = ModelEntry(
        connection_id=connection.connection_id, connection_revision=1,
        model="fixture/selected", output_tokens=64, entry_id=str(UUID(int=104)), revision=1,
    )
    catalog = CatalogResult(
        command_id=str(UUID(int=105)), connection=connection, state="READY", reason=None,
        entries=[CatalogModel(model=entry.model, max_output_tokens=64, supports_max_tokens=True)],
    )
    records = []

    def record(kind, number, payload):
        value = payload.model_dump(mode="json")
        ref = Ref(instance_id=instance, id=str(UUID(int=number)), kind=kind, digest=digest(value))
        row = {
            "instance_id": ref.instance_id, "id": ref.id, "kind": ref.kind,
            "revision": ref.revision, "digest": ref.digest, "payload": value,
            "created_at": "2026-01-01T00:00:00+00:00",
        }
        records.append(json.dumps(row))
        return ref

    catalog_ref = record("catalog-result", 1 if shared_first else 9, catalog)
    shared = records[-1]
    record("model-projection-v2", 9 if shared_first else 1, Projection(model=entry.model, output_tokens=64))
    unrelated = records[-1]
    capability_ref = record(
        "model-entry-capabilities-v1", 10,
        EntryCapabilities(entry=entry, connection=connection, catalog_ref=catalog_ref, max_output_tokens=64),
    )
    config_ref = record(
        "model-entry-snapshot-v1", 11,
        EntrySnapshot(entry=entry, connection=connection, capabilities_ref=capability_ref, endpoint="https://openrouter.ai/api/v1"),
    )
    projection_ref = record("model-projection-v2", 12, Projection(model=entry.model, output_tokens=64))
    operation = Operation(
        instance_id=instance, operation_id=identity, command_id=identity, payload_digest=digest({}),
        config_snapshot_ref=config_ref, input_projection_ref=projection_ref,
        execution_owner_id=str(UUID(int=106)), generation=1, owner_epoch=1, cancel_epoch=1,
        deadline=datetime(2026, 1, 1, tzinfo=UTC), state_revision=1, state="PENDING",
        finish_reason=None, outcome_ref=None,
    )
    before = {table: [] for table in TABLES}
    before["model_record_v2"] = sorted(records)
    before["system_operation"] = [operation.model_dump_json()]
    after = {table: list(rows) for table, rows in before.items()}
    after["system_operation"] = [Operation.model_validate_json(json.dumps({
        **operation.model_dump(mode="json"), "state_revision": 2, "state": "RUNNING",
    })).model_dump_json()]
    after["model_command_v2"] = [json.dumps({
        "instance_id": instance, "operation_id": identity, "command_id": identity, "action": "start",
    })]
    namespace = {
        "json": json, "pytest": pytest, "uuid4": uuid4,
        "initial": SimpleNamespace(instance_id=UUID(instance)), "tables": TABLES,
        "identity": identity, "first_snapshot": before, "final_snapshot": after,
        "history": {"model_record_v2": sorted([shared, unrelated])}, "table": "model_record_v2",
    }
    exec(compile(ast.Module(body=[ORACLE], type_ignores=[]), str(SOURCE), "exec"), namespace)
    return namespace


@pytest.mark.parametrize("shared_first", [True, False], ids=["shared-first", "foreign-first"])
def test_exact_negative_control(shared_first):
    ns = case(shared_first)
    check = ns["unchanged_except_start"]
    check(ns["first_snapshot"], ns["first_snapshot"], ns["identity"])
    check(ns["first_snapshot"], ns["final_snapshot"], ns["identity"])
    selected = json.loads(ns["history"]["model_record_v2"][0])
    assert (selected["kind"] == "catalog-result") == shared_first
    # Exact existing record mutation and pytest.raises, not a reimplementation.
    exec(compile(ast.Module(body=CHALLENGE.body, type_ignores=[]), str(SOURCE), "exec"), ns)


@pytest.mark.parametrize("table", TABLES)
def test_foreign_bait_is_rejected_in_every_table(table):
    ns = case(True)
    foreign = {"instance_id": str(UUID(int=999)), "operation_id": ns["identity"], "unrelated_bait": ns["identity"]}
    after = {**ns["final_snapshot"], table: [*ns["final_snapshot"][table], json.dumps(foreign)]}
    with pytest.raises(AssertionError, match=table):
        ns["unchanged_except_start"](ns["first_snapshot"], after, ns["identity"])


def test_unreferenced_record_with_bait_is_rejected():
    ns = case(True)
    row = json.loads(ns["history"]["model_record_v2"][0])
    row["id"] = str(UUID(int=999))
    row["payload"]["unrelated_bait"] = ns["identity"]
    after = {**ns["final_snapshot"], "model_record_v2": [*ns["final_snapshot"]["model_record_v2"], json.dumps(row)]}
    with pytest.raises(AssertionError, match="model_record_v2"):
        ns["unchanged_except_start"](ns["first_snapshot"], after, ns["identity"])
