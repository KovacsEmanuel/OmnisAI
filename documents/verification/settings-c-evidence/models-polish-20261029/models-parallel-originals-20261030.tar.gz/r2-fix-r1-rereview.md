# R1 re-review focalizat — remediu R2-F01

## Verdict: APPROVED_SCOPED

**Niciun blocker concret identificat în delta exactă `db6ab2bc4ff04f71cb101ca4f815fb74ccae0bd7` → `e730e3f002c9675835b8690f856e7856e31f9373`.** Remediul păstrează FINISHED deja citit înainte de recuperarea operației active distincte și păstrează protecția healthy direct-Test a aceleiași operații. Aprobarea este SOURCE/scoped; nu este QA browser/API/PG, acceptare instalată sau închidere T1/T2. După clearance-ul complementar și preflightul părintelui, permite QA healthy reală afectată; lipsa acelei QA nu este o prerechizită circulară pentru aprobarea codului.

## FREEZE verificat independent

- Checkout: `/home/kali/.hermes/cache/scratch/settings-inline-feedback-20261029`; branch `feat/settings-inline-feedback-20261029`.
- HEAD: `e730e3f002c9675835b8690f856e7856e31f9373`; tree: `1b458b1b56ddb03d14e78d0ebd98c55b8b5041cf`.
- Numai două căi în deltă, **+73/−4**: Page +9/−4, test +64/−0.
- `web/src/features/engagement/SettingsModelsPage.tsx`: blob HEAD/working-tree `5d05eb66e205fa4b076ab0bde8e6c822eeca5654`; SHA256 `212360c6ef12e619d94716718c6a2cff3924051c612d6591b7c417d0b79390e2`.
- `web/src/app/SettingsWizard.test.tsx`: blob HEAD/working-tree `7baea788b1a645ea68a8be5ee3f4065718c15a2f`; SHA256 `896a9fb52615b7381f4236ff2afce710948bf4b106b8ac6391724bff52af6e6d`.
- Diff binar generat independent, byte-equal cu `astra-evidence/r2-fix.delta.diff`: SHA256 `bfc792b7f72b5c1c3a7af6027c8d16d1280bf35996fed0ec5a8a559fe4dc9160`. Coincide cu manifestul CURRENT `astra-evidence/freeze.json`.
- Wizard blob `a9ddccfa4867aef0f3352c2f6eab01a18acca769`, E2E blob `f9436bdb7d9fb6dd0ffad165806b561e7e9726ac`: neschimbate, hashurile working-tree coincid cu freeze-ul. Testul simplu `SOURCE healthy direct Test` este byte-identic între db6 și e730, verificat separat prin extragerea blocului Git.
- Artefactele existente coincid cu freeze-ul: `web/dist/omnis-web.json` SHA256 `649e1593f6c330e62e56a8c513331106d09aeb8fb34237cdfb2c9b4435ebdf14`; `web/dist/assets/index-k_w5N4AQ.js` SHA256 `71b2d0c1070ff9f772bbf66fbee051eced9c8db20312236799620261b98e0a26`. Aceasta este numai identitate de artefact, nu execuție de browser.
- Tracked/index curate la inspecție; numai cele patru symlinkuri untracked preexistente `api/.venv`, `cli/.venv`, `tools/development/anti-slop/node_modules`, `web/node_modules`. `lstat/readlink` confirmă tipul/țintele din freeze; fără dereferențiere pentru cleanup, adoptare, înlocuire sau ștergere.

Comenzile proprii de integritate: `git status --short --branch`, `git rev-parse HEAD HEAD^{tree}`, `git show --stat --oneline HEAD`, `git diff --binary/--numstat/--stat`, `git diff --check db6ab2bc4ff04f71cb101ca4f815fb74ccae0bd7 e730e3f002c9675835b8690f856e7856e31f9373 --`, diff working-tree/index, `git hash-object` pentru căile declarate și comparații SHA256 cu Python stdlib; toate invocările au terminat exit0.

## Cerință → consumator → risc → decizie

Cerință: FINISHED autoritativ nu poate fi reseed-uit RUNNING, iar B activă distinctă trebuie să păstreze Cancel/readback și să nu reactiveze A după terminal. Consumator: App → ProviderSettings → SettingsModelsPage, query-ul exact scope+operation și biblioteca existentă. Risc: Reload întârziat publică A RUNNING2 înaintea B RUNNING2; alegerea oprește căutarea la A sau, după Cancel B, reselectează istoria stale A. Decizie: aprobarea remediului SOURCE ori un finding concret înaintea QA reale healthy.

Am citit originalele `direct-terminal-r1-review.md`, `direct-terminal-r2-review.md`, CURRENT din `astra-result.md`, freeze-ul și delta nouă, CURRENT/CONTRIBUTING/team-slice și rândul afectat al hărții, fără modificarea lor. Contractul afectat este `web/design/settings-final.md:25–39,46,54–56,88–92,136–142`.

Traseu urmărit: callerul unic `ProviderSettings.tsx:20–22` (mount pe scope); `SettingsModelsPage.tsx:56–123,157–164,252–335,424–454,512–527`; `shared/api/client.ts:74–102`; decoderul `shared/api/modelTest.ts:49–63`; `SettingsModels.ts:17–42`; fixture-ul HTTP existent `web/tests/settings-fixtures.ts:17–38`. Pentru semantica current am citit numai sursa `api/src/omnis/modules/runs/model_test_runtime.py:195–262` și `settings/provider_model_test.py:19–28`, fără a apela backendul/DB. Nu sunt necesare schimbări în fixture/config/export/API; remediul rămâne în efectul comun de hidratare și testul App existent.

| Criteriu | Cod/dovadă și evaluare R1 |
|---|---|
| Same-operation FINISHED nu este suprascris din RUNNING local | `SettingsModelsPage.tsx:118` exclude ID-ul deja selectat chiar în predicat; nicio scriere în query-ul său prin acest seed. Reconcilierea `:113–116` păstrează terminalul deja observat în biblioteca existentă, apoi revine la selecție la următoarea schimbare de date. Regresia healthy originală `SettingsWizard.test.tsx:684–735` rămâne neschimbată și inclusă în verificarea finală. **Păstrat SOURCE.** |
| A stale nu maschează B activă | `:118–121` caută primul candidat activ distinct, nu primul activ urmat de un refuz al întregii căutări. Barierele `operationPending/sending/connecting` rămân înaintea reconcilierii/selecției. Testele pereche `:1039–1102` cer GET exact B și Cancel/Read vizibile cu details închise. **R2-F01 remediat în reproducerul afectat.** |
| Cancel B nu reactivează A terminală | A FINISHED3 este păstrată înaintea schimbării selecției spre B. După Cancel, B FINISHED4/CANCELLED și A FINISHED3 nu mai oferă candidați activi stale. Testul cere biblioteca terminală pentru ambele, A Connected, niciun Cancel rămas și număr GET A neschimbat; GET-ul A neașteptat este ținut tocmai ca rereadul să nu ascundă defectul. **Continuarea afectată verificată SOURCE.** |
| Fără promovare unsafe din current/revizii vechi | Noua reconciliere cere FINISHED observat, același `operation_id` în slotul entry și `previous.state_revision < observed.state_revision`, ambele nenule. Nu înlocuiește prin această ramură operație distinctă, revizie egală/mai nouă, null sau UNKNOWN; nu fabrică terminal/current și nu modifică entries/settings/evidence. `exactCheck` păstrează current, entry/revision, connection/revision, provider/model/cap, iar `entryStatus` păstrează conexiunea curentă și disponibilitatea catalogului. Un observed current=false rămâne false; un rezultat vechi nu poate satisface reviziile unei configurații schimbate. Pe server, current este derivat din egalitatea snapshotului entry/conexiune cu registry/connections, nu din state_revision. **Nicio cale nouă concretă de false Connected identificată.** Acesta nu este un certificat general pentru orice ordine HTTP ori pentru efectul de proiecție preexistent. |
| Healthy real fără workaround | Consumatorul E2E existent `web/tests/e2e/settings-models.mjs:227–249` păstrează primul Connected, al doilea Test direct → Connected automat, două Starts distincte, apoi exact/latest FINISHED/COMPLETED/current/identități/cap64. Nu s-au adăugat Stop/Read manual, timeout sau relaxări. **Cerința reală rămâne deschisă pentru QA pe e730, nu declarată PASS prin SOURCE.** |

Nu apar owner/cache/timer noi, dispatch/retry/resend, schimbări Stop/deadline/polling/generation, CAS sau validare. Noua scriere de cache nu este Start ori Cancel; Cancel păstrează ID-ul selectat și revizia exact observată la `readTest`. Reconcilierea se stabilizează după păstrarea reviziei terminale, fără încă un mecanism de recovery.

## Originale executate de autor, inspectate fără rerulare

Am citit metadata argv/cwd/returncode/timestamps și outputurile originale `astra-evidence/r2-fix-*`, inclusiv diagnosticile FAIL și gate-urile finale. Nu revendic o execuție independentă a acestor teste.

- `r2-fix-red`: `npm test -- src/app/SettingsWizard.test.tsx -t 'SOURCE R2 delayed library'`, exit1, **1FAIL/1PASS/109skipped**. Diagnostic: exactA FINISHED, libraryA/B RUNNING, exactBReads0, cancelButtons0, writes[]. Reproduce findingul inițial, nu lipsa terminalului A.
- `r2-fix-predicate-only`: aceeași comandă, exit1, **1FAIL/1PASS**; B recuperată/anulată, dar GET A crește 3→4. Nu este remediul acceptat.
- `r2-fix-continuation-red`: aceeași comandă și pereche, exit1, **1FAIL/1PASS**; cu GET A neașteptat ținut: exactA/libraryA RUNNING, libraryB FINISHED, cancelButtons1, numai Cancel B/expected_state_revision2. Confirmă necesitatea păstrării terminalului înainte de switch, în aceeași clasă de defect.
- `r2-fix-green`: selecția `SOURCE R2 delayed library|SOURCE healthy direct Test`, exit0, **3PASS/108skipped**; dovadă intermediară, nu singura probă pentru bytes finali.
- Primul `r2-fix-lint`: exit1, warning `react-hooks(exhaustive-deps)` pentru updateCheck. În delta finală scrierea folosește direct QueryClient existent, dependențele sunt declarate, fără ignore/cast sau gate slăbit. Probe intermediare păstrate, nu transferate drept final.
- **După ultima editare**, `r2-fix-regression-final.command.json` confirmă cwd `.../settings-inline-feedback-20261029/web`, argv cu npm absolut `/home/kali/.local/share/omnis-toolchains/bin/npm`, 10:14:37.035936–10:14:59.191422Z, exit0, **37PASS/74skipped**, stderr gol. Comanda exactă:

```text
npm test -- src/app/SettingsWizard.test.tsx -t 'SOURCE R2 delayed library|SOURCE healthy direct Test|recovers the actual active check|expands history without replacing|remote UNKNOWN|manual read uncertainty|ends the unsent sequence|does not claim Connected|orphan RUNNING Cancel|SOURCE missing local projection|Save & connect waits|preserves receive-only recovery for an orphan|never resurrects an older stored green'
```

- `r2-fix-lint-final`: `npm run lint`, exit0, 10:14:59.191807–10:15:00.254905Z.
- `r2-fix-typecheck-final`: `npm run typecheck`, exit0, 10:15:00.255285–10:15:06.828841Z.
- `r2-fix-build-final`: `npm run build`, exit0, 10:15:06.829164–10:15:15.470936Z; outputul confirmă check:contracts/check:design/tsc/Vite/build-manifest, assetul nou din freeze. Toate stderr-urile finale sunt goale.

Regresia pereche nu injectează terminalul în QueryClient: întârzie răspunsurile HTTP ale fixture-ului, trece prin client/decoder și App StrictMode. Înainte de click cere writes[]; după Cancel cere lista exactă cu **numai Cancel B/rev2**, B FINISHED4/CANCELLED și A Connected, fără GET/reselecție/Cancel A. Egalitatea exactă a writes exclude orice Start ori altă mutație; keys/entries sunt păstrate. Controlul false și cel stale true disting selecția normală de cursa întârziată. Nu am găsit o suspiciune concretă rămasă care să schimbe verdictul prin încă o rulare SOURCE; nu am repetat suitele doar pentru număr.

## Dispoziții și limite de acceptare

1. **R1 vechi / same-operation terminal→RUNNING:** rămâne remediat SOURCE pe bytes noi prin guardul în `find` și regresia healthy originală neschimbată.
2. **R2-F01/HIGH:** vechiul R1 APPROVED_SCOPED nu îl închidea. Pe delta nouă, reproducerul și continuarea Cancel B→A terminală au remediu discriminator și GREEN final; acest R1 **susține CLOSED_SCOPED_SOURCE**, pentru adjudecarea părintelui și reviewul complementar. Nu anulez originalul R2 sau probele RED.
3. **Predicate-only și continuation RED:** defect real al remediului incomplet, rezolvat de păstrarea FINISHED înainte de alegerea lui B, nu workaround de reread. Nu propun alt finding independent.
4. **Healthy real pe ea78ee2:** primul Connected/al doilea FAIL rămâne istoric, cauză internă **NEATRIBUITĂ**. SOURCE nu dovedește retrospectiv cauza acelei execuții.
5. **Stop-read real ea78ee2 1PASS/13.16s:** dovadă istorică scoped comunicată de părinte, nu transferată la hidratarea nouă ori la healthy fără Stop.
6. **QA healthy real pe db6/e730:** **NOT_RUN** aici și în dovezile curente inspectate. Urmează consumatorul existent `test-settings-remove-ui-pg`, numai la părinte după clearance complementar, preflight și admiterea resurselor. Sol finished2/2 și drain/no-active-fixture sunt contextul comunicat de părinte, nu verificări PG făcute de mine. Contoarele istorice nu sunt resetate; nu am adăugat cicluri harness-only sau încercări PG.

**Findings curente în delta revizuită: niciunul.** Nu există severitate/file:line/scenariu/criteriu/remediu nou de predat developerului. Limita este demonstrația SOURCE a acestor curse și callers, nu completitudine universală sau acceptarea întregului Settings.

Am creat numai acest original scratch. Fără editări produs/test/fixture/config/statusmap/skill/index, commit, agent nou, acces PG/OCI/operator/provider/model sau instalare; main nu a fost modificat, fișierele protejate nu au fost citite/hashuite/staged. Reticle NOT_INTEGRATED, Chisel BLOCKED_NO_GO; fără încărcare/instrumentare ceremonială.

Am omis rerulările full, Add/E2E neafectate ca reauditare, browserul nativ și QA API/PG/instalată; nu declar T1/T2/installed PASS.
Risc rămas: healthy real pe freeze-ul e730 trebuie încă executat și adjudecat; FAIL-ul PG istoric rămâne neatribuit, iar acest verdict nu înlocuiește reviewul complementar.
