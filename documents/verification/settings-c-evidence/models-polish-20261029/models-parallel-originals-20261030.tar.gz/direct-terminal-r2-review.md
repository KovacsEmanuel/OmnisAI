# R2 independent — direct-terminal hydration

## Verdict: CHANGES_REQUESTED_SCOPED

Un blocker concret de recuperare/Cancel, reprodus SOURCE prin App: **R2-F01 / HIGH**. Nu propun redesign și nu contest remediul cazului simplu FINISHED3 versus biblioteca RUNNING2. Guardul trebuie păstrat, dar aplicat înainte de alegerea candidatului activ, nu după primul `find()`.

Acesta este reviewul complementar de identitate/recuperare/failure, nu acceptare globală, QA reală sau atribuirea FAIL-ului PG istoric. Părintele adjudecă findingul; nu am modificat produsul sau testele pe disc.

## Identitate și limită

- Checkout: `/home/kali/.hermes/cache/scratch/settings-inline-feedback-20261029`.
- Branch: `feat/settings-inline-feedback-20261029`.
- HEAD: `db6ab2bc4ff04f71cb101ca4f815fb74ccae0bd7`.
- Tree: `74ae52e6139714df1472aca01b79395cc61a9826`.
- Bază delta: `ea78ee2705156af88f53df92549f93a99ef71149`.
- Numai două fișiere modificate în deltă: Page **3+/2−**, test **52+/0−**.
- Page blob: `a3d799db11051d14c7bc8754055b1eb736cf6c25`; SHA256 working file `5da0bf6771dc61b4df83ec0946e39857dd441fa72dacc665098d13ac367fad4c`.
- Test blob: `834934e9cc6adb97336f861a24a54accd020f6d7`; SHA256 working file `ca20a97f21c0ddedf28fcd575862862191fe57510f9d783683fabeeaf522f3fc`.
- Diff binar Git live este byte-equal cu `astra-evidence/direct-terminal.delta.diff`; SHA256 `7c91cfe788c156964110c504ccfd1ec6f381ddd0627643a86b65a55ba53d5ebd`.
- La început și după probă: tracked/index curate, identitățile de mai sus neschimbate; numai cele patru symlinkuri untracked declarate. Am citit doar `lstat/readlink` pentru ele, fără adoptare/alterare/cleanup. Nu am comis nimic.

Am citit CURRENT din README și `astra-result.md`, freeze-ul actual, delta exactă și contractul afectat `web/design/settings-final.md`. Call path analizat: `ProviderSettings` → `SettingsModelsPage`, query/hydration/projection, `startTest`, `readTest`, `readCheck`, `connectEntries`, `stopRemaining`, row controls și `operationControls`, clientul/decoderul exact și fixture-ul HTTP SOURCE existent. Wizard/Add/E2E neschimbate nu sunt reauditare aici.

Cerință → consumer → risc → decizie: Cancel/readback trebuie să rămână legate de operația efectiv activă, inclusiv după o bibliotecă întârziată → App și controalele contextuale ale modelului → primul snapshot stale ascunde o admitere distinctă → finding pentru fix minimal înainte de aprobarea acestei cerințe.

## R2-F01 — un candidat stale egal cu operația selectată maschează o operație activă distinctă

**Severitate:** HIGH, pierdere de acces contextual la Cancel/readback pentru o operație activă. Nu am observat anularea altei operații sau retrimiterea unui Start.

**Loc:** `web/src/features/engagement/SettingsModelsPage.tsx:112–118`; contribuie proiecția `:153–159` și consumatorul `:420–438`.

**Reproducer legal la frontiera UI/HTTP:**

1. A este selectată și RUNNING; B este un alt model, fără operație încă. A și B sunt în bibliotecă, A prima în `checks`.
2. Operatorul cere Reload. `load()` citește latest per-entry, în paralel, fără un snapshot comun: răspunsul lui A capturează RUNNING2 și este întârziat. Răspunsul latest B este întârziat până după admiterea lui B.
3. Pollul exact pentru A ajunge FINISHED3. Înainte de încheierea Reload, query-ul A și rândul său ajung terminal/Connected. Numai după acest terminal devine B RUNNING2 (de exemplu, admitere explicită din altă filă). Nu este nevoie de două operații active simultan la producer.
4. Reload întârziat publică `{ A: RUNNING2, B: RUNNING2 }`, deși query-ul A rămâne FINISHED3.
5. `find()` alege A; guardul nou refuză A deoarece are ID-ul deja selectat, dar nu caută mai departe B. Proiecția observed→library nu mai rulează: `observed`, `connecting`, `testUnknown`, `test.isError` nu s-au schimbat odată cu biblioteca. Query-ul A este terminal, deci nici pollingul său nu mai produce progres.
6. B afișează **Connecting** cu Test disabled, dar **fără Cancel și fără readback contextual vizibil cu details închise**. Nu s-a făcut niciun GET exact B. Există un Read în details ascunse; acesta este un workaround prin selecție manuală, nu recuperarea activă cerută de contract.

**Criteriu încălcat:** `web/design/settings-final.md:46,54–56,88–90,139–140`: active Cancel/same-operation readback rămân accesibile și în afara istoricului/disclosure; hidratarea fresh/recuperarea selectează operația activă, fără ca istoricul să o mascheze.

**Dovadă executată pe bytes actuali:** o singură invocare Vitest4.1.12, App în StrictMode + `settingsBackend`, două controale parametrizate. Diagnostic adăugat exclusiv în memoria transformării Vite a modulului test existent; nicio editare de fișier, nicio substituire a componentei produsului, cache dezactivat. `config:false` evită generarea configului în dependențele comune; opțiunile jsdom/setup/React sunt cele existente.

- `stale-selected=false`: **PASS**, 1295ms; aceeași ordine, dar răspunsul A al Reload este terminal. B primește Cancel.
- `stale-selected=true`: **FAIL**, 1887ms, la `findByRole('button', { name: 'Cancel test' })` din rândul B.
- Runner: **1PASS / 1FAIL / 109skipped**, duration5.31s, exit1; wrapperul Python a păstrat același return code1.
- Observația originală din `R2_DELAYED_LIBRARY`:

| Câmp | Observat |
|---|---|
| exact A | `aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa`, FINISHED, revision3, COMPLETED |
| library A | același ID A, RUNNING, revision2 |
| library B | `bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb`, RUNNING, revision2 |
| exactBReads | `0` |
| cancelButtons | `0` |
| writes | `[]` |

Eroare originală: `TestingLibraryElementError: Unable to find role="button" and name "Cancel test"`. DOM-ul rândului B arată `Connecting`, butonul Test `disabled`, iar Read este în `section hidden`. Acesta este FAIL discriminant de recuperare, nu timeout înaintea fazei sau lipsa terminalului A.

**Remediu minimal propus, neimplementat de reviewer:** mută excluderea `check.operation_id !== operation` în predicatul lui `find()`, astfel încât să aleagă prima operație activă **distinctă**, păstrând bariera `operationPending || sending || connecting` și interdicția de a reseeda query-ul deja selectat. Adaugă regresia întârziat-A + activ-B lângă testele existente de recuperare. Nu cere alt owner/cache/loop/timer sau relaxarea validării/CAS. Părintele/developerul verifică remediul și afectările înainte de acceptare.

**Atribuire:** am demonstrat defectul pe candidatul curent; nu am executat aceeași cursă pe ea78ee2 și nu declar că acesta este un defect exclusiv introdus de db6 sau cauza FAIL-ului PG vechi. Este însă în cerința explicită a acestui review: snapshotul stale nu trebuie să ascundă admiterea activă distinctă sub noul guard.

## Restul scope-ului R2

- `operationPending`/sending/connecting păstrează identitatea deja nesettled; hidratarea nu autorizează nici Start, nici Cancel. Query keys rămân scope+operation.
- `readTest` capturează ID-ul selectat, Cancel folosește revizia din `observed`, iar clientul/decoderul verifică UUID-ul și identitatea răspunsului exact. `readCheck` blochează schimbarea pe istoric cât timp operația este pending. Nu am identificat o cale nouă de Cancel către alt ID în deltă.
- Recuperarea distinctă simplă/fresh fără candidatul stale precedent rămâne acoperită de codul existent și de controlul pozitiv executat mai sus. Orphan recovery folosește ID-ul selectat și `operationControls`, independent de existența unui rând; nu a fost eliminată prin guard.
- Manual UNKNOWN păstrează identitatea și abandonează continuarea, nu operația deja admisă. FINISHED/UNKNOWN rămâne istoric; NEEDS_RECONCILIATION rămâne recuperabil, nu succes. Stop continuă să abandoneze numai nesentul; nici hidratarea, nici readbackul nu apelează `startTest`.
- Nicio schimbare în limite/deadline/generație, validare, consent, `exactCheck`, CAS, requesturile Start/Cancel, client sau server. Nu solicit modificarea lor fără defect.
- Am citit originalele autorului `direct-red-2`, `direct-green`, `direct-regression` și comanda regression: RED comportamental FINISHED3 fixture vs RUNNING2 query; GREEN1PASS; regresii27PASS/82skipped/exit0. Sunt dovezi ale autorului, nu suite rerulate de mine. Primul `direct-red` rămâne eroare de lookup, nu probă comportamentală. Findingul de mai sus nu este acoperit de cazurile simple `recovers the actual active check` deoarece ele nu publică după terminal un Reload cu A stale înainte de B activ.

## Payload-ul exact al probei SOURCE executate

A fost trimis prin stdin către `/home/kali/.local/share/omnis-toolchains/bin/node --input-type=module`, din `.../settings-inline-feedback-20261029/web`, cu `NODE_ENV=test` și PATH pinned. Mai jos este JavaScriptul executat; testul append-uit nu există pe disc. Nu rula această probă ca QA API/PG sau ca dovadă instalată.

```javascript
import { startVitest } from "vitest/node";
import react from "@vitejs/plugin-react";
const probe = String.raw`
it.each([false, true])("R2 delayed library stale-selected=%s must recover distinct active Cancel", async staleSelected => {
  const target = { ...entry, entry_id: "cccccccc-cccc-4ccc-8ccc-cccccccccccc", model: "Catalog/00" };
  const a = operation("aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa", entry);
  const b = operation("bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb", target);
  const terminalA: EntryTestView = { ...a, state: "FINISHED", state_revision: 3, result_state: "COMPLETED", finish_reason: "COMPLETED" };
  const { state, hook } = settingsBackend(configured, [entry, target], [...models, { ...models[0]!, model: entry.model }]);
  let reloading = false, held = false, finished = false, remoteB = false, release = () => {};
  const gate = new Promise<void>(resolve => { release = resolve; });
  hook.intercept = async (path, _body, method) => {
    if (path === "/api/v1/model-test/entries/latest/" + entryId) {
      if (reloading) { held = true; await gate; return Response.json(staleSelected ? a : terminalA); }
      return Response.json(a);
    }
    if (path === "/api/v1/model-test/entries/latest/" + target.entry_id) {
      if (reloading) await gate;
      return remoteB ? Response.json(b) : undefined;
    }
    if (path === "/api/v1/model-test/entries/" + a.operation_id) return Response.json(finished ? terminalA : a);
    if (path === "/api/v1/model-test/entries/" + b.operation_id) return Response.json(b);
    return undefined;
  };
  const scope = await sessionScope(session.csrf_token); remember(testStorage, scope, a.operation_id!);
  const mounted = mount(true);
  try {
    const rowA = await screen.findByRole("listitem", { name: "Model Exact/Model via OpenRouter" });
    await within(rowA).findByRole("button", { name: "Cancel test" });
    reloading = true;
    fireEvent.click(screen.getByRole("button", { name: "Reload current settings" }));
    await waitFor(() => expect(held).toBe(true));
    finished = true;
    await waitFor(() => expect(mounted.client.getQueryData(["private", "settings-entry-test", scope, a.operation_id])).toMatchObject({ state: "FINISHED", state_revision: 3 }), { timeout: 2000 });
    await within(rowA).findByText("Connected", { exact: true });
    remoteB = true; release();
    await screen.findByText("Settings reloaded.");
    const rowB = modelRow(target.model);
    await within(rowB).findByRole("button", { name: "Cancel test" });
    expect(state.writes).toEqual([]);
  } catch (error) {
    const library = mounted.client.getQueryData<{ checks: Record<string, EntryTestView> }>(["private", "settings-model-library", scope]);
    console.error("R2_DELAYED_LIBRARY " + JSON.stringify({ staleSelected, exactA: mounted.client.getQueryData(["private", "settings-entry-test", scope, a.operation_id]), libraryA: library?.checks[entryId], libraryB: library?.checks[target.entry_id], exactBReads: state.reads.filter(path => path === "/api/v1/model-test/entries/" + b.operation_id).length, cancelButtons: screen.queryAllByRole("button", { name: "Cancel test" }).length, writes: state.writes }));
    throw error;
  } finally { release(); mounted.unmount(); mounted.client.clear(); }
});
`;
let appended = false;
const ctx = await startVitest("test", ["src/app/SettingsWizard.test.tsx"], {
  config: false, watch: false, cache: false, environment: "jsdom", include: ["src/**/*.test.{ts,tsx}"], setupFiles: ["./tests/setup.ts"], restoreMocks: true, clearMocks: true,
  testNamePattern: "R2 delayed library", reporters: ["default"],
}, { plugins: [{ name: "r2-readonly-source-probe", enforce: "pre", transform(code, id) { if (id.split("?")[0].endsWith("/src/app/SettingsWizard.test.tsx")) { appended = true; return { code: code + probe, map: null }; } } }, react()] });
console.log("R2_IN_MEMORY_ONLY " + JSON.stringify({ appended, exitCode: process.exitCode ?? 0 }));
await ctx.close();
```

## Predare

Original unic creat: acest raport. Produs/teste/fixture/config/index nemodificate; nicio resursă reală nouă și niciun cleanup al resurselor altora. Integritatea Git/diff/blob a fost recitită după probă, cu exit0 pentru comparațiile tracked/index. Verdictul poate fi reanalizat numai pe fixul minimal și controlul afectat; nu redeschide Add/E2E neschimbate și nu cere alt audit general.

Am omis PG/API/OCI/operator/browser nativ, instalare, canonical și full suites; Reticle NOT_RUN (fără runtime UI admis), Chisel BLOCKED_NO_GO. Main, fișierele protejate și slotul Sol nu au fost atinse.
Risc: Cancel-ul contextual al unei operații distincte poate rămâne ascuns după Reload stale; cauza FAIL-ului PG istoric și healthy QA pe bytes actuali rămân neatribuite/neexecutate aici.
