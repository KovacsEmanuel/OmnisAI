"""F01 delta: original real-wheel probe, finite S1 omissions must deny."""
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from zipfile import ZIP_DEFLATED, ZipFile

REPO = Path('/home/kali/.hermes/cache/scratch/omnis-s1-20261104')
WHEEL = Path('/home/kali/.hermes/cache/scratch/s1-copy-__zsnccx/wheels/omnis_api-0.1.2-py3-none-any.whl')
sys.path[:0] = [str(REPO / 'cli/src'), str(REPO / 'cli/tests')]
from omnis_cli.release import ReleaseError, _manifest
from test_provider_settings_profile import ProviderSettingsBundleTest

CHILD = '''import sys,json
from pathlib import Path
sys.path.insert(0,sys.argv[1])
def guard(event,args):
    if event in {'socket.connect','socket.bind','subprocess.Popen','os.system'}:
        raise RuntimeError('NO_EFFECT_REVIEW')
sys.addaudithook(guard)
try:
    from omnis.modules.runs.run_runtime import AgentRunOwner
    from omnis.supervisor.agent_runner import AgentStep
    import omnis.modules.runs.run_runtime as owner
    assert Path(owner.__file__).is_relative_to(Path(sys.argv[1]))
    print(json.dumps({'import':'PASS','owner_from_private_copy':True}))
except Exception as exc:
    print(json.dumps({'import':'FAIL','type':type(exc).__name__,'missing':getattr(exc,'name',None)}))
    sys.exit(1)
'''
rows = []
with tempfile.TemporaryDirectory(prefix='s1-r1-fix-', dir='/home/kali/.hermes/cache/scratch') as temporary:
    root = Path(temporary)
    os.environ['TMPDIR'] = temporary
    original = WHEEL.read_bytes()
    assert hashlib.sha256(original).hexdigest() == 'fc57a1185db6e23f8e3a6cfc5e1e85cba1d0f848bcb063933147138582b7e6e9'
    with ZipFile(io.BytesIO(original)) as archive:
        modules = {name: archive.read(name) for name in archive.namelist() if name.startswith('omnis/') and name.endswith('.py')}
    assert len(modules) == 133
    assert all(content == (REPO / 'api/src' / name).read_bytes() for name, content in modules.items())
    cases = (None, *ProviderSettingsBundleTest.S1_CATALOG_CLOSURE, 'omnis/modules/runs/run_runtime.py')
    assert len(cases) == len(set(cases)) == 20
    for index, missing in enumerate(cases):
        fixture_owner = ProviderSettingsBundleTest()
        try:
            fixture = fixture_owner.bundle(version='0.1.2', schema='0019_agent_runs', dependencies=fixture_owner.S0)
            payload = io.BytesIO()
            with ZipFile(io.BytesIO(original)) as source, ZipFile(payload, 'w', ZIP_DEFLATED) as target:
                for item in source.infolist():
                    if item.filename != missing:
                        target.writestr(item, source.read(item.filename))
            name = 'api/omnis_api-0.1.2-py3-none-any.whl'
            (fixture.bundle / name).write_bytes(payload.getvalue())
            fixture.manifest['files'][name] = hashlib.sha256(payload.getvalue()).hexdigest()
            fixture.write_manifest()
            try:
                _manifest(fixture.bundle)
                accepted, refusal = True, None
            except ReleaseError as exc:
                accepted, refusal = False, str(exc)
            tree = root / str(index)
            tree.mkdir(mode=0o700)
            with ZipFile(io.BytesIO(payload.getvalue())) as archive:
                archive.extractall(tree)
            child = subprocess.run([sys.executable, '-I', '-B', '-c', CHILD, str(tree)], capture_output=True, text=True, timeout=30, env={'PATH':'/usr/bin:/bin','HOME':str(root),'TMPDIR':str(root)})
            result = json.loads(child.stdout)
            assert not child.stderr
            rows.append({'omitted':missing,'manifest_accepted':accepted,'refusal':refusal,'consumer':result,'exit':child.returncode})
        finally:
            fixture_owner.doCleanups()
assert rows[0]['manifest_accepted'] and rows[0]['exit'] == 0
assert all(not row['manifest_accepted'] and row['refusal'] == 'Provider Settings production closure required' and row['exit'] == 1 for row in rows[1:])
print(json.dumps({'source_modules':len(modules),'source_wheel_parity':True,'rows':rows,'owned_temporary_removed':not root.exists()},indent=2))
