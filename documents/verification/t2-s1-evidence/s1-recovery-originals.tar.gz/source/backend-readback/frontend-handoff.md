# S1 R1-03 / R1-05 — public DTO handoff (SOURCE candidate)

Base `9ff8bbbd7d6e0d9d953bde6e34d53d5193ded9b0`; apply in order:
1. `1d4b5e8e8a2ca818b84a8ff857d6d009377d5155` — exact completion/consumption inspector.
2. `0b945bc4da737c82ce887470d8e30a3c6cf596db` — attributed original usage, idempotent receipt, aggregate/readback.

`manifest.json` contains every changed path, Git blob and SHA256 (10 paths). `dto-schemas.json` is the actual generated OpenAPI subset for the two existing GETs, not a hand-written approximation. Public `contracts/`, web generated TS/decoder/UI remain parent-owned and unchanged here.

## Old → new normal endpoints

- `GET /api/v1/runs/{run_id}/summary`: response remains `RunSummary`; adds **required `usage: UsageSummary`**, scope `RUN`. Existing `run`, `owner_live`, `phase_active`, `question`, `attempts: Attempt[]` (max50), `has_more`, `as_of` unchanged. Stored `Attempt` and the summary roster stay lean. Summary `has_more` concerns only roster truncation, NEVER usage aggregation.
- `GET /api/v1/runs/{run_id}/attempts/{attempt_id}`: response changes `Attempt` → **`AttemptInspection extends Attempt`**. Every existing Attempt field remains. Added fields below. No new route, generic ref resolver, effect, query option, schema migration or billing store.

### AttemptInspection additions

| Field | Exact shape / meaning |
|---|---|
| `result` | `ResultRecord | null`; exact retained worker completion or error/cancel result, not a recomputed verdict |
| `decision` | existing `BrainDecision | null`: `action: delegate|ask|finish`, `summary: string<=256`, `detail: string<=1024`, `consumed_refs: RunRef[]<=32` |
| `decision_completion_kind` | `"direct" | null`; legacy decision-v1 is null, never inferred |
| `consumption` | `InboxConsumption | null`: `{held:boolean, decision_ref:RunRef|null, consumer_attempt_id:Identity|null}`; follows exact worker inbox linkage to consuming Brain; a non-null decision link has its ownership/payload/ref and consumed_refs checked |
| `usage` | `UsageSummary | null` in schema; the normal GET always populates it with scope `ATTEMPT`; nullable allows the internal completion-only DTO before composition |
| `dispatches` | `DispatchUsage[]`, max20, default[]; bounded detail, not the source of whole-attempt/run totals |
| `dispatches_has_more` | boolean, defaultfalse; true when count21 or full-response byte budget omits detail; there is no invented all-history claim or automatic resend |
| `as_of` | datetime string, UTC from read transaction; completion, consumption, usage and dispatch detail share REPEATABLE READ/readonly snapshot |

`ResultRecord` fields: `run_id/task_id/attempt_id: Identity`; `state: SUCCEEDED|INCONCLUSIVE|FAILED|CANCELLED`; `completion_kind: direct|finish|error|cancel|null`; `summary: string<=256|null`; `consumed_refs: RunRef[]<=32`; `gaps: string[]<=17`. Gaps, summary and refs are the exact persisted values, including INERT_READ_PROOF_INCOMPLETE, not a re-evaluation. Missing historical completion_kind remains null.

Brain success uses `decision`, not `result`. Brain error/cancel can have `result`. Running/uncompleted attempts can have both null. The inherited `result_ref` remains the exact reference to whichever completion is resolved; use the existing attempt URL for the inspector. To inspect consumption's Brain, navigate to the same run and `consumer_attempt_id`; do not invent a ref endpoint.

## UsageSummary and attribution

`UsageSummary = {scope: "RUN"|"ATTEMPT", accounting_policy:"MONITOR", totals:UsageTotals, roles:RoleUsage[]<=2}`.

`RoleUsage = {role:"BRAIN"|"RECON", configured_model:string<=256, connection_id:Identity, connection_revision:PositiveRevision, totals:UsageTotals}`. Only roles with dispatch rows appear. These use the immutable run setup's two configs, never unbounded observed-model alias grouping.

`UsageTotals` fields:
- `dispatches: Revision`: all unique owned dispatch allocations in the selected run/attempt, all stored states. This is NOT a paid-call counter. RESERVED/RELEASED have no inferred charge.
- `unobserved_dispatches: Revision`: dispatches with no observation receipt (including SENT/lost response). A present receipt whose components are absent still has UNKNOWN component coverage below.
- Each of `input_tokens`, `output_tokens`, `total_tokens`, `cached_tokens`, `reasoning_tokens`, `cache_creation_tokens`, `cost_observed` is a **`UsageSubtotal`**: `{value:string|null, observed_dispatches:Revision, state:"OBSERVED"|"PARTIAL"|"UNKNOWN"}`. Value is a nonnegative decimal string (max256) to avoid JS precision loss. For token fields it is an integer string. Null/zero observations is UNKNOWN, never 0. Known numeric zero is the string `"0"` (possibly cost scale).

`OBSERVED`: every dispatch in the selected scope has this component. `PARTIAL`: a subtotal over only the explicitly counted observed dispatches. `UNKNOWN`: no observed values, including an empty run. Show coverage and state; never relabel a PARTIAL cost subtotal as a complete charge. No estimates/pricing, currency conversion, financial ceiling or run-lifetime cap is introduced. Observed cost is the only cost source.

Aggregation happens in SQL over all owned dispatch history with bounded result shape (whole scope plus at most2 roles), no N-record cap and no Python loading of all records. Missing receipts are LEFT JOINed, not dropped. Token total is input+output when both are known and reported total is absent or matches; a mismatching total is unknown. When input/output is incomplete, a validated reported total can still be used. Cache/reasoning are components and are not added again. Conflicting aliases become unknown for their normalized component while validated originals remain available.

### DispatchUsage

`{dispatch_id:Identity, state:RESERVED|SENT|SETTLED|RELEASED|UNKNOWN, usage_ref:RunRef|null, usage:UsageRecord|null, reserved_at:datetime|null, sent_at:datetime|null, settled_at:datetime|null}`.

Times come from actual retained dispatch events; null means not observed. No provider duration or real300s elapsed proof is invented. `usage=null` means no observation receipt; use null/UNKNOWN, not zero. `state` is the exact dispatch state, independent of whether a usage receipt exists.

`UsageRecord` fields:
- `instance_id/run_id/task_id/attempt_id/dispatch_id: Identity`;
- `role:BRAIN|RECON`, `configured_model:string<=256`, `connection_id:Identity`, `connection_revision:PositiveRevision`;
- `observed_at:datetime`, `observed_model:string<=256|null`;
- `measures:UsageMeasures`, `reported:ReportedUsage`.

`UsageMeasures`: `input_tokens/output_tokens/total_tokens/cached_tokens/reasoning_tokens/cache_creation_tokens: TokenCount|null`; `cost_observed:string<=128|null` (finite validated fixed decimal). `TokenCount` is a strict non-bool integer in `[0,9007199254740991]`.

`ReportedUsage` retains ONLY validated known original values before SDK coercion:
- `prompt_tokens`, `completion_tokens`, `total_tokens`, `input_tokens`, `output_tokens`, `cached_tokens`, `reasoning_tokens`, `cache_read_input_tokens`, `cache_creation_input_tokens`: TokenCount|null;
- `prompt_tokens_details: {cached_tokens:TokenCount|null}|null`;
- `completion_tokens_details: {reasoning_tokens:TokenCount|null}|null`;
- `cost: int|float|string|null`, original validated numeric representation. Nonnegative finite decimal, bounded numeric representation/expansion; malformed/bool/infinite/huge-exponent values become null, not coerced amounts. Missing/invalid count strings and booleans are never parsed into numbers.
All unknown provider keys/private reasoning strings are discarded. Existing DATA guard precedes observe; this is not a claim of universal semantic redaction.

## Storage / compatibility / refusal

- New `run-usage-v2` is one immutable record linked by exact `usage_ref` in the existing owned dispatch payload. Dispatch row lock serializes duplicates; identical observation returns the original ref/time with no extra receipt or revision. Conflicting observation fails closed, preserving the original record. No old usage records are rewritten.
- Legacy unlinked `run-usage-v1` is resolved by same-instance unique dispatch identity. Identical stored-payload duplicates are collapsed once; differing legacy receipts refuse readback. Only old prompt/completion observations are recovered; unavailable cost/cache/model information stays null. Attribution is obtained from owned dispatch/attempt/setup, not fabricated provider history.
- New `run-decision-v2` wraps `{run_id,task_id,attempt_id,completion_kind:"direct",decision:BrainDecision}` and remains the attempt's result_ref in the SAME TxB as consumption/checkpoint. Old v1 records are unchanged and bind ownership through their immutable decision event; old completion kind stays null.
- Result/decision resolution checks instance/run/task/attempt/kind/revision/digest; decision consumption must match retained inbox references. Usage SQL matches exact reference metadata and ownership against immutable records/config; per-dispatch record resolution additionally recomputes the record digest.
- Both readers are receive-only. No owner wake, SDK, vault key loading, re-evaluation, consume or write. Existing 65536-byte full-response cap remains; exact completion/aggregate are never silently shortened. Dispatch details/roster may truncate with truthful has_more, while an oversized essential projection refuses `PROJECTION_LIMIT`.

## Evidence / limits

- `final-source.json`: 176PASS6.51s, exit0. Includes real owner + installed SDK scripted transport → one usage/decision receipt → both existing GET readers and repeated readback; malformed originals; privacy sentinel exclusion; duplicate/conflict; independent refs/lineage denials; incomplete result/consuming Brain; legacy nulls; missing receipt; composed65536-byte response and existing32768-byte SDK controls. One scripted call per journey is NOT paid inference.
- `final-quality.json`: Ruff check, format-check10, strict mypy10 and diff-check all exit0. `pins-origins.json`: Python3.13.15, agents0.19.0, OpenAI2.45.0, cryptography50.0.1, exact owned-worktree imports.
- SQL result/authority seams are SOURCE evidence. Aggregate SQL syntax/semantics, constraint/concurrency/restart durability on actual PostgreSQL, browser/UI, installed release, real300s and live provider remain NOT_RUN. The100001 test value is a synthetic returned aggregate, NOT100001 inserted/executed database rows. PG fixture census names updated but no PG test executed.
- Initial behavioral REDs and intermediate test assembly/lint failures remain alongside final evidence; no previous checkpoint overwritten. Earlier five fixes are unchanged candidates pending parent paired review, not re-audited or approved here.
- Parent next: cherry-pick these two commits, regenerate public OpenAPI/TS and bind frontend, obtain paired exact-snapshot review, then separately authorized real-consumer QA. No S1 closure, acceptance, push or rollout claimed.
