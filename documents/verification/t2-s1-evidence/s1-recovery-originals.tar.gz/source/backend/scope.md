# Backend review fixes — own isolated candidate
Base 7a48274153988e4a917f8128c79a48415ba43961. Original reviews unchanged.
S1 only. Owned API runtime/SDK/store/contract/projections/routes/errors and targeted tests.
SOURCE only: actual pinned SDK through scripted httpcore sink; DB/transaction/vault doubles.
No PG, browser, services, live provider, target, operator files, new dependencies, or generated contracts.
Acceptance: R2-F01 DATA; R1-01 Start; R1-02/R2-F03 typed refusal; R1-06 events; R1-04 finish-tool; R1-03/05 usage and readback. Each independent behavior gets RED/GREEN and a local granular commit. Parent integrates/reviews/accepts.
Checkpoint: five behavior fixes committed; R1-03 accounting and R1-05 public result/decision readback remain NOT_IMPLEMENTED at bounded-session handoff. Public DTO work is NOT stable/available; frontend stage2 must not assume otherwise. Only ErrorCode.DATA_DENIED was added publicly; RUN commands unchanged. Internal StepResult.kind adds finish; durable run-result-v1 includes completion_kind direct/finish/error/cancel. Existing result_summary/result_ref consumers unchanged. Exact commits/file hashes and proof scope: checkpoint.json. Parent owns continuation, integration and acceptance. No all-S1 closure claimed.
Start commit bbd49fe8 accidentally preceded the Ruff import-order correction and prematurely claimed quality0; the preserved follow-up ceb829c1 fixes that import. All checkpoint-source-final/quality checks run on final bytes; historical failure logs remain.
