# Diagnostic read-only: cele trei eșecuri inițiale web

Snapshot: 90eb7041fb928098f35aa2916f77772b2b1e1dfa; `git diff --exit-code 22eaecdd73d6a42d9a1a79f2edada109ae1f4804 HEAD -- web` exit0. Fișierele neversionate protejate nu au fost citite/modificate. Niciun test nou lansat de acest investigator, nicio editare produs/config/test, niciun efect operator/provider.

## Verdict

Cauză istorică UNKNOWN. Nu există finding de produs demonstrat și nu admit un remediu din aceste date. Eșecurile sunt deadline-uri ale primei inițializări, nu ale acțiunilor numite în titlurile testelor. Counter harness-only2 rămâne; 162/162 și 354/354 curente nu repară/explică gate-ul original.

## Dovezi originale și frontiere

Am citit membrul gate.log direct din arhiva versionată canonical-final-fail-originals.tar.gz și sursele efective. Atât snapshotul DOM din ultima eroare a locatorului, cât și cel adăugat la timeout conțin aceeași etapă pentru fiecare caz:

- ProjectionStates.test.tsx:25–29: linkul lipsește, `Loading dashboard…`. Shell a comis deja sesiunea autentificată; Dashboard este montat, dar proiecția nu este încă vizibilă. 401/Refresh nu sunt executate.
- SettingsModels.test.tsx:45–48, parametrul Skills: `Checking local session…`. Încă Bootstrap/session pending, înainte de navigare, secret nesalvat sau pagina Models.
- SettingsWizard.test.tsx:16–17, helper:236: `Loading current settings…`. Shell a trecut de sesiune; ProviderSettings nu a comis încă un binding valid. Add/Continue/Refresh nu sunt executate. NU este dovadă că settings library read s-a blocat: SettingsModelsPage încă nu este montat în acest DOM.

Traseu: `useBrowserSession.ts:18–27` → API request/body/decode în `shared/api/client.ts:23–49` → Query cache → notifyManager → React commit (`App.tsx:36`). Dashboard continuă prin `Dashboard.tsx:15–19`/`readPrivate:113–125`; Settings continuă prin `ProviderSettings.tsx:11–22` → digestul nativ din `SettingsModels.ts:64–66` → abia apoi `SettingsModelsPage.tsx:56–84`.

Nu există un unic apel HTTP aval comun celor trei DOM-uri. Comună este propagarea asincronă sesiune/query→notificare→React; Wizard mai are digest nativ→setBinding→commit. Un trace care vede numai fetch nu poate discrimina acestea.

## Izolare și scheduling

Vitest instalat are isolate=true (`dist/config.cjs:50`), pool implicit forks (`chunks/coverage.DM_a_rWm.js:180`), un spec per task (`cli-api.B0Pz1_R7.js:3875–3900`), iar workerul izolat nu este refolosit (`:3543–3551`). Toate trei sunt primele teste executabile din fișier. La comanda/configurația consemnată, mecanismul „callback al unui test precedent în același worker fură mockul” nu are un predecesor pentru aceste trei cazuri. Lipsa client.clear() global nu demonstrează cauza; nu justifică un fix de teardown. Izolarea workerilor nu izolează CPU/event loop host contention.

notifyManager folosește efectiv setTimeout(callback,0): `query-core/src/notifyManager.ts:19,41–50,78–84`, `timeoutManager.ts:241–242`. React subscriberul trece prin batchCalls: `react-query/src/useBaseQuery.ts:98–114`. Testing Library are asyncUtilTimeout=1000 și interval50, plus MutationObserver (`dom/dist/config.js:15`, `wait-for.js:40,91–97,143–156`). Deci query success în cache poate preceda actualizarea DOM; lipsa DOM nu dovedește request lipsă sau refuz de auth.

Important pentru observator: `query-core/src/query.ts:779–783` tratează CancelledError(silent) fără dispatch(error)/onError obișnuit. Un listener numai pe query-cache errors poate rata exact readPrivate cancellation. Trebuie observat și settlementul Promise-ului real Query.fetch, fără swallow și fără schimbarea valorii/errorului.

## Baseline-uri curente citite, nu relansate

Comenzile și exit0 provin din three-files-command.json/default-web-command.json. JSON-urile originale confirmă162PASS/0FAIL, respectiv354PASS/0FAIL.

Duratele întregului prim test (nu latența primei citiri):

| Caller | original FAIL | trei fișiere PASS | wholeweb default PASS |
|---|---:|---:|---:|
| ProjectionStates |1728ms|423.149ms|1319.048ms|
| SettingsModels/Skills |1655ms|585.019ms|2034.804ms|
| SettingsWizard |1821ms|848.324ms|2541.614ms|

Trei teste curente pornesc în aceeași fereastră de startup, dar JSON-ul nu are faze interne. Timpii mai mari ai testelor complete care trec arată de ce totalul unui caz nu măsoară deadline-ul primul findBy/waitFor. Nicio atribuire CPU/crypto/notify nu rezultă din aceste numere.

## Cel mai mic probe propus, NECALIBRAT/NEEXECUTAT

Numai scratch, callerii existenți și dependențele instalate; fără helper/framework/config livrată. După admiterea părintelui, observare temporară în cele trei teste/mount-uri:

1. Buffer bounded în memorie, timestamp monotonic; flush la primul assertion failure/success, înainte de cleanup. Păstrează numai case/file, query label finit, phase/status/fetchStatus, CancelledError/silent/revert, signal.aborted, scheduled/fired și faze DOM. Fără query data/keys cu scope brut, grant, request bodies, headers sau storage.
2. Spy delegat pe API session/dashboard și digest pentru enter/resolved/rejected; înregistrează numai eticheta și rezultatul, nu input/output. Query cache subscribe pentru added/updated/status/observer count. Spy delegat pe `Query.prototype.fetch` pentru settlement/rejection efectiv (inclusiv silent CancelledError), returnând rezultatul/eroarea nemodificate.
3. `notifyManager.setScheduler` delegă exact la exportul instalat `defaultScheduler`, înregistrează enqueue/run. Restabilește defaultScheduler în finally. Nu muta callbackul pe microtask și nu înfășura artificial în act în proba naturală.
4. React Profiler în jurul App, numai pentru commit+booleeni DOM finiți: bootstrap/dashboardLoading/settingsBinding/configured/addReady. Acesta distinge render/commit de cache success. Dacă Query.fetch se anulează natural, păstrează cancellation/abort înainte de teardown; observatorul de aici NU explică automat ce guard epoch/phase a declanșat-o.

Calibrare înainte de tentativa naturală, în proces separat, astfel încât să nu preîncălzească primul caz rece:
- Pozitiv: consumerul real emite API settled→query success→notify fired→commit→locator original.
- Negativ notify: reține explicit un callback notify de sesiune prin schedulerul delegat; așteaptă settlementul real al query-ului, verifică cache success + DOM bootstrap + callback scheduled/not-fired. Eliberează prin defaultScheduler și cere locatorul original. Barieră explicită, nu sleep/timeout mărit. Distinge consumer sănătos dar notificare neexecutată de citire nerezolvată.
- Negativ cancellation: reține răspunsul folosind deferred-ul existent; anulează query-ul real prin client.cancelQueries și eliberează răspunsul. Cere signal/cancellation/rejection și absența unui success atribuit acelei citiri. Aceasta calibrează cancellation reală Query, nu pretinde a reproduce un guard epoch istoric. Cleanup settle/unmount/restaurare obligatorii.

Tentativa naturală: comanda existentă npm --prefix web test cu cele3fișiere și filtrul exact al primelor cazuri, fără schimbare de workers/deadline. O singură execuție rece după calibrare, fără full gate. Aceasta poate identifica o frontieră dacă eșecul reapare; nu reproduce automat încărcarea wholeweb, iar un PASS rămâne NOT_REPRODUCED/UNKNOWN. Nu propun un al treilea ciclu de harness sau repetarea suitei complete.

Decizii din trace: query settled success + notify întârziat = frontieră scheduler; notify fired + commit întârziat = frontieră React/event loop; API settled fără query success și CancelledError = lifecycle/cancellation; digest pending sau digest resolved fără commit = frontieră binding, nu private-library read. Timpii singuri localizează întârzierea, nu dovedesc cauza CPU; nu justifică maxWorkers fix ori timeout mai mare.

## Dispoziție

Must-fix/should-fix concrete de produs: niciunul demonstrat în scope. Remediul minim admis acum: niciun diff de produs. Urmează numai decizia părintelui asupra observației calibrate; păstrează auth/epoch/grant fences și FAIL-ul original.

Necontrolat: runtime operator, browser real, S1, provider/ținte, cauză istorică fără timeline. Singurul fișier creat este acest jurnal scratch; niciun commit sau editare repo. Reticle NOT_INTEGRATED pentru acest diagnostic jsdom; Chisel BLOCKED_NO_GO.
