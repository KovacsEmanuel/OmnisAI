# R1 original — measurement truth / producer binding

**Verdict: APPROVED_SCOPED_SOURCE (R1); niciun blocker concret identificat în frontiera revizuită.** Nu este aprobare de integrare, admitere unilaterală a execuției, runtime PASS sau închidere T1.

## Snapshot și scope

- Worktree: `/home/kali/.hermes/cache/scratch/settings-supervisor-tcp-20261030`.
- HEAD/base: `9122a34d4449212b6271ebed504f1f7ffde3e924`; cele patru modificări integration preexistente sunt păstrate, fără editare/stage/commit.
- FREEZE: `/home/kali/.hermes/cache/scratch/settings-supervisor-tcp-evidence-20261030/FREEZE.json`.
- SHA256 verificat: `2016b9599fe6bb05aace7e9e9cf8a3c5b6a8d8fb9462fe1742a3b4802a9d8bb1`.
- Verificare locală: 141 intrări hash (4 integration, 6 adapted, 131 prepared) concordă; `DRIFT []`. Diferența terminal-newline a diff-ului este deja adjudecată de părinte și nu a fost redeschisă.
- Scope: callerul existent installed → copilul supervisor real → service/SQLAlchemy/psycopg → martor backend/progres → readback. R2 deține efectele, rețeaua, deadline-ul și cleanupul complet.

## Constatări

1. **ACK-ul nu este un `finally` și nici simplul retur al driverului.** `observe_existing.py:64–87` păstrează rezultatul real al generatorului `_exec_command`; emite `protocol_COMMIT_success` numai pentru rezultat nenul, `COMMAND_OK` și tag exact `b'COMMIT'`. `None` rămâne queued, iar tag ROLLBACK rămâne not_acknowledged. Excepția/cancelarea sunt separate și propagate. Am inspectat implementarea locală psycopg 3.3.6: `_exec_command` returnează efectiv PGresult în afara pipeline, respectiv None la enqueue; `_commit_gen` poate reveni fără COMMIT când conexiunea este IDLE. Readerul nu echivalează acel driver-return cu ACK.
2. **Legarea la producător este reală în sursa pregătită.** `run_native.py:39–61` copiază wheelul și verifică cei patru producători afectați, apoi atașează trei module și contextul din entrypoint; nu schimbă comanda `python -I -m omnis.supervisor`. `provider_settings_overlay` și `__main__.py:89–116` construiesc adevăratul ApiKeyModelTest. Hookurile ating aceeași clasă InstanceService/LeaseTrace importată de copil, nu numai procesul părinte.
3. **Frontierele cerute sunt distincte în trace.** `service.py:409–450,521–532` pune COMMIT înaintea ieșirii `engine.begin`, TX_DONE după returul conexiunii. Observerul păstrează protocol, driver, pool reset/checkin și service return/error/cancel, cu PID/tag/cycle și timestamp de apariție. `native_bootstrap.py:49–74,109–126` leagă ciclul nativ și progresul event-loop-ului; `native_witness.py:37–64,81–103` colectează din proces separat, READ ONLY/autocommit, PID/backend_start/wait/query_start/blocanți și păstrează envelope-ul de recepție separat de eveniment.
4. **Eșecurile nu sunt promovate la dovadă.** Conectarea timpurie/rolul martorului nu sunt declarate calibrate în Docker: o eroare produce `independent_backend_error`, iar `summarize:22–35` refuză martor lipsă/eșuat. Drop/gap/overflow/closure incompletă sunt refuzate. `run_native.py:115–120` refuză un test eșuat și returnează exit3 chiar după observație completă; cauza rămâne UNKNOWN. Finalizerul existent păstrează excepția primară, iar prefixul nu emite vechiul PASS.

## Verificare efectuată

Comandă inertă, fără DB/rețea/fixture/proces witness:

`/home/kali/OmnisAI/api/.venv/bin/python -I -B /home/kali/.hermes/cache/scratch/settings-supervisor-tcp-evidence-20261030/calibrate.py /home/kali/.hermes/cache/scratch/settings-supervisor-tcp-evidence-20261030/observe_existing.py`

Rezultat real: exit0, `DRIVER_OUTCOMES success/error/cancel exact; no finally-as-ACK`.

Am citit `controls.log` și codul calibrării existente: originalul finally-end este RED; controlul channel păstrează success/error/cancel, queued/ROLLBACK-not-ACK, backpressure și respingerea dovezii sintetice ca nativă. Aceste rezultate sunt dovezi păstrate ale autorului, nu execuții native efectuate de R1.

## Limite și predare

- `slow_spans`/`max_commit_ns` din sumar măsoară intervalul **driver commit**, nu întregul COMMIT→TX_DONE istoric. Pentru întârziere post-ACK/pool/context se citesc timestampurile brute păstrate; un sumar fără slow commit nu dovedește absența unei asemenea întârzieri și nu repară incidentul5852ms.
- Samplingul backend are interval begin/receipt și nu este timestamp fizic de fsync; nici observarea WalSync nu separă singură stocarea de descheduling-ul backendului/VM. Cauza istorică rămâne UNKNOWN.
- Diagnostic real NOT_RUN de R1; nu am lansat Docker/DB/servicii, install-image, --run, PG pytest sau QA largă. Nicio citire de credentiale/operator/protected files.
- Reticle NOT_APPLICABLE; Chisel BLOCKED_NO_GO. Fără modificare de skill/produs ori gate; procedura existentă acoperă această analiză, fără workflow nou de salvat.
- Fișier creat: numai acest original. Părintele adjudecă împreună cu R2 și decide admiterea; aprobarea R1 nu consumă tentativa0/1 și nu schimbă T1_BLOCKED/T2_NOT_READY.
