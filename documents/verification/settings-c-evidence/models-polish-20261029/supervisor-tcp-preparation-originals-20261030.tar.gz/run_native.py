"""Adapted sol invocation: existing installed owner, no UDS attestation bypass."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import unittest
import zipfile

ROOT = Path('/home/kali/.hermes/cache/scratch/settings-supervisor-tcp-20261030')
OUT = Path(__file__).parent
BUNDLE = Path('/home/kali/.local/share/omnis-t1-artifacts/upgrade-bb760e5/bundle')
UV = '/home/kali/.local/share/omnis-toolchains/bin/uv'
FILES = ('observe_existing.py', 'native_bootstrap.py', 'native_witness.py')
sys.path[:0] = [str(ROOT / 'cli/src'), str(ROOT / 'cli/integration'), str(OUT)]
sys.dont_write_bytecode = True


def preflight():
    from omnis_cli.release import _manifest
    from omnis_cli.development import validate_new
    if Path.cwd() != ROOT or sys.version_info[:3] != (3, 13, 15):
        raise ValueError('EXACT_SOURCE_INTERPRETER_REQUIRED')
    if any(k.startswith(('DOCKER_', 'PG')) for k in os.environ):
        raise ValueError('AMBIENT_CONNECTION_CONFIG_REFUSED')
    manifest = json.loads(_manifest(BUNDLE)[0])
    if (manifest['release'], manifest['schema'], manifest.get('profile')) != ('0.1.1', '0017_model_removal', 't1-provider-settings'):
        raise ValueError('EXACT_BUNDLE_REQUIRED')
    if not os.access(UV, os.X_OK):
        raise ValueError('PINNED_UV_REQUIRED')
    hashes = {name: hashlib.sha256((OUT / name).read_bytes()).hexdigest() for name in FILES}
    api_wheel = BUNDLE / 'api/omnis_api-0.1.1-py3-none-any.whl'
    hashes['run_native.py'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    hashes['api_wheel'] = hashlib.sha256(api_wheel.read_bytes()).hexdigest()
    hashes['cli_wheel'] = hashlib.sha256((BUNDLE / 'cli/omnis_cli-0.1.1-py3-none-any.whl').read_bytes()).hexdigest()
    desired = {}
    with zipfile.ZipFile(api_wheel) as wheel:
        for name in wheel.namelist():
            if name.startswith('omnis/') and not name.endswith('/'):
                if '..' in Path(name).parts:
                    raise ValueError('WHEEL_PATH_REFUSED')
                desired['api/src/' + name] = wheel.read(name)
    for name in ('supervisor/__main__.py', 'modules/instance/service.py', 'core/db.py', 'modules/runs/model_test_runtime.py'):
        if desired['api/src/omnis/' + name] != (ROOT / 'api/src/omnis' / name).read_bytes():
            raise ValueError('PRODUCER_WHEEL_DRIFT')
    main_path = 'api/src/omnis/supervisor/__main__.py'
    original = desired[main_path].decode()
    old = 'if __name__ == "__main__":\n    raise SystemExit(main())\n'
    new = ('if __name__ == "__main__":\n'
           '    from omnis.supervisor._sol_native_bootstrap import attach\n'
           '    with attach(sys.modules[__name__]) as observer:\n'
           '        result = main()\n'
           '        observer.emit("native_main_return", exit=result)\n'
           '        raise SystemExit(result)\n')
    if original.count(old) != 1:
        raise ValueError('EXACT_SUPERVISOR_ENTRY_REQUIRED')
    desired[main_path] = original.replace(old, new).encode()
    for name in FILES:
        desired['api/src/omnis/supervisor/_sol_' + name] = (OUT / name).read_bytes()
    for name in manifest['files']:
        if name.startswith('web/'):
            desired['web/dist/' + name.removeprefix('web/')] = (BUNDLE / name).read_bytes()
    digest = hashlib.sha256(json.dumps(hashes, sort_keys=True).encode()).hexdigest()
    workspace = OUT / ('development-' + digest[:12])
    if workspace.exists():
        if {str(p.relative_to(workspace)) for p in workspace.rglob('*') if p.is_file()} != set(desired):
            raise ValueError('OWNED_SOURCE_INVENTORY_DRIFT')
        for name, payload in desired.items():
            if (workspace / name).read_bytes() != payload:
                raise ValueError('OWNED_SOURCE_DRIFT')
    else:
        workspace.mkdir(mode=0o700)
        for name, payload in desired.items():
            target = workspace / name
            target.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
            with target.open('xb') as stream:
                stream.write(payload)
            target.chmod(0o600)
    validate_new(str(workspace))
    for name, payload in desired.items():
        if name.endswith('.py'):
            compile(payload, name, 'exec')
    identity = dict(bundle=str(BUNDLE), workspace=str(workspace), uv=UV)
    print('SOL_PREFLIGHT ' + json.dumps(dict(
        options=identity, observer_hashes=hashes, prepared_files=len(desired),
        command=['python', '-I', '-m', 'omnis.supervisor'],
        schema=manifest['schema'], profile=manifest['profile'],
        image='fresh install-image; existing CLI attestation unchanged',
        docker_access='NOT_EXERCISED', docker_socket_access=os.access('/run/docker.sock', os.R_OK | os.W_OK),
        diagnostic_invocations=int((OUT / 'diagnostic-admission.json').exists()), historical_invocations=2,
        budget_seconds=600, includes_teardown=True,
    )), flush=True)
    return identity


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--run', action='store_true', help='Effectful; requires independent admission')
    parser.add_argument('--preflight', action='store_true')
    args = parser.parse_args()
    if args.run == args.preflight:
        parser.error('choose exactly one mode')
    options = preflight()
    if args.run:
        from test_release import ReleaseBundleTest
        from observe_native_case import summarize
        marker = OUT / 'diagnostic-admission.json'
        with marker.open('x') as stream:
            json.dump(dict(wall_ns=time.time_ns(), budget_seconds=600, invocations=1), stream)
        marker.chmod(0o600)
        case = ReleaseBundleTest('test_t1_supervisor_diagnostic_installed')
        case.supervisor_options = options
        result = unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite([case]))
        if not result.wasSuccessful() or not hasattr(case, 'supervisor_events'):
            raise SystemExit(2)
        print('SOL_DIAGNOSTIC ' + json.dumps(summarize(case.supervisor_events)), flush=True)
        # A completed observation is not a causal fix, even with clean lifecycle tests.
        raise SystemExit(3)
