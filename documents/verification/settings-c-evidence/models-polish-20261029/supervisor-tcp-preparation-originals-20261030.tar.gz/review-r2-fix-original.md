# R2 — re-review independent focalizat al remedierii F01/F02

**Verdict: APPROVED_SCOPED_SOURCE. R2-F01 și R2-F02 sunt închise pe snapshotul de mai jos. Niciun blocker concret nou în scope-ul re-reviewului.** Din perspectiva acestor două findings, părintele poate admite unica diagnostică instalată deja autorizată, cu deadline absolut≤600s inclusiv pregătire/Stop/readback, fără fallback de rețea și fără scurtarea intervalelor ownerului. Nu este runtime PASS și nu constituie integrare ori atribuirea cauzei5852ms.

## Identitate și scope

- Worktree: `/home/kali/.hermes/cache/scratch/settings-supervisor-tcp-20261030`; HEAD `9122a34d4449212b6271ebed504f1f7ffde3e924`. Cele patru modificări integration erau preexistente; reviewerul nu a editat source, stage sau commit.
- `FREEZE-r2-fix.json` SHA256 `467ae5907f27792fab8ab7fca6e6b560af62f802ad6ceca0edfae406645702a2`.
- `frozen-r2-fix.diff` SHA256 `78d416ea2a149c6e0343d316eebb94505d5a11af792bbe288036e79ba4cea439`.
- Hashurile celor patru fișiere changed recalculate independent, exacte înainte și după controale. Cele șase contract_bindings de asemenea exacte. Manifestele adapted/prepared_source sunt identice cu FREEZE original; verificarea fizică integrală 6+131 este cea deja efectuată de părinte, nerepetată aici.
- FREEZE original, frozen.diff original, controls.log și ambele reviewuri originale: hashuri recalculate, păstrate exact. Vechiul test_installed_settings.py nu este remediere nouă. R1 se reutilizează strict pentru observer/ACK/backend neschimbate; fără reaudit sau transfer către comportamentul schimbat al adaptorului.
- Cerință→consumer→risc→decizie: diagnostic unic≤600s → metoda reală ReleaseBundleTest și run_installed_stop → admitere tardivă ori tăierea cleanupului normal → închiderea/refuzul blockers înaintea probei reale. Numai trei fișiere integration reparate, callerii lifecycle relevanți și controalele existente; fără audit general.

## Dispoziții

| Finding | Cod curent / verificare | Dispoziție |
|---|---|---|
| R2-F01: install/install-image după clock610 | `test_release.py:52–153`: deadline unic; preparation_timeout înaintea fiecărui subprocess, după copy, înaintea chmod și scrierilor wrapperului. Timeoutul rezervă Start310+Stop210+readback30+settlement6, deci pregătirea are inițial44s. | CLOSED_SCOPED_SOURCE. Controlul existent parcurge tăieturile scratch/venv/pip/copy/chmod/install/install-image; refuză efectul următor, nu lansează ownerul după expirare, păstrează intrările/scratch. |
| R2-F02: Start180/Stop110 omoară ownerul prea devreme | `installed_stop.py:29–43,234–275`: Config real180 startup+100 cleanup+30 allowance=310 Start;180 shutdown+30=210 Stop. Întreg watchdogul și rezerva sunt admise înainte de comandă și reverificate după receiptul PENDING; nu sunt micșorate pentru a încăpea. | CLOSED_SCOPED_SOURCE. Controlul existent acceptă intervalul Start+cleanup și Stop lent; refusal/timeout rămân diferențiate. |

**Stop obișnuit și finalizer verificate explicit:**
- `installed_stop.py:399–457`: inventarul și pollingul folosesc deadline-ul comun cu rezerva Stop/readback; psql are limita proprie în acea rezervă. Stop este aceeași comandă publică, watchdog210; după Stop, deadline-ul runtime pentru absență este resetat la minimum(now+30, deadline absolut), nu rămâne deadline-ul psql/poll expirat.
- `installed_stop.py:1039–1148`: la refuz după Start, finalizerul citește READY/status/inventar cu timp rezervat pentru întregul Stop și readback. Dacă autoritatea rămâne sănătoasă/neschimbată și observația este settled, folosește Stop public, apoi resetează deadline-ul readback și verifică absența. Nu apelează teardown alternativ pentru acest diagnostic.
- Dacă nu mai încape Stop integral, nu îl lansează cu timeout redus. Dacă subprocessul are rezultat necunoscut/TimeoutExpired, driver_pending împiedică retry/cleanup nesigur; rămân locatorul și UNCERTAIN. Un Start FAILED_CLEANED nu este transformat de adaptor într-o dovadă nouă de cleanup: rezultatul rămâne conservator FAIL/UNCERTAIN.
- Controlul existent exercită complete, observation-refused, stop-timeout, start-cleanup, slow-stop, setup-exhausted, post-start-no-observation, post-start-no-stop și poll-exhausted. Inclusiv refuzul observației este urmat de Stop întreg și readback valid când bugetul permite; scenariul tardiv fără buget Stop nu lansează comanda.
- Config/defaults, Start cleanup și Stop owner rămân neschimbate. Nu s-au introdus deadlines de produs, framework, killpg ori owner nou.

## Dovezi și limite reale

Am citit RED-urile originale din `controls-r2-fix.log`: F01 late-effect și F02 watchdog180<280/110<180, plus manifestul affected final19PASS/1SKIP/exit0; acestea sunt dovezi ale autorului/părintelui, nu execuții live ale reviewerului.

Execuție independentă numai pe cele două controale reparate existente, cu `/home/kali/OmnisAI/api/.venv/bin/python -I -B`, `TMPDIR=/home/kali/.hermes/cache/scratch`, source paths explicite `cli/src`, `cli/integration` și unittest pe:
1. `test_release.ReleaseBundleTest.test_supervisor_preparation_refuses_late_effects`
2. `test_installed_stop_lock_oracle.StopLockOracleTest.test_supervisor_prefix_uses_one_start_and_owned_stop_or_preserves_uncertainty`

Un guard exterior a refuzat orice subprocess.Popen. Sunt doubles pentru CLI/runtime/status și filesystem temporar propriu; nu sunt procese owner reale sau DB/Docker. Output original al execuției reviewerului, exit0:

```text
test_supervisor_preparation_refuses_late_effects (test_release.ReleaseBundleTest.test_supervisor_preparation_refuses_late_effects) ... IMAGE_RECOVERY_INTENT retained at /home/kali/.hermes/cache/scratch/tmpf598_eyq/omnis-bundle-_bzori24
ok
test_supervisor_prefix_uses_one_start_and_owned_stop_or_preserves_uncertainty (test_installed_stop_lock_oracle.StopLockOracleTest.test_supervisor_prefix_uses_one_start_and_owned_stop_or_preserves_uncertainty) ... BOUNDARY: existing SOURCE controls, no real CLI/Docker/DB; subprocess.Popen forbidden
SUPERVISOR_OBSERVATION_RETAINED /home/kali/.hermes/cache/scratch/tmpowq_g7ob/s4-udvfg_jh/r/omnis/sol-events.jsonl cause=UNKNOWN
SUPERVISOR_OBSERVATION_RETAINED /home/kali/.hermes/cache/scratch/tmpzlgsm8hi/s4-s0uws165/r/omnis/sol-events.jsonl cause=UNKNOWN
ok

----------------------------------------------------------------------
Ran 2 tests in 0.079s

OK
RESULT 2 FAILURES 0 ERRORS 0 SKIPS 0 POPEN_CALLS 0
```

`git diff --check`, status și HEAD: exit0; source hashes finale neschimbate. Nu am reluat calibrări, observer/native, fullsuite, browser, model sau operator; zero diagnostică reală, install/build/Start/Stop/SQL efectiv. Noua tentativă rămâne0/1, istoricul2/2 se păstrează. Reticle NOT_APPLICABLE; Chisel BLOCKED_NO_GO. Protejatele tempkey/docsOmnis_NotiteOriginale nu au fost citite/hashuite; fără credentiale/env brut/inspect Docker brut.

## Decizia și riscul rămas

Aprobarea închide numai F01/F02 pe bytes curenți și se compune cu R1 neschimbat; integrarea și admiterea/proba efectivă aparțin părintelui. Cache-ul exact trebuie să încapă în pregătirea inițială44s sau să refuze, fără internet. Nu cer extinderea bugetului, alt harness ori alt ciclu de calibrare.

Copierea sincronă/I/O și suspendarea OS nu au garanție hard-real-time: la întoarcere, admission refuză următorul pas; nu pretind că un timeout Python împiedică orice depășire fizică sub suspendare. Allowance30s nu certifică drenarea sub orice blocaj OS. Cleanupul ownerului instalat, TCP witness și cauza5852ms rămân NOT_RUN/UNKNOWN până la proba bounded admisă. Orice depășire/refuz/UNCERTAIN trebuie păstrat, nu convertit în PASS.

**Fișier creat:** numai acest raport original în evidence; niciun fișier de proiect modificat și niciun commit. Status global propus: T1_BLOCKED/T2_NOT_READY neschimbat; numai reviewul R2 al remedierii devine APPROVED_SCOPED_SOURCE.

Omis: QA instalată/cache Docker, R1 ACK/backend neschimbat și gates globale. Risc: SOURCE+doubles nu demonstrează succesul ori settlementul real; rămâne exact unica tentativă≤600s, fără waiver.
