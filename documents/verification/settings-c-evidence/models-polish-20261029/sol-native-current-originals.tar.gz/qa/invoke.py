"""One admitted QA continuation; existing CLI and readers only, no rescue/retry."""
import hashlib
import json
import os
import stat
import subprocess
import sys
import time
import tomllib
from pathlib import Path

WT = Path('/home/kali/.hermes/cache/scratch/settings-supervisor-tcp-20261030')
OBS = Path('/home/kali/.hermes/cache/scratch/settings-supervisor-tcp-evidence-20261030')
OUT = Path('/home/kali/.hermes/cache/scratch/settings-sol-team-b45fd55/stopped-continuation-qa')
BASE = Path('/home/kali/.hermes/cache/scratch/s4-6s7mt9bt')
ROOT, CONTROL = BASE / 's/omnis', BASE / 'r/omnis'
DATA = Path('/home/kali/.hermes/cache/scratch/omnis-bundle-xi8ua6is/data')
CLI = '/home/kali/.hermes/cache/scratch/omnis-bundle-xi8ua6is/cli/bin/omnis'
WORKSPACE = Path('/home/kali/.hermes/cache/scratch/settings-sol-team-b45fd55/tcp-normal-attempt-1/development-f84ded1e534f')
UUID = 'fd7d96a8-2441-4176-bc34-de8b2e5e8e31'
ORIGIN = 'http://127.0.0.1:60349'
ENV = dict(PATH='/usr/bin:/bin', HOME=str(BASE), XDG_DATA_HOME=str(DATA), XDG_CONFIG_HOME=str(BASE / 'config'), XDG_STATE_HOME=str(BASE / 's'), XDG_RUNTIME_DIR=str(BASE / 'r'), TMPDIR='/home/kali/.hermes/cache/scratch')
sys.path[:0] = [str(WT / 'cli/integration'), str(OBS)]
from omnis_cli.start import preflight_port
from omnis_cli.start_runtime import ControlRuntime
from omnis_cli.development import selection
from omnis_cli.control import request
from omnis_cli.lifecycle import process_identity
from omnis_cli.stop_receipt import completed_receipt, receipt_path, validate_grant, validate_inventory
from installed_start import assert_resources_absent, resource_snapshot
from installed_stop import SUPERVISOR_START_SECONDS, SUPERVISOR_STOP_SECONDS, SUPERVISOR_READBACK_SECONDS
from observe_native_case import summarize

begin = time.monotonic()
deadline = begin + 600
result = dict(scope='SAME_OWNED_STOPPED_FIXTURE_CONTINUATION', cause='UNKNOWN', start_calls=0, stop_calls=0, observation='NOT_RUN', cleanup='NOT_RUN', historical='old2/2 + diagnostic1/1 + team-normal1FAIL + direct-prefix1FAIL retained')
runtime = None
record = None
start_valid = False
failure = None
config_hash = None
old_hashes = {}

def need(reserve=0):
    left = deadline - time.monotonic() - reserve
    if left <= 0:
        raise TimeoutError('COMMON_600_BUDGET')
    return left

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(name, value):
    fd = os.open(OUT / name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'w') as stream:
        json.dump(value, stream, ensure_ascii=True, indent=2)
        stream.flush()
        os.fsync(stream.fileno())
    directory = os.open(OUT, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(directory)
    finally:
        os.close(directory)

def cli_call(name, args, timeout, reserve=0):
    argv = [CLI, *args]
    save(name + '-command.json', dict(argv=argv, timeout=timeout, reserve=reserve, common_deadline=deadline))
    need(timeout + reserve)
    started = time.monotonic()
    try:
        completed = subprocess.run(argv, cwd=BASE / 'cwd', env=ENV, capture_output=True, text=True, timeout=timeout, check=False)
    except BaseException as exc:
        save(name + '-result.json', dict(argv=argv, returncode=None, error=type(exc).__name__, elapsed=time.monotonic() - started))
        raise
    save(name + '-result.json', dict(argv=argv, returncode=completed.returncode, stdout=completed.stdout, stderr=completed.stderr, elapsed=time.monotonic() - started))
    need(reserve)
    return completed

def public_identity(value):
    assert value['instance_id'] == UUID and value['origin'] == ORIGIN
    assert value['release'] == '0.1.1' and value['schema'] == '0017_model_removal'

def fail(phase, exc):
    global failure
    item = dict(phase=phase, error=type(exc).__name__, public_reason=getattr(exc, 'reason', None))
    if failure is None:
        failure = item
    result.setdefault('errors', []).append(item)

assert stat.S_IMODE(OUT.stat().st_mode) == 0o700
save('plan.json', dict(candidate='f7f0c8cdbab0d41260efeb027dc21d901be32dfb', data_home=str(DATA), root=str(ROOT), control=str(CONTROL), cwd=str(BASE / 'cwd'), environment=ENV, workspace=str(WORKSPACE), start=[CLI, 'start', '--no-open', '--json'], stop=[CLI, 'stop', '--json'], intervals=dict(total=600, start=SUPERVISOR_START_SECONDS, stop=SUPERVISOR_STOP_SECONDS, readback=SUPERVISOR_READBACK_SECONDS), policy='one Start; optional90s; one normal Stop after valid READY; no retry/rescue/recovery'))
try:
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WT, text=True).strip() == 'f7f0c8cdbab0d41260efeb027dc21d901be32dfb'
    assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=WT, text=True) == ''
    freeze = json.loads((OBS / 'FREEZE-r2-fix.json').read_text())
    for rel, expected in freeze['prepared_source'].items():
        assert digest(WORKSPACE / rel) == expected
    for rel, expected in freeze['adapted'].items():
        assert digest(OBS / rel) == expected
    config = BASE / 'config/omnis/config.toml'
    config_hash = digest(config)
    cfg = tomllib.loads(config.read_text())
    assert cfg['port'] == 60349 and cfg['development_workspace'] == str(WORKSPACE)
    for path in [BASE / 'probe-receipt.json', *sorted(BASE.glob('command-0[123]-*.json')), Path('/home/kali/.hermes/cache/scratch/settings-sol-team-b45fd55/direct-prefix-attempt-1/run.log')]:
        old_hashes[str(path)] = digest(path)
    pg_before = (ROOT / 'postgres').stat()
    status_result = cli_call('01-preflight-status', ['status', '--json'], 15, 550)
    assert status_result.returncode == 0
    status = json.loads(status_result.stdout)
    public_identity(status)
    assert status['state'] == 'STOPPED' and status['generation'] == 2 and status['mode'] == 'RELEASE'
    record = json.loads((ROOT / 'startup.json').read_text())
    assert record['phase'] == 'STOPPED' and record['instance_id'] == UUID and selection(record) is None
    need(550)
    runtime = ControlRuntime(DATA, min(time.monotonic() + 30, deadline - 550))
    assert runtime.receipt.project == 'omnis-local-ea23cc8205dd499a89a6eaf7ebcf72a9'
    assert runtime.receipt.image_id == 'sha256:f33c4c2fe8072d9a8f66979d9114114b3a24bcd5522ebb751c64f902b9ed2151'
    assert runtime.digest == 'f09766be6239f6eed62c0e22aed0b5acd6ee2a3658f239e6e78636ff99260262'
    assert runtime.receipt.docker_id == '94260307-c33f-46ac-af7c-8a5ac1a7ffdc' and runtime.host == 'unix:///run/docker.sock'
    assert runtime.receipt.profile == 't1-provider-settings' and runtime.schema == '0017_model_removal'
    assert runtime.ids() == [] and runtime.network(set()) is None
    assert not runtime.uncertain and runtime.family_drained
    preflight_port(60349)
    save('preflight.json', dict(status=status, prepared_files=len(freeze['prepared_source']), observer_files=len(freeze['adapted']), config_sha256=config_hash, old_originals=old_hashes, project_empty=True, preflight_port_no_reuse=True, schema=runtime.schema, manifest=runtime.digest, daemon=runtime.receipt.docker_id))
    need(550)
    save('admission.json', dict(action='ONE_EXPLICIT_DEVELOPMENT_START_THEN_ONE_NORMAL_STOP', candidate='f7f0c8cdbab0d41260efeb027dc21d901be32dfb', instance_id=UUID, generation=2, origin=ORIGIN, common_begin=begin, common_deadline=deadline, claim_wall_ns=time.time_ns(), source='current explicit parent/user mandate', history=result['historical']))
    need(550)
    preflight_port(60349)
    result['start_calls'] = 1
    started_result = cli_call('02-start', ['start', '--no-open', '--json'], SUPERVISOR_START_SECONDS, SUPERVISOR_STOP_SECONDS + SUPERVISOR_READBACK_SECONDS)
    result['start_exit'] = started_result.returncode
    started = json.loads(started_result.stdout)
    result['start_public'] = started
    if started_result.returncode != 0:
        result['verdict'] = 'FAIL_START_REFUSED_NO_RETRY'
        raise RuntimeError('ACTUAL_START_REFUSAL')
    public_identity(started)
    assert started['state'] == 'READY' and started['mode'] == 'DEVELOPMENT' and started['assessment_ready'] is False
    record = json.loads((ROOT / 'startup.json').read_text())
    assert record['instance_id'] == UUID and record['port'] == 60349 and record['phase'] == 'READY'
    assert selection(record) == str(WORKSPACE)
    runtime.attempt = record['attempt']
    runtime.development_workspace = selection(record)
    start_valid = True
    runtime.deadline = min(time.monotonic() + 30, deadline - 240)
    snapshot = resource_snapshot(runtime, ROOT, CONTROL, 60349)
    save('ready-readback.json', dict(status=started, attempt=record['attempt'], containers=record['containers'], snapshot=snapshot, generation=record['generation'], workspace=selection(record)))
    observe_until = deadline - SUPERVISOR_STOP_SECONDS - 2 * SUPERVISOR_READBACK_SECONDS - 15
    if time.monotonic() + 90 >= observe_until:
        result['observation'] = 'NOT_RUN_INSUFFICIENT_FULL_WINDOW'
    else:
        initial = request(CONTROL, {'op': 'status'}, deadline=observe_until)
        assert initial['instance_id'] == UUID and initial['generation'] == started['generation']
        until = time.monotonic() + 90
        assert until < observe_until
        samples = [dict(elapsed=0, status=initial)]
        quiet_begin = time.monotonic()
        while time.monotonic() < until:
            time.sleep(min(1, max(0, until - time.monotonic())))
            assert time.monotonic() < observe_until
            current = request(CONTROL, {'op': 'status'}, deadline=observe_until)
            samples.append(dict(elapsed=time.monotonic() - quiet_begin, status=current))
            assert current['supervisor_ready'] is True
            assert all(current[key] == initial[key] for key in ('instance_id', 'supervisor_epoch', 'generation', 'admission_open'))
        save('quiet-statuses.json', samples)
        result['observation'] = 'COMPLETED_90S_CAUSE_UNKNOWN'
        result['quiet_seconds'] = time.monotonic() - quiet_begin
        result['status_reads'] = len(samples)
        runtime.deadline = min(time.monotonic() + 15, deadline - 240)
        census = runtime.psql(record['containers']['db'], 'SELECT (SELECT count(*) FROM system_operation),(SELECT count(*) FROM model_dispatch_v2)')
        save('read-only-census.json', dict(query='SELECT (SELECT count(*) FROM system_operation),(SELECT count(*) FROM model_dispatch_v2)', observed=census))
        assert census == '0|0'
        result['census'] = census
except BaseException as exc:
    fail('PREFLIGHT_START_OR_OBSERVATION', exc)
finally:
    if start_valid:
        try:
            need(240)
            runtime.deadline = min(time.monotonic() + 15, deadline - 240)
            logs = runtime.run('logs', record['containers']['supervisor'], cap=15, success=False)
            allowed = [line for line in (logs.stdout + '\n' + logs.stderr).splitlines() if line.startswith(('SUPERVISOR_FAILURE ', 'SUPERVISOR_LEASE_TRACE ', 'SUPERVISOR_UNAVAILABLE', 'SUPERVISOR_READY'))]
            save('supervisor-allowlisted-before-stop.json', dict(returncode=logs.returncode, lines=allowed))
            if failure is not None:
                public = cli_call('03-failure-status', ['status', '--json'], 5, 240)
                result['first_failure_public_exit'] = public.returncode
                result['first_failure_public'] = json.loads(public.stdout)
            assert not runtime.uncertain and runtime.family_drained
            need(240)
            result['stop_calls'] = 1
            stopped_result = cli_call('04-stop', ['stop', '--json'], SUPERVISOR_STOP_SECONDS, SUPERVISOR_READBACK_SECONDS)
            result['stop_exit'] = stopped_result.returncode
            stopped = json.loads(stopped_result.stdout)
            result['stop_public'] = stopped
            assert stopped_result.returncode == 0 and stopped['state'] == 'STOPPED'
            public_identity(stopped)
            final_record = json.loads((ROOT / 'startup.json').read_text())
            assert final_record['phase'] == 'STOPPED' and final_record['instance_id'] == UUID
            runtime.deadline = min(time.monotonic() + SUPERVISOR_READBACK_SECONDS, deadline)
            runtime.check_daemon()
            assert_resources_absent(runtime, ROOT, CONTROL, final_record)
            rp = receipt_path(ROOT, final_record)
            receipt = json.loads(rp.read_text())
            completed_receipt(rp, receipt['grant'])
            validate_inventory(receipt['grant']['inventory'], final_record)
            validate_grant(receipt['grant'], final_record, receipt['grant']['inventory'])
            original_alive = []
            for identity in (receipt['owner'], receipt['launcher'], final_record['forwarder']):
                try:
                    observed = process_identity(identity['pid'])
                except (FileNotFoundError, ProcessLookupError):
                    continue
                if all(observed[key] == identity[key] for key in ('pid', 'start_ticks', 'boot_id')):
                    original_alive.append(identity['pid'])
            assert not original_alive
            for table in ('tcp', 'tcp6'):
                for row in Path('/proc/net/' + table).read_text().splitlines()[1:]:
                    fields = row.split()
                    assert not (fields[3] == '0A' and int(fields[1].split(':')[1], 16) == 60349)
            pg_after = (ROOT / 'postgres').stat()
            assert (pg_before.st_dev, pg_before.st_ino) == (pg_after.st_dev, pg_after.st_ino)
            assert not runtime.uncertain and runtime.family_drained
            save('stop-readback.json', dict(public=stopped, phase=final_record['phase'], project_empty=True, exact_cids=list(final_record['containers'].values()), ipc_absent=True, listener_absent=True, daemon=runtime.receipt.docker_id, completed_receipt=str(rp), receipt_sha256=digest(rp), receipt_state=receipt['state'], stages=receipt['completed'], original_processes_absent=True, pgdata_same_inode=True, family_evidence='COMPLETED validated product receipt + pinned-identity absence + exact resource readback'))
            result['cleanup'] = 'VERIFIED_NORMAL_STOP_ACK_RECEIPT_EXACT_READBACK'
            events_path = CONTROL / 'sol-events.jsonl'
            assert events_path.is_file() and events_path.stat().st_size <= 32 * 1024 * 1024
            raw = events_path.read_bytes()
            fd = os.open(OUT / 'raw-sol-events.jsonl', os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
            with os.fdopen(fd, 'wb') as stream:
                stream.write(raw); stream.flush(); os.fsync(stream.fileno())
            result['events_original'] = str(events_path)
            result['events_sha256'] = hashlib.sha256(raw).hexdigest()
            summary = summarize(events_path)
            save('observer-summary.json', summary)
            result['observer_summary'] = summary
        except BaseException as exc:
            fail('STOP_READBACK_OR_SUMMARY', exc)
            if result['cleanup'] == 'NOT_RUN':
                result['cleanup'] = 'UNCERTAIN_RETAIN_NO_RESCUE'
    try:
        if config_hash is not None:
            assert digest(BASE / 'config/omnis/config.toml') == config_hash
        for path, expected in old_hashes.items():
            assert digest(Path(path)) == expected
        result['originals_and_config_unchanged'] = True
        if result['cleanup'].startswith('VERIFIED'):
            final_status_result = cli_call('05-final-status', ['status', '--json'], min(10, need()), 0)
            final_status = json.loads(final_status_result.stdout)
            assert final_status_result.returncode == 0 and final_status['state'] == 'STOPPED'
            public_identity(final_status)
            result['final_status'] = final_status
    except BaseException as exc:
        fail('FINAL_STATUS_OR_ORIGINAL_INTEGRITY', exc)
    result['elapsed_seconds'] = time.monotonic() - begin
    result['common_budget_seconds'] = 600
    result['first_failure'] = failure
    result['verdict'] = 'PASS_SCOPED_QUIET_CAUSE_UNKNOWN' if failure is None and result['observation'] == 'COMPLETED_90S_CAUSE_UNKNOWN' and result['cleanup'].startswith('VERIFIED') else result.get('verdict', 'FAIL_OR_INCOMPLETE_RETAINED')
    save('result.json', result)
    print(json.dumps(result, ensure_ascii=True), flush=True)
    raise SystemExit(0 if result['verdict'] == 'PASS_SCOPED_QUIET_CAUSE_UNKNOWN' else 1)
