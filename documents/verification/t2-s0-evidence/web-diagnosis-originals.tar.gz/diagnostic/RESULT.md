# Diagnostic PHASE1 — NOT_REPRODUCED; fără fix justificat

Bază explicită: `90eb7041fb928098f35aa2916f77772b2b1e1dfa`. Copia `checkout/` este EXCLUSIV DIAGNOSTICĂ, NU CANDIDAT DE PRODUS. Main nu a fost editat; fără commit. Counterul anterior harness-only2 se păstrează.

## Rezultat real

- `npm run typecheck`: exit0.
- Calibrare în callerul existent ProjectionStates/App, proces separat: exit0, 2/2 controale SOURCE PASS; celelalte 8 cazuri din fișier neselectate numai în această calibrare.
- O SINGURĂ suită web completă instrumentată: `npm test -- --reporter=default --reporter=json --outputFile=<scratch>/wholeweb-results.json`, exit0, 354/354 PASS, 20/20 fișiere, 43.831s wall. Wrapperul `timeout --signal=TERM --kill-after=5 240 unshare --user --map-root-user --net` impune numai plafon exterior și namespace fără rețea. Configul, timeouturile Vitest/Testing Library și workerii impliciți nu au fost modificați. NODE_ENV=test provine din scriptul original.
- Manifestele instalate comparate cu lock: Node24.21.0/npm11.19.0, Vitest4.1.12, jsdom30.1.1, TanStack5.103.2, React19.3.0.
- JSON-urile au fost agregate programatic. Exact 3 trace-uri naturale, 0 evenimente abandonate; fiecare capturat în finally înainte de cleanup.

## Calibrare discriminantă, nu cauză istorică

1. Notificări reținute explicit prin schedulerul existent: session cache SUCCESS și DOM bootstrap loading, enqueue prezent/run absent; eliberare prin defaultScheduler → notificări rulate → commit și locatorul original Dashboard. PASS.
2. Răspuns Dashboard reținut prin deferred-ul existent, `client.cancelQueries` real cu silent=true: abort observat, `Query.fetch` respins cu CancelledError/silent/revert; după eliberarea răspunsului nu există cache success ori link Dashboard. PASS. Nu a fost fabricat un CancelledError și nu au fost schimbate guardurile auth/epoch/readPrivate.

Controalele au fost îndepărtate din copia pentru wholeweb, păstrate byte-exact în `calibration-artifact/`. Nicio a doua încercare de calibrare sau suite wholeweb.

## Timeline natural

Toți timpii sunt monotonic ms față de begin-ul cazului, nu măsurători ale deadline-ului locatorului.

| Caz inițial | Commit inițial utilizabil | Max enqueue→run până la acel commit | Anulări inițiale |
|---|---:|---:|---:|
| ProjectionStates | 677.049 | 133.134 | 0 |
| SettingsModels/Skills | 674.756 | 77.145 | 0 |
| SettingsWizard | 864.428 | 84.516 | 0 |

Session API și Query.fetch s-au rezolvat în fiecare caz; Dashboard API/query au ajuns la success; ambele bindinguri Settings au digest resolved și commit ulterior. React Profiler raportează numai commit/faze finite; fără date de query, tokenuri, granturi, request bodies sau DOM brut. Trace-urile includ întreg primul test; anularea/401 intenționată de la finalul testului ProjectionStates nu este atribuită inițializării.

**Decizie:** defectul inițial nu a fost reprodus; cauza istorică rămâne UNKNOWN. Controalele demonstrează că observarea discriminează două mecanisme, nu că notificarea reținută explică FAIL-ul istoric. Nu există bază cauzală pentru schimbare de produs, teardown, scheduler, workers sau timeout. S0/gate-ul canonic și review/QA rămân la adjudecarea părintelui; această suită diagnostică nu închide singură S0.

## Artefacte și integritate

- `calibration-command.json`, `typecheck-command.json`, `wholeweb-command.json`: argv, mediu finit, exit și durată.
- `calibration.log`, `wholeweb.log`: output real; `*-results.json`: rapoarte Vitest.
- `calibration-traces.json`, `wholeweb-traces.json`, `timeline-summary.json`, `selected-cases.json`: extrase/aggregate programatic, nu output inventat.
- `original-files/`: cele 3 teste originale; `calibration-artifact/` și `wholeweb-artifact/`: cele 4 fișiere temporare (3 calleri și `tests/startup-diagnostic.tsx`).
- `baseline-sha256.json`, `calibration-sha256.json`, `wholeweb-sha256.json`, `product-source-sha256.json`, `verification.json`: freeze și readback.
- Verificat după execuție: toate cele 103 fișiere web tracked din main identice cu baza; în scratch 100 fișiere tracked neinstrumentate identice și toate cele 4 artefacte instrumentate identice cu freeze. Starea Git main neschimbată, inclusiv cele două căi untracked protejate, necitite.
- Copia instrumentată rămâne explicit diagnostică; nicio instalare/operator asset sau dependență produs schimbată. node_modules este copie privată a instalației izolate admise.

## Abatere de izolare și limite

La primul `npm run typecheck`, notificatorul automat npm a efectuat un GET public neautorizat la `https://registry.npmjs.org/npm`, status200,241ms, consemnat în logul npm din HOME privat. Nu a fost apel provider/țintă și nu s-au transmis inputuri ale aplicației; nu revendic no-network pentru pregătire/calibrare. După constatare: update_notifier=false, offline=true, audit=false, fund=false; wholeweb a rulat într-un namespace de rețea separat, precedat de preflight unshare exit0. Această abatere trebuie păstrată în adjudecare.

Nu am testat browserul real, runtime/API/DB/operator, provider, S1, ori cauza istorică. Instrumentarea adaugă overhead; un PASS observat nu infirmă un defect rar. Fără comparație de concurență sau rerun automat. Reticle NOT_INTEGRATED, Chisel BLOCKED_NO_GO.
