"""One recorded invocation of the existing owner; no new lifecycle implementation."""
import hashlib
import json
import os
from pathlib import Path
import sys
import time

ROOT = Path('/home/kali/.hermes/cache/scratch/settings-supervisor-tcp-20261030')
OUT = Path(__file__).parent
DATA = Path('/home/kali/.hermes/cache/scratch/omnis-bundle-xi8ua6is/data')
CLI = '/home/kali/.hermes/cache/scratch/omnis-bundle-xi8ua6is/cli/bin/omnis'
WORKSPACE = '/home/kali/.hermes/cache/scratch/settings-sol-team-b45fd55/tcp-normal-attempt-1/development-f84ded1e534f'
sys.dont_write_bytecode = True
if Path.cwd() != ROOT or sys.flags.optimize or not sys.flags.isolated:
    raise RuntimeError('Exact isolated invocation required')
if hashlib.sha256((ROOT / 'cli/integration/installed_stop.py').read_bytes()).hexdigest() != 'e9ea1dc575388330ab75d6f0fcf30c93cbba8c8e8d017f48d83e9c0c1750254e':
    raise RuntimeError('Reviewed consumer drift')
sys.path[:0] = [str(ROOT / 'cli/src'), str(ROOT / 'cli/integration'), '/home/kali/.hermes/cache/scratch/settings-supervisor-tcp-evidence-20261030']
from installed_stop import run_installed_stop
from observe_native_case import summarize

started = time.monotonic()
deadline = started + 600
fd = os.open(OUT / 'claim.json', os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
with os.fdopen(fd, 'w') as claim:
    json.dump({'candidate': 'f7f0c8cdbab0d41260efeb027dc21d901be32dfb', 'wall_ns': time.time_ns(), 'maximum_seconds': 600, 'attempts': 1, 'mode': 'existing_owner_prepared_input_no_rebuild'}, claim)
    claim.flush()
    os.fsync(claim.fileno())
directory = os.open(OUT, os.O_RDONLY | os.O_DIRECTORY)
try:
    os.fsync(directory)
finally:
    os.close(directory)
receipt = json.loads((DATA / 'omnis/image.json').read_text())
events = run_installed_stop(DATA, receipt, CLI, supervisor_observation={'workspace': WORKSPACE, 'deadline': deadline})
result = {'events': str(events), 'summary': summarize(events), 'elapsed_seconds': time.monotonic() - started}
print('DIRECT_SUPERVISOR_RESULT ' + json.dumps(result), flush=True)
# Completion of a diagnostic is not a demonstrated causal repair.
raise SystemExit(3)
