# QA S1 instalat — FAIL / INSTALLED_NOT_RUN

- Snapshot exact: `880ac42f0d4462c7dd006607835cd8bb4b56523d`, detached, curat înainte și după.
- Checkout: `/home/kali/.hermes/cache/scratch/omnis-s1-runtime-qa-a8d9f68c`.
- O singură invocare: `make check-installed-stop UV=/home/kali/.local/share/omnis-toolchains/bin/uv`, prin `ops/run_test_db_gate.py::run_gate(command, env, log, 1800)`, importat în `api/.venv/bin/python -I -B`. Fără runner `--check`, fără PG suplimentar, fără retry/edit/rescue extern.
- Execuție: 2026-11-05 06:16:32–06:20:31 UTC; **238.71640799799934s, exit 2**. Proces terminal `proc_efea7c94a731`, PID launcher2875912 terminat. Receipt separat: `{"schema_version":1,"code":2,"family_drained":true}`.

## Ce a trecut și unde s-a oprit

- Preflight: importuri din checkoutul exact; Python3.13.15, uv0.12.19, Node24.21.0, npm11.19.0; imaginile locale fixate postgres18.6/python3.13.15; daemon94260307-c33f-46ac-af7c-8a5ac1a7ffdc/27.5.1, endpoint Unix. Producerul Compose sursă + overlay S1 au trecut `start.validate_config` real pe fixture sintetică existentă; controalele existente pentru catalog înlocuit/symlink au refuzat. Nu este probă runtime instalată.
- HOME privat existent: `/home/kali/.hermes/cache/scratch/s1-env-20261104/home`; PATH: `/home/kali/.local/share/omnis-toolchains/bin:/usr/local/bin:/usr/bin:/bin`.
- TMPDIR nou0700: `/home/kali/.hermes/cache/scratch/s1i-7srtx1f8`; calea socket estimată79bytes ≤107. `UV_PYTHON_INSTALL_DIR=/home/kali/.local/share/uv/python`, `UV_OFFLINE=1`, `UV_PYTHON_DOWNLOADS=never`, `UV_LINK_MODE=copy`; niciun opt-in development/upgrade/start/pair-open/control extern.
- **465 teste CLI/wheel PASS,208.621s**, build web trecut, Ruff check/format și mypy au permis intrarea în integrare.
- `check-release-install`: **83 teste executate,79PASS/1FAIL/3SKIP,16.957s**. Eșecul este `test_real_api_web_and_cli_bundle_is_checkout_independent` la `cli/integration/test_release.py:1504`, helperul `run` la1452: `AssertionError: 2 != 0 : .../cli/.venv/bin/python returned 2`.
- Consumerul invoca `ops/build_control_bundle.py --api-wheel <scratch>/api-wheel/... --cli-wheel <scratch>/cli-wheel/... --requirements <scratch>/requirements.txt --web-root <checkout>/web/dist --output <scratch>/bundle`. Exitul builderului observat este2; `make` se oprește la `Makefile:334`, înaintea rețetei `Makefile:363`.
- **Clasificare observată:** prerechizit de distribuție/bundle, anterior instalării; cauza internă SOURCE versus fixture/environment rămâne **UNKNOWN**. Helperul capturează stderr, dar nu îl include în assertion; scratchul bundle a fost șters de consumer. Nu atribuim defect de produs lifecycle sau `COLD_CATALOG_UNSUPPORTED` și nu reconstruim stderr-ul pierdut.
- **NOT_RUN:** manifestul final0.1.2/0019 instalat, `install-image`, Start/status/Stop/restart/sentinel și emergency Stop. Nu există receipt instalat/image, CID/proiect/tag propriu de produs sau PGDATA instalat de verificat. Probele source negative ale prerechizitului nu sunt acestea.

## Readback și material păstrat

- Inventare Docker recitite după terminare, comparate pe identități/stări: **34→34 containere,15→15 rețele,112→112 volume,101→101 rânduri imagini**, fără adăugări/eliminări; containerele inițiale erau toate oprite. Daemon identic.
- Launcher absent; niciun proces găsit cu argumentele TMPDIRului; receiptul ownerului confirmă familia drenată. Nicio rădăcină bundle sau image receipt rămasă. Repo curat, HEAD neschimbat.
- **Nu afirmăm absența tuturor inode-urilor socket.** Există socketul stale `/home/kali/.hermes/cache/scratch/s1i-7srtx1f8/s2i-b_oz9i0x/s/omnis/http/api.sock` și receipt `project=test-only`, `probe=FAIL`, `cleanup=UNCERTAIN`, păstrate intenționat de controlul negativ existent `start_oracle_probe.py::assert_failure_rescued` (NoDocker). Testul exterior a trecut; `/proc/net/unix` nu conține niciun socket live al TMPDIRului. Nicio curățare/adopție nouă; acest receipt nu este rezultat installed și nu este promovat la PASS.
- Wheel CLI produs/păstrat: `/home/kali/.hermes/cache/scratch/s1i-7srtx1f8/omnis-p04-cli-wheel/omnis_cli-0.1.2-py3-none-any.whl`, SHA256 `27e291e9d6eb61f13bd24d18e5697c33973b43bda4549bf0ce5708ac8c33f5e8`. Nu este hashul unui bundle instalat reușit.
- Nu s-a editat/comis sursă, test, documentație ori skill; numai artefacte ignorate de build și evidence privată. `tempkey.txt`, HTMLul original și credentialele operatorului nu au fost citite.

## Locatoare originale

Director evidence: `/home/kali/.hermes/cache/scratch/s1-env-20261104/run-evidence/installed-880ac42f/`.

- `gate.log` — log original privat; linii519–521 CLI PASS,634/654–679 eșecul bundle,680 oprirea make.
- `gate.log.result.json` — receipt original de familie.
- `execution.json` — argv, pinuri citite în procesul gate, exit și durată.
- `preflight.json`, `tmpdir.txt` — preflight și locator.
- `inventory-before.json`, `inventory-after.json`, `readback.json` — inventare/readback/hash CLI.
- `safe-log-summary.json`, `ipc-readback.json`, `source-oracle-readback.json` — extrase sigure și limita socketului sintetic.

Observații preflight păstrate: Python nu era descoperit inițial sub HOME privat(exit2), rezolvat exclusiv prin selecția pinului deja existent; fără install. Au existat dry-runuri pip auxiliare nerelevante pentru fast-pathul nativ uv (`hatchling` și `uv_build`, cache indisponibil); nu au instalat nimic și buildul real ulterior a trecut. Prima citire text `/proc/net/unix` a întâlnit un pathname non-UTF8; citirea bytes, fără modificări, a verificat absența căilor live proprii.

## Predare

**S1 rămâne neînchis; installed BLOCKED/NOT_RUN.** Părintele citește receiptul și readbackul exacte, apoi decide diagnoza minimală separată pentru refuzul builderului; această sesiune nu rerulează și nu remediază.

Neexecutat: control fizic RUN, canonical, provider/model/ținte, operator/rollout, upgrade/backup, S2–S7/A/push. Reticle NOT_APPLICABLE; Chisel BLOCKED_NO_GO.
Risc: cauza internă a builderului nu a fost păstrată de consumer; niciun PASS installed nu poate fi dedus din teste source/build sau din familia drenată.
