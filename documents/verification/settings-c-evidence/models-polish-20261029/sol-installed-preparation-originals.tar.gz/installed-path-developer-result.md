DELTA PREGĂTIRE DIAGNOSTICĂ — CANDIDAT SOURCE, NU ACCEPTARE

Bază/worktree: 9eb87fd11c63490f3d7afa4d7e97efb45decf20f, /home/kali/.hermes/cache/scratch/settings-supervisor-tcp-20261030. Singurul fișier modificat: cli/integration/test_release.py (206 inserări/35 ștergeri, inclusiv controalele SOURCE). Fără stage/commit. Main a rămas b45fd552cd8c5c45eefbe2d47127fd02365f73c1, tracked/index fără diff.

Schimbare

- Callerul CONTROL nu mai inserează --network=none. Toate argumentele normale sunt transmise identic, inclusiv --pull=false; pull explicit rămâne refuzat cu97. Dockerfile/bundle/pini/hashes/profil/UID și production code sunt neschimbate.
- În rootul fresh al fixture-ului, preparation/ este creat privat0700 înaintea pregătirii CLI. Pentru venv/pip/install/install-image: sink0600, O_EXCL|O_NOFOLLOW, command fsync înaintea apelului; returncode/stdout/stderr fsync înaintea assertionului. Excepția este consemnată și retransmisă, nu transformată în succes.
- Numai buildul folosește preparation/docker-build.{stdout,stderr,jsonl}: toate sinkurile sunt deschise exclusiv înaintea buildului; command este persistat înaintea efectului, apoi codul real și outputurile înaintea întoarcerii în CLI. Inspect/context/info păstrează exec direct și stdout/stderr originale pentru attestare. Coliziunea/symlinkul/directorul unwritable refuză înaintea stubului-build; niciun fișier existent nu este suprascris.
- Decizie explicită pentru review: exec direct NU poate consemna propriul cod după înlocuirea procesului. De aceea shimul existent așteaptă numai buildul prin subprocess.run cu fișierele ca fd-uri, fără PIPE/tee, sesiune/process group, timeout sau cleanup nou; run_cli_scope rămâne ownerul existent al întregului grup. Pentru non-build rămâne os.execv. Codul pozitiv și terminarea prin semnal sunt propagate; SIGKILL nu este tratat ca un handler instalabil. Nu prezint această alegere drept aprobare independentă.

Dovezi reale SOURCE

- red.log: 2 teste,5 assertion failures, exit1,0.371s. A observat argumentul --network=none introdus, pierderea rezultatului CLI și execuție în ciuda celor3 sinkuri refuzate.
- green.log: primul GREEN3teste/0.460s/exit0. Apoi controlul de cod exact prin SIGKILL a reprodus un defect al noii propagări: signal-red.log,1test/1FAIL/exit1/0.745s,1 în loc de-9. Remediu local: nu instala handler pentru semnalele nemodificabile; nu a fost reparație de infrastructură/harness.
- final-checks.log, pe bytes finali: Python3.13.15 -I -B;3teste PASS0.499s/exit0. Controlul shimului execută exclusiv un executabil inert pentru build17, SIGKILL-9, inspect/output, pull97, symlink, coliziune și unwritable. Controlul callerului păstrează CLI2/stdout/stderr înaintea assertionului și nu ajunge la ownerul instalat. F01 late-preparation trece neschimbat. Ruff check/format --check/git diff --check: toate exit0.
- run_cli_scope, bundle_scratch și metoda F01 sunt byte-identice ca sursă cu baza; cele3 fișiere integration rămase și cele6 scripturi originale au hashes egale cu FREEZE-r2-fix.json. F02 și celelalte dovezi19SOURCE/1SKIP se reutilizează numai pe bytes neafectați; nu le-am rerulat ceremonial.

Freeze pentru reviewul părintelui

Director: /home/kali/.hermes/cache/scratch/settings-sol-team-b45fd55/installed-path-fix/
FREEZE.json SHA256: 54556f882bb8ff9bb53af51e4ec8576a0c3fb252d68c828c03bc6ef9d2a09edf
candidate.patch SHA256: 51e290d11cbcb8158c56f688da918472b87cf677952504d7a140b906cd8d1cdb
test_release.py SHA256: bb2e3dad4c2cba0306d6bc486b312865ae8a34fb47271faaf247dbd81692d9b7
Manifestul leagă baza/blobul, patchul, toate5 checklogs și cele9 bindings păstrate. Nu există commit candidat nou și nici autoaprobare; integrarea granulară și reviewul independent sunt ale părintelui.

Comanda reală PROPUSĂ după review și admitere distinctă — NU executată

Originalul run_native.py fixează ROOT la worktree-ul de mai sus, care este încă traseul corect; nu necesită rebind dacă acesta rămâne consumerul revizuit. OUT este însă directorul scriptului și conține claimul consumat. Părintele trebuie să pregătească un director nou privat, de exemplu installed-path-fix/admitted-tcp-next/, cu copii byte-exact ale celor5 fișiere originale run_native.py, observe_existing.py, native_bootstrap.py, native_witness.py și observe_native_case.py. Nu copia vechiul diagnostic-admission.json, workspace-ul sau logurile și nu modifica originalele. preflight-ul însuși poate crea noul workspace, deci nu îl executa drept dry-run fără efecte.

Din cwd /home/kali/.hermes/cache/scratch/settings-supervisor-tcp-20261030, numai după acele prerechizite și noua admitere:

  env -i PATH=/home/kali/.local/share/omnis-toolchains/bin:/usr/bin:/bin HOME=/home/kali/.hermes/cache/scratch/settings-sol-team-b45fd55/installed-path-fix/admitted-tcp-next TMPDIR=/home/kali/.hermes/cache/scratch /home/kali/OmnisAI/api/.venv/bin/python -I -B /home/kali/.hermes/cache/scratch/settings-sol-team-b45fd55/installed-path-fix/admitted-tcp-next/run_native.py --run

Nu folosi tee/pipeline pentru a deduce exitul exterior; păstrează direct rezultatul procesului. Semantica runnerului original este2 la eșecul testului și3 după observație completă, nu exit0/PASS de remediere. Deadline-ul agregat600s, rezervele Start/Stop și ownerul nu au fost schimbate. Directorul propus și copiile NU au fost create în acest turn.

Limite de admitere

Zero Docker/build/install/DB/lifecycle/network/provider/model executate. Numai stubs SOURCE și fișiere temporare proprii. Nu s-au atins intentul eșuat, claimul vechi, originalele9eb87fd sau analiza inițială. Contoarele istorice2/2+1/1 rămân consumate; următoarea invocare necesită înregistrare nouă justificată de părinte.

Buildul normal poate solicita DNS/HTTPS PyPI/files.pythonhosted.org. requirements are39 intrări declarate cu markeri; --require-hashes nu fixează automat dependențele unui build-isolation sdist. Nu am adăugat wheels-only/wheelhouse/alt Dockerfile ca să ascund limita; acordul pentru aceste efecte trebuie delimitat înainte de execuție. Vechiul CLI2 rămâne cauză UNKNOWN; acest patch nu demonstrează cache-miss, nu repară supervisorul și nu promite READY stabil.
