# S0 — minimal SOURCE pin fix, frozen for independent review

Only modified repository file: `api/tests/test_model_test_prepare_source.py` (4 additions / 2 deletions). Exact assertions at current lines1607/2369 now require OpenAI2.45.0; both comments distinguish current API SOURCE from the historical native pin. No runtime/dependency/fixture/marker changes; no commit by the child.

## Identity

- Entry HEAD: `d1fb8d42926b88ea6997e3fa56f531c8eec56faf`.
- Parent advanced HEAD to `fa28be79fb4be40f07486814169b1c98922bd657` while work ran, adding only two canonical-failure evidence files. `git diff --exit-code d1fb8d42926b88ea6997e3fa56f531c8eec56faf HEAD -- api integrations/hermes` returned0; affected baseline bytes are unchanged.
- Before file SHA256: `9ea15ac670cb89d1baa727da938c915c60b263d09aad367a592c32009531f309`.
- Candidate file SHA256: `5c68aa1d69c942783902185fba1dcd8464099648f17408c3f3b3068b9b71259c`.
- Candidate Git blob: `90c96bd1b188c090aec9101b6522c96ea194adfc`.
- `candidate.patch` SHA256: `4c0fa5ba309825e6f125fc60467b1bb9bbca673cb620e3042fd9c1ce23227784`.

## Actual execution

Every invocation used `sandbox.json` argv prefix: no-network bwrap, private /dev, read-only source/dependencies, clean env and candidate interpreter. Each named JSON contains full exact argv/cwd/exit/deadline; matching log preserves output.

- `preflight.json`: exit0; OpenAI2.45.0, agents0.19.0, pytest9.1.1, asyncio1.4.0, Ruff0.16.9, mypy2.3.1; imported OpenAI originates in candidate venv.
- `collect-before.json` / `collect-after.json`: exit0; all135 emitted IDs equal, including all25 affected IDs. `integrity.json`: exact approved text replacements only; normalized whole-file AST equal, decorators unchanged,197 outer asserts preserved. No cases skipped or removed.
- `red.json`: existing `[sdk]` and `[complete]`, pytest exit1, **2 failed in3.61s**; exact2.24 refusal with actual2.45. Original bounded12801-byte stdout/stderr retained in `red.log`.
- `green-private.json`: whole module, pytest exit0, **135 passed in41.95s**, zero skips/errors/failures. JUnit independently counted25 affected +110 siblings in `green-counts.json`.
- `ruff-check-no-cache.json`: `-m ruff check --config api/pyproject.toml --no-fix --no-cache api/tests/test_model_test_prepare_source.py`, exit0.
- `ruff-format-no-cache.json`: `-m ruff format --config api/pyproject.toml --check --no-cache api/tests/test_model_test_prepare_source.py`, exit0.
- `mypy.json`: `-m mypy --config-file api/pyproject.toml --no-incremental --cache-dir=/s/mypy --output=json api/tests/test_model_test_prepare_source.py`, exit0, no diagnostics. Existing strict config unchanged.
- `git diff --check`, historical `git diff --exit-code -- integrations/hermes api/tests/fixtures`: exit0. API search now has zero2.24.0 matches; exactly the two SOURCE assertions join current manifest/lock2.45.0. Historical codex_headers fixture SHA remains `f294215fef55f229704cd3fc596ccb6840af126459f15a7ffd38f2c51ae62f6a`.

## Retained prerequisite failures

Initial Ruff invocation exit2 attempted cache creation in read-only repo; using `--no-cache` corrected only the invocation, not lint rules. Initial whole-module run (`green.json` / `green.log` / `green.xml`) was exit1:115pass/20fail38.28s; **all25 affected cases passed**. The20 unrelated UDS siblings correctly rejected scratch `/s` mode0775 as a replaceable ancestor. Changed only the owned output directory to0700, then both actual API and adapter private-directory guards passed in `private-path-preflight.json`; unchanged tests passed on the single subsequent run. No product guard, test timeout or assertion was weakened. Initial final-freeze HEAD-equality check also refused the concurrent parent evidence commit; exact API/integrations comparison established unchanged tested source before freeze.

Owned output tree has zero remaining socket paths. All evidence and scratch effects are beneath this directory. Protected original untracked paths were masked without reading; operator files/environment and mainapi venv were not modified. No provider/target/PG or installed native runtime was executed; the cold SDK Python subprocess, SOURCE UDS, pipes/socketpairs and explicit HTTP doubles are not historical native certification.

Status: GREEN_SOURCE_CANDIDATE / NOT_REVIEWED_DELTA / UNCOMMITTED. Canonical retained FAIL remains; no canonical rerun or gate closure by child. Parent owns focused review, integration and separately admitted canonical rerun. Existing canonical harness-only counter1 is retained; no product behavior change is claimed.
