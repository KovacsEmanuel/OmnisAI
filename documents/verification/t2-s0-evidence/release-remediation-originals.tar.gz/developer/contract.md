# S0 release closure compatibility — developer candidate

Base: 828b6fdac384992251282516798745ee1129a188, initially clean detached worktree /home/kali/.hermes/cache/scratch/t2web-me7ugrx1/release-fix. Sole product developer; no commit/push/integration.

Acceptance: real ops/build_control_bundle.py must accept API 0.1.1 with exact openai==2.45.0 + openai-agents==0.19.0, cryptography==50.0.1/httpx==0.28.1/httpcore==1.0.9; still read legacy T1 openai==2.24.0 without agents at release0.1.0/schema0016 or0017 and0.1.1/schema0017. Admit the new SDK pair only on0.1.1. Reject extras/missing/wrong/mixed/duplicate/conflicting core pins, without normalizing malformed tokens into accepted pins. All immutable install/digest/retention guards remain.

Allowed product paths: cli/src/omnis_cli/release.py; cli/tests/test_provider_settings_profile.py. Reuse/extend fixture inside that test only. No API/UI/ops/docs/pins/dependencies or version changes. No operator install, service, Docker, PostgreSQL, credential/provider/model/target effects.

Reachability: _manifest -> builder before publication; install_release/_install_locked before install/idempotency; compose.install_control_image before image effects; ControlRuntime before receipt binding/start; stop_owner._load_runtime before stop/recover; upgrade before backup/dispatch. Existing fixtures test_install (format1/2), test_recover (legacy2.24), provider_settings_profile (legacy closure), test_upgrade (retention/schema/intent) stay meaningful. No export/config changes: real API metadata and locked export are already current; CLI stays dependencies=[].

Requirement -> consumer -> risk -> decision:
- RED/new pair + legacy/negative controls -> _manifest -> stale rejection or widened admission -> minimal shared validator fix.
- SOURCE unittest sibling install/recover/upgrade/attestation checks -> lifecycle readers -> historical unreadability/data replacement -> accept/reject candidate for review.
- Pinned Ruff0.16.9 and strict mypy2.3.1 -> CLI source/siblings -> static regression -> freeze only if pass.
- Own CLI wheel/private venv + actual build_bundle(existing API wheel, exact locked export, frozen-web) -> real builder -> accidental main-source binding or false synthetic success -> developer BUNDLE_READY artifact evidence, not independent QA.

Bounds: source commands<=240s, artifact<=120s. Reuse existing build/test commands with explicit source sys.path or own installed CLI; no alternate harness/supervisor. Parent supplied immutable web root /home/kali/.hermes/cache/scratch/t2web-me7ugrx1/frozen-web (do not use concurrently rebuilding dist).

Prior concrete producer RED: /home/kali/.hermes/cache/scratch/t2web-me7ugrx1/bundle-refusal.json (ReleaseError: Provider Settings production closure required, _manifest line175), release.stdout/release.stderr and current-requirements.txt remain original. Prior harness-only counter=2 unchanged. Web diagnosis not this defect; historicalUNKNOWN preserved. S1 NOT_STARTED_NOT_ADMITTED. Parent owns two complementary reviews on frozen bytes and final real release/bundle QA after blockers clear. Reticle NOT_APPLICABLE; Chisel BLOCKED_NO_GO.

Rollback: discard only this candidate's two-file diff before parent integration; no external product state changed. All evidence/temporary outputs owned under release-fix-evidence. Source changes are a candidate, never acceptance.
