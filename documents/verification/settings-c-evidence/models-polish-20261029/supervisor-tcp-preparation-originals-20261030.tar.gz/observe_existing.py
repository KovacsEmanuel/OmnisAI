"""Adapted sol observer; installed child's hooks, no pytest or fixture connector."""
import asyncio
from contextvars import ContextVar
import functools
import json
import os
import time

import psycopg
from sqlalchemy import event
from sqlalchemy.engine import Engine
from sqlalchemy.pool import Pool
from omnis.modules.instance.service import InstanceService

TAG = ContextVar('sol_diagnostic_tag', default=None)
CYCLE = ContextVar('sol_diagnostic_cycle', default=0)
fd = None
serial = sequence = dropped = 0


def emit(kind, **fields):
    global sequence, dropped
    sequence += 1
    row = dict(kind=kind, mono_ns=time.monotonic_ns(), wall_ns=time.time_ns(),
               thread_cpu_ns=time.thread_time_ns(), pid=os.getpid(), seq=sequence,
               dropped=dropped, tag=TAG.get(), cycle=CYCLE.get(), **fields)
    packet = (json.dumps(row, separators=(',', ':')) + '\n').encode()
    try:
        if fd is None or len(packet) > 4096 or os.write(fd, packet) != len(packet):
            dropped += 1
    except OSError:
        dropped += 1


def wrap_driver(name):
    original = getattr(psycopg.AsyncConnection, name)
    @functools.wraps(original)
    async def observed(self, *a, **kw):
        if TAG.get() is None:
            return await original(self, *a, **kw)
        pid = self.info.backend_pid
        emit('driver_' + name + '_begin', backend_pid=pid,
             tx_status=int(self.pgconn.transaction_status))
        try:
            result = await original(self, *a, **kw)
        except asyncio.CancelledError:
            emit('driver_' + name + '_cancel', backend_pid=pid)
            raise
        except BaseException:
            emit('driver_' + name + '_error', backend_pid=pid)
            raise
        else:
            emit('driver_' + name + '_success', backend_pid=pid,
                 tx_status=int(self.pgconn.transaction_status))
            return result
    setattr(psycopg.AsyncConnection, name, observed)


for name in ['commit', 'rollback']:
    wrap_driver(name)
original_command = psycopg.AsyncConnection._exec_command


def observed_command(self, command, *a, **kw):
    tagged = TAG.get() is not None and command in (b'COMMIT', b'ROLLBACK')
    pid = self.info.backend_pid
    if tagged:
        emit('protocol_' + command.decode() + '_begin', backend_pid=pid)
    try:
        result = yield from original_command(self, command, *a, **kw)
    except asyncio.CancelledError:
        if tagged:
            emit('protocol_' + command.decode() + '_cancel', backend_pid=pid)
        raise
    except BaseException:
        if tagged:
            emit('protocol_' + command.decode() + '_error', backend_pid=pid)
        raise
    else:
        if tagged:
            acknowledged = (result is not None
                            and result.status == psycopg.pq.ExecStatus.COMMAND_OK
                            and result.command_status == command)
            outcome = 'success' if acknowledged else 'queued' if result is None else 'not_acknowledged'
            emit('protocol_' + command.decode() + '_' + outcome, backend_pid=pid)
        return result
psycopg.AsyncConnection._exec_command = observed_command


@event.listens_for(Engine, 'before_cursor_execute')
def before(conn, cursor, statement, parameters, context, executemany):
    if TAG.get() is not None:
        kind = ('lease_update' if statement.startswith('UPDATE supervisor_lease SET expires_at')
                else 'clock' if statement == 'SELECT clock_timestamp()'
                else 'instance_lock' if statement.startswith('SELECT * FROM instance_control')
                else 'lease_lock' if statement.startswith('SELECT * FROM supervisor_lease')
                else 'other')
        emit('sql_begin', operation=kind,
             backend_pid=conn.connection.driver_connection.info.backend_pid)


@event.listens_for(Engine, 'after_cursor_execute')
def after(conn, cursor, statement, parameters, context, executemany):
    if TAG.get() is not None:
        emit('sql_success', backend_pid=conn.connection.driver_connection.info.backend_pid)


@event.listens_for(Pool, 'reset')
def reset(dbapi, record, state):
    if TAG.get() is not None:
        emit('pool_reset', backend_pid=dbapi.driver_connection.info.backend_pid,
             transaction_was_reset=state.transaction_was_reset)


@event.listens_for(Pool, 'checkin')
def checkin(dbapi, record):
    if TAG.get() is not None:
        emit('pool_checkin' if dbapi is not None else 'pool_invalidated',
             backend_pid=dbapi.driver_connection.info.backend_pid if dbapi else None)


def install_service(name, original):
    @functools.wraps(original)
    async def observed(self, *a, **kw):
        global serial
        serial += 1
        token = TAG.set(f'{name}:{serial}')
        emit('service_begin')
        try:
            result = await original(self, *a, **kw)
        except asyncio.CancelledError:
            emit('service_cancel')
            raise
        except BaseException:
            emit('service_error')
            raise
        else:
            emit('service_return')
            return result
        finally:
            TAG.reset(token)
    setattr(InstanceService, name, observed)


for name in ['acquire', 'heartbeat', 'owned_status', 'quiesce', 'release']:
    install_service(name, getattr(InstanceService, name))
