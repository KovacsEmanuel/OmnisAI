"""Adapted attachment in the owned DEVELOPMENT copy; normal supervisor argv stays."""
import asyncio
from contextlib import contextmanager
import functools
import os
from pathlib import Path
import select
import socket
import subprocess
import sys
import time

from . import _sol_observe_existing as obs


def no_network(event, args):
    # libpq owns DB TCP; Python DNS is admitted only for that fixed Compose service.
    if event == 'socket.getaddrinfo' and args[:2] not in (('db', 5432), ('db', '5432')):
        raise PermissionError('DIAGNOSTIC_DNS_FORBIDDEN')
    if event == 'socket.__new__' and args[1] != socket.AF_UNIX:
        raise PermissionError('DIAGNOSTIC_SOCKET_FORBIDDEN')


def install(consumer):
    from omnis.modules.instance import service as instance
    from omnis.modules.runs.model_test_runtime import ApiKeyModelTest
    from omnis.supervisor.model_sender import ModelSender, Backend
    from omnis.core.db import validated_database_url
    import psycopg
    from psycopg.conninfo import conninfo_to_dict

    url = validated_database_url(os.environ['OMNIS_DATABASE_URL'])
    if (url.host, url.port, url.username, url.database) != ('db', 5432, 'omnis', 'omnis'):
        raise ValueError('DIAGNOSTIC_DB_SCOPE_REFUSED')
    original_connect = psycopg.AsyncConnection.connect.__func__

    @classmethod
    async def connect(cls, conninfo='', **kwargs):
        controls = {key: kwargs[key] for key in ('host', 'port', 'user', 'dbname', 'password') if key in kwargs}
        parsed = conninfo_to_dict(conninfo, **controls)
        if (parsed.get('host'), str(parsed.get('port')), parsed.get('user'), parsed.get('dbname'), parsed.get('password')) != ('db', '5432', 'omnis', 'omnis', url.password):
            raise PermissionError('DIAGNOSTIC_DB_SCOPE_REFUSED')
        if set(parsed) - {'host', 'port', 'user', 'dbname', 'password'} or any(key in kwargs for key in ('hostaddr', 'service', 'passfile')):
            raise PermissionError('DIAGNOSTIC_DB_SCOPE_REFUSED')
        return await original_connect(cls, conninfo, **kwargs)
    psycopg.AsyncConnection.connect = connect
    sys.addaudithook(no_network)

    cycle = 0
    original_cycle = instance.LeaseTrace.cycle
    @contextmanager
    def observed_cycle(self):
        nonlocal cycle
        cycle += 1
        token = obs.CYCLE.set(cycle)
        with original_cycle(self):
            obs.emit('native_cycle_begin')
            try:
                yield
            except BaseException:
                obs.emit('native_cycle_error')
                raise
            else:
                obs.emit('native_cycle_return')
            finally:
                obs.CYCLE.reset(token)
    instance.LeaseTrace.cycle = observed_cycle
    original_mark = instance._lease_mark
    def mark(step, **kw):
        original_mark(step, **kw)
        trace = instance._lease_trace.get()
        if trace is not None and trace.task is asyncio.current_task() and trace.events:
            obs.emit('native_cycle_boundary', boundary=trace.events[-1])
    instance._lease_mark = mark

    original_init = ApiKeyModelTest.__init__
    def model_init(self, *a, **kw):
        original_init(self, *a, **kw)
        obs.emit('real_model_owner_constructed')
    ApiKeyModelTest.__init__ = model_init
    for name in ['reconcile', 'drain', 'drain_models']:
        original = getattr(ApiKeyModelTest, name)
        def callback(name, original):
            @functools.wraps(original)
            async def observed(self, *a, **kw):
                obs.emit('model_owner_callback_begin', method=name)
                try:
                    result = await original(self, *a, **kw)
                except asyncio.CancelledError:
                    obs.emit('model_owner_callback_cancel', method=name)
                    raise
                except BaseException:
                    obs.emit('model_owner_callback_error', method=name)
                    raise
                else:
                    obs.emit('model_owner_callback_return', method=name,
                             acknowledged=result is True)
                    return result
            setattr(ApiKeyModelTest, name, observed)
        callback(name, original)

    async def forbidden(*a, **kw):
        obs.emit('forbidden_provider_boundary')
        raise PermissionError('DIAGNOSTIC_PROVIDER_IO_FORBIDDEN')
    for name in ['send', 'metadata', 'metadata_page']:
        setattr(ModelSender, name, forbidden)
    Backend.connect_tcp = forbidden
    original_run = consumer.run
    async def progress():
        last = time.monotonic_ns()
        while True:
            await asyncio.sleep(.05)
            now = time.monotonic_ns()
            obs.emit('native_loop_progress', gap_ns=now-last)
            last = now
    async def observed_run():
        task = asyncio.create_task(progress())
        try:
            return await original_run()
        finally:
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
    consumer.run = observed_run


@contextmanager
def attach(consumer, *, inert_output=None):
    read_fd, write_fd = os.pipe()
    os.set_blocking(write_fd, False)
    path = Path(__file__).with_name('_sol_native_witness.py')
    output = str(inert_output or '/run/omnis-control/sol-events.jsonl')
    witness = None
    try:
        witness = subprocess.Popen([sys.executable, '-I', '-B', str(path), str(read_fd), output,
                                    *(['--inert'] if inert_output is not None else [])],
                                   pass_fds=(read_fd,), stdout=subprocess.PIPE,
                                   stderr=subprocess.DEVNULL, text=True)
        os.close(read_fd)
        read_fd = None
        obs.fd = write_fd
        if not select.select([witness.stdout], [], [], 5)[0] or witness.stdout.readline().strip() != 'SOL_WITNESS_READY':
            raise RuntimeError('DIAGNOSTIC_WITNESS_NOT_READY')
        start_ticks = int(Path('/proc/self/stat').read_text().rsplit(')', 1)[1].split()[19])
        obs.emit('declared_synthetic_emission_control' if inert_output else 'native_identity',
                 start_ticks=start_ticks, consumer_source=consumer.__file__)
        if inert_output is None:
            install(consumer)
        try:
            yield obs
        finally:
            obs.emit('native_observer_end')
    finally:
        obs.fd = None
        os.close(write_fd)
        if read_fd is not None:
            os.close(read_fd)
        if witness is not None:
            try:
                code = witness.wait(timeout=5)
            except subprocess.TimeoutExpired:
                witness.terminate()
                try:
                    witness.wait(timeout=1)
                except subprocess.TimeoutExpired:
                    witness.kill()
                    witness.wait(timeout=1)
                raise RuntimeError('DIAGNOSTIC_WITNESS_UNSETTLED') from None
            finally:
                witness.stdout.close()
            if code != 0:
                raise RuntimeError('DIAGNOSTIC_WITNESS_FAILED')
