"""Attach to one existing native supervisor case; add only a quiet status window."""
import asyncio
import json
import os
from pathlib import Path
import selectors
import subprocess
import sys
import time

ROOT=Path('/home/kali/.hermes/cache/scratch/t1-supervisor-diagnostic-20261030')
OUT=Path(__file__).parent
sys.dont_write_bytecode=True
sys.path[:0]=[str(ROOT/'api/src'),str(ROOT/'api/tests')]
import pytest
from conftest import connect_test_database

NODE=str(ROOT/'api/tests/test_supervisor.py')+'::test_real_supervisor_is_unique_and_restart_stays_closed[before_shutdown]'
notes=[]
def record(kind,**fields):
    notes.append({'kind':kind,'mono_ns':time.monotonic_ns(),**fields})

def ready(process):
    with selectors.DefaultSelector() as s:
        s.register(process.stdout,selectors.EVENT_READ)
        if not s.select(30):
            raise RuntimeError('INDEPENDENT_WITNESS_NOT_READY')
        if process.stdout.readline().strip()!='SOL_WITNESS_READY':
            raise RuntimeError('INDEPENDENT_WITNESS_REFUSED')

class Attach:
    @pytest.hookimpl(hookwrapper=True)
    def pytest_runtest_call(self,item):
        module=item.module
        url=item.funcargs['migrated_database_url']
        fixture=Path(os.environ['OMNIS_TEST_FIXTURE']).parent
        r,w=os.pipe()
        witness=subprocess.Popen([sys.executable,'-I','-B',str(OUT/'native_witness.py'),str(r),'invocation-2-native'],pass_fds=(r,),stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        os.close(r)
        children=[]; window_done=False
        original_start=module.start_supervisor
        original_request=module.request
        original_stop=module.stop_process
        try:
            ready(witness)
            record('witness_ready',pid=witness.pid)
            def start(database_url,directory):
                number=len(children)+1
                paths=[fixture/f'native-vault-{number}',fixture/f'native-keys-{number}']
                for p in paths: p.mkdir(mode=0o700)
                env={'PATH':os.environ.get('PATH',''),'OMNIS_DATABASE_URL':database_url.render_as_string(hide_password=False),'OMNIS_CONTROL_DIR':str(directory),'OMNIS_VAULT_DIR':str(paths[0]),'OMNIS_VAULT_KEY_DIR':str(paths[1]),'OMNIS_MODEL_EGRESS_DIR':'/vault'}
                argv=[sys.executable,'-I','-B',str(OUT/'native_bootstrap.py'),str(w)]
                child=subprocess.Popen(argv,cwd=directory,env=env,pass_fds=(w,),stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
                children.append(child)
                stat=Path(f'/proc/{child.pid}/stat').read_text().rsplit(')',1)[1].split()
                record('native_spawn',number=number,pid=child.pid,start_ticks=int(stat[19]),argv=argv,original_helper_argv=[sys.executable,'-I','-m','omnis.supervisor'],model_owner_enabled=True)
                return child
            async def request(directory,capability,command,**extra):
                nonlocal window_done
                reply=await original_request(directory,capability,command,**extra)
                if command=={'op':'status'} and not window_done:
                    window_done=True
                    baseline=reply.get('status')
                    if not reply['ok'] or baseline is None:
                        raise RuntimeError('QUIET_WINDOW_INITIAL_STATUS_REFUSED')
                    start=time.monotonic(); end=start+90
                    record('quiet_window_begin',native_pid=children[0].pid,seconds=90,instance_id=baseline['instance_id'],epoch=baseline['supervisor_epoch'],generation=baseline['generation'])
                    reads=0
                    while time.monotonic()<end:
                        await asyncio.sleep(min(1,end-time.monotonic()))
                        observed=await original_request(directory,capability,{'op':'status'})
                        status=observed.get('status')
                        record('quiet_status',ok=observed['ok'],error=observed.get('error'),native_pid=children[0].pid,instance_id=status.get('instance_id') if status else None,epoch=status.get('supervisor_epoch') if status else None,generation=status.get('generation') if status else None,supervisor_ready=status.get('supervisor_ready') if status else None)
                        reads+=1
                        if not observed['ok'] or status is None or not status['supervisor_ready'] or (status['instance_id'],status['supervisor_epoch'],status['generation'])!=(baseline['instance_id'],baseline['supervisor_epoch'],baseline['generation']):
                            raise RuntimeError('QUIET_NATIVE_STATUS_CHANGED_OR_REFUSED')
                    record('quiet_window_end',elapsed_seconds=time.monotonic()-start,reads=reads,native_alive=children[0].poll() is None)
                return reply
            def stop(process,*,crash=False):
                result=original_stop(process,crash=crash)
                lines=[line for stream in result for line in stream.splitlines()]
                record('native_stopped',pid=process.pid,exit=process.returncode,declared_crash=crash,allowlisted_lines=[line for line in lines if line.startswith(('SUPERVISOR_READY','SUPERVISOR_FAILURE ','SUPERVISOR_LEASE_TRACE ','SUPERVISOR_UNAVAILABLE'))],other_line_count=sum(not line.startswith(('SUPERVISOR_READY','SUPERVISOR_FAILURE ','SUPERVISOR_LEASE_TRACE ','SUPERVISOR_UNAVAILABLE')) for line in lines))
                return result
            module.start_supervisor=start
            module.request=request
            module.stop_process=stop
            outcome=yield
            record('test_call_outcome',error_type=outcome.excinfo[0].__name__ if outcome.excinfo else None)
        finally:
            module.start_supervisor=original_start
            module.request=original_request
            module.stop_process=original_stop
            os.close(w)
            stdout,stderr=witness.communicate(timeout=15)
            record('witness_stopped',pid=witness.pid,exit=witness.returncode,stderr_present=bool(stderr),native_states=[{'pid':p.pid,'exit':p.poll()} for p in children])
            # The original native test owns all lifecycle changes and its child finalizer.
            if all(p.poll() is not None for p in children):
                with connect_test_database(url,autocommit=True) as db:
                    db.execute('SET default_transaction_read_only = on')
                    counts=db.execute('SELECT (SELECT count(*) FROM system_operation),(SELECT count(*) FROM model_dispatch_v2)').fetchone()
                    record('no_model_effect_readback',system_operations=counts[0],model_dispatches=counts[1],key_files=sum(len(list((fixture/f'native-keys-{i+1}').iterdir())) for i in range(len(children))))
            (OUT/'invocation-2-native-parent.json').write_text(json.dumps(notes,indent=2)+'\n')
            if witness.returncode!=0:
                raise RuntimeError('INDEPENDENT_WITNESS_FAILED')
    def pytest_sessionfinish(self,session,exitstatus):
        (OUT/'invocation-2-pytest-result.json').write_text(json.dumps({'exit':int(exitstatus),'collected':session.testscollected,'node':NODE},indent=2)+'\n')

if __name__=='__main__':
    args=['-p','pytest_asyncio.plugin','-p','no:cacheprovider','-c',str(ROOT/'api/pyproject.toml'),NODE,'-q','--tb=short']
    if '--collect-only' in sys.argv:
        args+=['--collect-only']
    print('SOL_NATIVE_SELECTION '+json.dumps({'argv':args,'quiet_seconds':90,'bootstrap_difference':'instrumented real consumer.main; fresh vault/key paths enable real ApiKeyModelTest; no provider calls'}),flush=True)
    raise SystemExit(pytest.main(args,plugins=[Attach()]))
