"""One-shot SOURCE reader proof; SQL rows are doubles, not PG/HTTP evidence."""

import asyncio
import json
import sys
from datetime import UTC, datetime, timedelta
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

ROOT = Path('/home/kali/.hermes/cache/scratch/omnis-s1-20261104')
sys.path[:0] = [str(ROOT / 'api/src'), str(ROOT / 'api/tests')]

from omnis.modules.runs.model_test_runtime import ApiKeyModelTest
from omnis.modules.settings.provider_catalog import CatalogIngest
from omnis.modules.settings.provider_catalog_models import CatalogModel, SearchCatalog
from omnis.modules.settings.provider_catalog_runtime import CatalogRequest, CatalogResult, view
from omnis.modules.settings.provider_key_service import ConnectionRevision


async def main():
    connection = ConnectionRevision(
        connection_id='00000000-0000-4000-8000-000000000001', revision=1,
        provider='openrouter', enabled=True,
        secret_id='00000000-0000-4000-8000-000000000002', credential_revision=1,
    )
    command = '00000000-0000-4000-8000-000000000003'
    request = CatalogRequest(
        command_id=command, connection=connection, generation=1, owner_epoch=1,
        execution_owner_id='00000000-0000-4000-8000-000000000004',
        deadline=datetime.now(UTC) + timedelta(seconds=15),
    )
    result = CatalogResult(
        command_id=command, connection=connection, state='READY', reason=None,
        entries=[CatalogModel(model=model, max_output_tokens=4096, supports_max_tokens=True)
                 for model in ('fixture/s1', 'fixture/s1-recon')],
    )
    db = AsyncMock()
    engine = MagicMock()
    engine.connect.return_value.__aenter__.return_value = db
    runtime = object.__new__(ApiKeyModelTest)
    runtime.service = SimpleNamespace(engine=engine)
    runtime.instance = '00000000-0000-4000-8000-000000000005'
    runtime.settings = SimpleNamespace(connections=AsyncMock(return_value=[connection]), epoch=1)
    search = SearchCatalog(action='search', connection_id=connection.connection_id, connection_revision=1)

    # The old fixture has a result, but the reader cannot reach it without a request.
    db.execute.return_value.scalar_one_or_none = MagicMock(return_value=None)
    missing = await view(runtime, search)
    assert missing.state == 'NOT_REQUESTED' and missing.total == 0
    assert db.execute.await_count == 1
    print('SOURCE bare-result reader:', missing.state, flush=True)
    if '--paired' not in sys.argv:
        assert missing.state == 'READY', 'S1-QA-UI-01: result-only seed is not UI-ready'
        return

    from test_run_runtime_pg import S1_CATALOG_PAGE
    ingest = CatalogIngest('openrouter')
    assert ingest.add(S1_CATALOG_PAGE, 'synthetic-s1-not-a-key') is None
    assert ingest.complete and ingest.reason is None and ingest.total == 2
    assert list(ingest.entries.values()) == result.entries
    assert len(json.dumps(S1_CATALOG_PAGE).encode()) < 2097152
    # Known matching rows exercise the real reader, not catalog persistence/refresh.
    db.execute.reset_mock()
    db.execute.side_effect = [
        MagicMock(scalar_one_or_none=MagicMock(return_value=request.model_dump(mode='json'))),
        MagicMock(scalar_one_or_none=MagicMock(return_value=result.model_dump(mode='json'))),
    ]
    paired = await view(runtime, search)
    assert paired.state == 'READY' and paired.reason is None and paired.total == 2
    assert paired.catalog_command_id == command
    assert paired.connection_id == connection.connection_id and paired.connection_revision == 1
    assert paired.entries == result.entries
    assert db.execute.await_args_list[1].args[1]['command'] == command
    assert db.execute.await_args_list[1].args[1]['kind'] == 'catalog-result'
    print('SOURCE paired-reader READY, exact command/connection/revision and both caps; ingest complete')


asyncio.run(main())
