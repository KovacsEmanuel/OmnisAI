"""R2 SOURCE-only decisive controls for the inherited Stop attestor.
Synthetic Docker shapes, real private scratch filesystem; no daemon/services.
"""
import importlib
import json
import sys
from copy import deepcopy
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock

REPO = Path('/home/kali/.hermes/cache/scratch/omnis-s1-20261104')
sys.path[:0] = [str(REPO / 'cli/src'), str(REPO / 'cli/tests')]
from omnis_cli.lifecycle import StartError, write_record
from omnis_cli.start_runtime import private_identity, provider_settings_overlay
from omnis_cli.stop_owner import _View
from runtime_inspect_fixture import container_item, image_item
from test_provider_settings_profile import ProviderSettingsProfileTest

fixture = ProviderSettingsProfileTest()
fixture.setUp()
checks = []

def deny(label, action, reason=None):
    try:
        action()
    except ValueError as exc:
        if reason is not None:
            assert isinstance(exc, StartError) and exc.reason == reason, (label, type(exc), str(exc))
        checks.append(label)
    else:
        raise AssertionError(label + ': unexpectedly accepted')

try:
    root, runtime, record = fixture.root, fixture.runtime, fixture.record
    runtime.receipt.release = '0.1.2'
    runtime.schema = '0019_agent_runs'
    runtime.release, runtime.digest, runtime.host = root / 'release', 'a' * 64, 'unix:///synthetic.sock'
    (root / 'catalog').mkdir(mode=0o700)
    record['catalog_identity'] = private_identity(root / 'catalog')
    record['system_id'] = '12345'
    write_record(root / 'startup.json', record, replace=True)
    engine = SimpleNamespace(deadline=runtime.deadline, check_daemon=Mock())
    view = _View(runtime, engine)
    assert view.run_catalog and view.schema == '0019_agent_runs' and not view.native
    checks.append('Stop _View inherits exact S1 schema/profile/catalog policy')
    cid, control, port = 'f' * 64, root / 'control', 48765
    view.ids, view.network = Mock(return_value=[cid]), Mock(return_value='1' * 64)
    for role in ('db', 'api', 'supervisor', 'migrate', 'reconcile'):
        candidate = container_item(runtime, role, cid, root, control, port)
        if role == 'supervisor':
            candidate['Config']['Env'] = [s for s in candidate['Config']['Env'] if not s.startswith('OMNIS_RUNTIME_DIR=')]
            candidate['Mounts'] = [m for m in candidate['Mounts'] if m['Destination'] != '/runtime']
            candidate['Config']['Env'] += ['OMNIS_VAULT_DIR=/vault', 'OMNIS_VAULT_KEY_DIR=/vault-key', 'OMNIS_MODEL_EGRESS_DIR=/vault', 'OMNIS_RUN_CATALOG_ROOT=/catalog']
            candidate['Mounts'] += [{'Type': 'bind', 'Source': str(root / name), 'Destination': '/' + name, 'RW': True, 'Propagation': 'rprivate'} for name in ('vault', 'vault-key', 'catalog')]
        view.inspect = Mock(side_effect=lambda kind, ident: candidate if kind == 'container' else image_item(runtime, role))
        attest = lambda: view.attest(cid, role, root, control, port)
        assert attest() == candidate
        checks.append('Stop full attestor positive ' + role)
        baseline = deepcopy(candidate)
        candidate['Mounts'].append({'Type': 'bind', 'Source': str(root / 'catalog'), 'Destination': '/catalog', 'RW': True, 'Propagation': 'rprivate'})
        deny('Stop extra/duplicate catalogue mount ' + role, attest, 'CONTAINER_IDENTITY_MISMATCH')
        candidate = deepcopy(baseline)
        candidate['Config']['Env'].append('OMNIS_MANAGED_TASKS=1')
        deny('Stop unexpected native environment ' + role, attest, 'CONTROL_CONFIGURATION_MISMATCH')
        candidate = deepcopy(baseline)
        if role == 'supervisor':
            candidate['Mounts'][-1]['RW'] = False
            deny('Stop read-only catalog rejected', attest, 'CONTAINER_IDENTITY_MISMATCH')
            candidate = deepcopy(baseline)
            candidate['Mounts'].pop()
            deny('Stop missing catalog rejected', attest, 'CONTAINER_IDENTITY_MISMATCH')
            candidate = deepcopy(baseline)
            candidate['Mounts'][-1]['Source'] = str(root / 'foreign')
            deny('Stop wrong catalogue source rejected', attest, 'CONTAINER_IDENTITY_MISMATCH')
    deny('Stop no Docker CLI fallback', lambda: view.run('version'), 'STOP_COMMAND_EXECUTION_FORBIDDEN')
    overlay = lambda: provider_settings_overlay(view, {'OMNIS_STATE_ROOT': str(root)})
    overlay()
    runtime.receipt.release = '0.1.1'
    assert not view.run_catalog
    deny('T1 rejects S1 catalogue journal', overlay, 'VAULT_PATH_IDENTITY_MISMATCH')
    runtime.receipt.release = '0.1.2'
    view.schema = '0017_model_removal'
    assert not view.run_catalog
    deny('Wrong schema rejects S1 catalogue journal', overlay, 'VAULT_PATH_IDENTITY_MISMATCH')
    view.schema = '0019_agent_runs'
    (root / 'catalog').chmod(0o750)
    deny('Non-private catalogue mode rejected', overlay)
    (root / 'catalog').chmod(0o700)
    (root / 'catalog').rename(root / 'original-catalog')
    (root / 'catalog').mkdir(mode=0o700)
    deny('Stale catalogue inode rejected', overlay, 'VAULT_PATH_IDENTITY_MISMATCH')
    (root / 'catalog').rmdir()
    (root / 'catalog').symlink_to(root / 'original-catalog', target_is_directory=True)
    deny('Catalogue symlink rejected', overlay)
    runtime.run.assert_not_called()
    print(json.dumps({'scope': 'SOURCE synthetic inspect + private filesystem, not OCI QA', 'checks': checks, 'count': len(checks), 'result': 'PASS'}, indent=2))
finally:
    fixture.doCleanups()
