"""SOURCE-only pytest entry; refuse network and child process effects."""
import os
import socket
import sys
from pathlib import Path

root = Path('/home/kali/.hermes/cache/scratch/omnis-s1-api-fixes-20261104')
os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD'] = '1'
sys.path[:0] = [str(root / 'api/src'), str(root / 'api/tests')]
denied = []

def audit(event, args):
    if event in {'socket.connect', 'socket.bind', 'socket.getaddrinfo', 'socket.gethostbyname', 'socket.gethostbyaddr', 'subprocess.Popen', 'os.system', 'os.posix_spawn', 'os.fork'} or (event == 'socket.__new__' and args[1] in (socket.AF_INET, socket.AF_INET6)):
        denied.append(event)
        raise RuntimeError('NO_EFFECT_AUDIT:' + event)

sys.addaudithook(audit)
import pytest
code = pytest.main(['-p', 'pytest_asyncio.plugin', '-p', 'no:cacheprovider', '-c', str(root / 'api/pyproject.toml'), *sys.argv[1:]])
print('SOURCE_DENIED_EFFECT_ATTEMPTS', denied)
raise SystemExit(code)
