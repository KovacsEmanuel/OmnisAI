"""Second and final private invocation: existing owner, one native case, exact logs."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys
import time

ROOT=Path('/home/kali/.hermes/cache/scratch/t1-supervisor-diagnostic-20261030')
OUT=Path(__file__).parent
sys.dont_write_bytecode=True
os.environ['PATH']='/home/kali/.local/share/omnis-toolchains/bin:/usr/bin:/bin'
os.environ['TMPDIR']='/home/kali/.hermes/cache/scratch'
spec=importlib.util.spec_from_file_location('sol_second_private_fixture_owner',ROOT/'ops/run_test_db_gate.py')
owner=importlib.util.module_from_spec(spec); sys.modules[spec.name]=owner; spec.loader.exec_module(owner)
original_gate=owner.run_gate
original_cleanup=owner.cleanup_owned
retention=[]

def attached(command,env,log,timeout_seconds):
    if command!=['make','--no-print-directory','test-sl04-pg','UV=/home/kali/.local/share/omnis-toolchains/uv-0.12.19']:
        raise ValueError('UNEXPECTED_NATIVE_GATE_COMMAND')
    argv=[sys.executable,'-I','-B',str(OUT/'observe_native_case.py')]
    print('SOL_NATIVE_GATE_ATTACHMENT '+json.dumps({'original_argv':command,'executed_argv':argv,'timeout_seconds':timeout_seconds}),flush=True)
    return original_gate(argv,{**env,'PYTEST_DISABLE_PLUGIN_AUTOLOAD':'1','PYTHONDONTWRITEBYTECODE':'1'},log,timeout_seconds)

def cleanup(cid,docker,env,paths,project,image_id,daemon_id):
    original_run=owner._run
    def retain_before_rm(argv,run_env,*,timeout=20):
        if argv==[*docker,'rm','-f',cid]:
            # This exact removal is reached only through the original cleanup's attest().
            result=original_run([*docker,'logs','--timestamps',cid],run_env,timeout=20)
            for name,raw in [('stdout',result.stdout),('stderr',result.stderr)]:
                lines=raw.splitlines(keepends=True)
                allowed=[line for line in lines if re.search(r'LOG:|FATAL:  password authentication failed for user "omnis_test"|initdb: warning:',line) and not re.search(r'STATEMENT:|DETAIL:|postgresql\+|Bearer |token=|password=',line,re.I)]
                target=OUT/f'invocation-2-pg-{name}-allowlisted-original.txt'
                with target.open('x') as stream: stream.write(''.join(allowed))
                os.chmod(target,0o600)
                retention.append({'stream':name,'exit':result.returncode,'original_lines':len(lines),'retained_lines':len(allowed),'path':str(target),'sha256':hashlib.sha256(''.join(allowed).encode()).hexdigest()})
        return original_run(argv,run_env,timeout=timeout)
    owner._run=retain_before_rm
    try:
        return original_cleanup(cid,docker,env,paths,project,image_id,daemon_id)
    finally:
        owner._run=original_run
        (OUT/'invocation-2-pg-log-retention.json').write_text(json.dumps(retention,indent=2)+'\n')

if __name__=='__main__':
    if Path.cwd()!=ROOT: raise ValueError('EXACT_DIAGNOSTIC_CHECKOUT_REQUIRED')
    paths=['Makefile','api/pyproject.toml','api/uv.lock','api/alembic.ini','api/tests/conftest.py','api/tests/test_supervisor.py','api/tests/test_local_control.py','ops/run_test_db_gate.py','ops/compose.test.yaml']
    paths += [str(p.relative_to(ROOT)) for p in (ROOT/'api/src/omnis').rglob('*.py')]
    files=[ROOT/p for p in paths]+[OUT/p for p in ['observe_existing.py','native_bootstrap.py','native_witness.py','observe_native_case.py','run_native.py']]
    freeze={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    first={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in OUT.glob('invocation-1*') if p.is_file()}
    (OUT/'invocation-2-freeze.json').write_text(json.dumps({'inputs':freeze,'first_invocation_preservation':first},indent=2)+'\n')
    owner.run_gate=attached; owner.cleanup_owned=cleanup
    sys.argv=[str(ROOT/'ops/run_test_db_gate.py'),'--check','--target','test-sl04-pg','--uv','/home/kali/.local/share/omnis-toolchains/bin/uv','--timeout-seconds','600']
    started=time.monotonic(); code=owner.main()
    result={'invocation':2,'invocation_limit':2,'exit':code,'elapsed_seconds':time.monotonic()-started,'inputs_unchanged':all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in freeze.items()),'first_invocation_unchanged':all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in first.items()),'pg_logs':retention}
    (OUT/'invocation-2-result.json').write_text(json.dumps(result,indent=2)+'\n')
    print('SOL_NATIVE_RESULT '+json.dumps(result),flush=True)
    raise SystemExit(code if result['inputs_unchanged'] and result['first_invocation_unchanged'] else 3)
