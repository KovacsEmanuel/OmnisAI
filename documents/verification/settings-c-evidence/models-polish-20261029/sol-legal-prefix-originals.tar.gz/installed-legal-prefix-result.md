PREFIX INSTALAT LEGITIM — CANDIDAT SOURCE, REVIEW INDEPENDENT PENDING

Bază: 028781897a8bb4c4277be7d33a3a24eac8121004; worktree /home/kali/.hermes/cache/scratch/settings-supervisor-tcp-20261030. Inițial clean. Numai cli/integration/installed_stop.py și test_installed_stop_lock_oracle.py sunt modificate; nimic staged/comis. test_release.py, start/config/stop/lifecycle de produs și cele6 scripturi originale sunt byte-identice cu bazele lor. Nu am modificat main/operator/README/status.

Finding și delta

Invocarea reală proc_358fe3b68733 a trecut pregătirea imaginii și apoi a refuzat primul Start:1FAIL8.769s/runnerexit2, nu o nouă problemă de build. Nu reconstruim motivul aruncat al acelui CLI2. Invaliditatea fresh DEVELOPMENT este însă demonstrată independent de logul pierdut: testul actual compilează exact AST-ul guardului start.py:1263–1270. fresh/restartingNone refuză DEVELOPMENT_REQUIRES_STOPPED_RELEASE/code2; sentinelul STOPPED trece numai acest guard, nu certifică READY.

run_installed_stop păstrează acum configul inițial port-only. Numai pentru supervisor_observation parcurge RELEASE Start→Stop normal→journal STOPPED și assert_resources_absent/family settled→config DEVELOPMENT→Start DEVELOPMENT→observația existentă→Stop normal/readback. Reutilizează command, resource_snapshot și finalizer; nu există owner/wheel/imagine/framework nou sau full journey browser/upgrade/lock. Calea normală fără observation rămâne un singur prefix RELEASE.

Fiecare Start cere în continuare integral310s+Stop210s+readback30s; Stop cere210s+30s, în același deadline600s. A doua etapă verifică iar rezerva integrală înaintea schimbării configului; command o reverifică după scrierea logului. Dacă nu încape, nu pornește etapa2 și păstrează primul STOPPED verificat. Nu pretindem că ambele cicluri plus90s observație încap la worst case; observația poate fi refuzată ulterior, cu Stop admis numai în rezerva rămasă. Nu am mărit sau scurtat niciun interval.

Pentru observation, command folosește writerul privat/durabil deja existent write_record: command-01-start.json,02-stop,03-start,04-stop, cu nume proprii și publicare exclusivă înaintea efectului. Rezultatul complet (argv/returncode/stdout/stderr) este persistat înaintea assertionului; după log-I/O se verifică din nou deadline-ul înaintea efectului și, la rezultat admis, rezerva rămasă. Pe excepție fără rezultat complet: returncode:null/error și excepția originală retransmisă; driver_pending rămâne incert, nu deducem STOPPED din absență. Nu se capturează pairing/key/browser sau alte profile. Un command de finalizare suplimentar, dacă este legitim admis, primește următorul număr, nu suprascrie primele4.

Controale și verificare

Un singur RED de comportament: red.log,1test cu11 failures/0.103s/exit1 pe callerul vechi; fakecallerul nu mai acceptă fresh DEV și întoarce refuzul guardului real. Primul GREEN:3teste/0.368s/exit0. O corecție de definite-assignment a făcut explicit started=None/assert started is not None pentru analiza buclei; fără ignore sau READY fictiv. Verificarea finală pe bytes actuali:3SOURCE PASS0.280s/exit0, Ruff check/format --check/diff --check toate0, în final-checks.log.

Cele12 scenarii ale controlului existent acoperă ordinea legală, observation-refused, Stop timeout, Start cleanup3, Stop lent, setup exhausted, buget insuficient după Start/poll, refuzul etapei2 după RELEASE STOPPED, timeoutul primului Stop și epuizarea bugetului de către scrierea logului înainte de lansare. Pozitivul apelează exact start/stop/start/stop; negativul etapei2 numai start/stop și rămâne FAIL/CLEANUP_VERIFIED, nu diagnostic PASS. Commandurile fără ACK rămân FAIL/UNCERTAIN. Fișierele fiecărei comenzi sunt verificate distinct/0600. Celelalte două teste ale fișierului protejează oracle-ul de effects și teardownul incert. Sunt SOURCE doubles și AST cut, nu probă READY instalată sau12 execuții native. Dovezile neafectate rămân scoped, nereexecutate.

FREEZE

Director originale noi: /home/kali/.hermes/cache/scratch/settings-sol-team-b45fd55/installed-legal-prefix/
FREEZE.json SHA256: 1e60a9aa2ab85acc64c63a6f56da77c97a2ab18a9ca9b5d1d0f30b512611612f
candidate.patch SHA256: fc4e3799c15cf2511becf88d19c5486287b0bbfe992bb9611488ebb74ba8a3a9
installed_stop.py SHA256: e9ea1dc575388330ab75d6f0fcf30c93cbba8c8e8d017f48d83e9c0c1750254e
test_installed_stop_lock_oracle.py SHA256: bc535aee64ea18ad6e1ce28831fe9c49ecd73d35ecf405881ba0f6987f53d1c6

Reutilizarea inputului instalat, fără build nou

Metadata citită: /home/kali/.hermes/cache/scratch/omnis-bundle-xi8ua6is/data/omnis/image.json este complet, format3/t1-provider-settings/release0.1.1, proiect omnis-local-ea23cc8205dd499a89a6eaf7ebcf72a9, aceeași identitate daemon din mandat. Imagine sha256:f33c4c2fe8072d9a8f66979d9114114b3a24bcd5522ebb751c64f902b9ed2151; manifest instalat SHA256 f09766be6239f6eed62c0e22aed0b5acd6ee2a3658f239e6e78636ff99260262, egal receiptului. CLI privat există/executabil: /home/kali/.hermes/cache/scratch/omnis-bundle-xi8ua6is/cli/bin/omnis. Toate131 fișierele workspace-ului pregătit tcp-normal-attempt-1/development-f84ded1e534f coincid cu freeze-ul anterior. Vechiul state nu are startup.json; nu îl reutilizăm.

Reutilizarea este eligibilă SOURCE/metadata condiționat, nu adoption foreign: ControlRuntime.__init__(:209–307) validează release/manifest/receipt, profil, platformă, socket/daemon, image ID/tag/labels/proiect/UID și PG pin. Start(:1272–1276) refuză orice resursă de proiect preexistentă. Acești predicați rămân și se execută la consumatorul real; nu i-am substituit cu metadatele din raport. Censusul live gol este dovada anterioară a părintelui, nu o nouă interogare Docker a mea. Dacă s-a schimbat daemonul/tagul/digestul ori reapare o resursă proprie, se refuză; fără relabel, reconstruire sau adoptare.

Apel direct propus — NUMAI după review/admitere/claim nou al părintelui

Din cwd /home/kali/.hermes/cache/scratch/settings-supervisor-tcp-20261030:

  env -i PATH=/home/kali/.local/share/omnis-toolchains/bin:/usr/bin:/bin HOME=/home/kali/.hermes/cache/scratch TMPDIR=/home/kali/.hermes/cache/scratch /home/kali/OmnisAI/api/.venv/bin/python -I -B -c 'import json,pathlib,sys,time; r=pathlib.Path.cwd(); sys.path[:0]=[str(r/"cli/src"),str(r/"cli/integration"),"/home/kali/.hermes/cache/scratch/settings-supervisor-tcp-evidence-20261030"]; from installed_stop import run_installed_stop; from observe_native_case import summarize; d=pathlib.Path("/home/kali/.hermes/cache/scratch/omnis-bundle-xi8ua6is/data"); receipt=json.loads((d/"omnis/image.json").read_text()); events=run_installed_stop(d,receipt,"/home/kali/.hermes/cache/scratch/omnis-bundle-xi8ua6is/cli/bin/omnis",supervisor_observation={"workspace":"/home/kali/.hermes/cache/scratch/settings-sol-team-b45fd55/tcp-normal-attempt-1/development-f84ded1e534f","deadline":time.monotonic()+600}); print(json.dumps({"events":str(events),"summary":summarize(events)}),flush=True)'

Acesta apelează funcția existentă și creează state/control fresh; nu execută run_native/test_release/install/install-image și nu citește sau consumă vechiul claim. Părintele înregistrează o singură admitere nouă, de exemplu installed-legal-prefix/direct-attempt-admission.json creat exclusiv, și capturează direct exitul/outputul procesului, fără pipeline; claimul nu a fost creat de mine. Nu propun un nou flag public sau runner persistent. Code0 al acestui apel ar însemna numai consumer/summary complet, nu cauză reparată sau READY stabil; excepția rămâne FAIL.

Limite/predare

Zero Docker/DB/build/CLI Start/Stop/network/operator/provider/model/target executate în acest turn; numai SOURCE și metadata de fișiere owned. Nicio nouă recuperare sau purjare; intenturile/claimurile/logurile vechi și originalele028 rămân. Istoria old2/2+diagnostic1/1+team-normal-attempt1FAIL este păstrată, nu resetată. Urmează adjudecarea/reviewul independent și, numai dacă părintele admite, o invocare directă distinctă≤600s. Supervisor cause/fix și disponibilitatea stabilă rămân UNKNOWN/NOT_PROVEN; nu declar T1/canonical/aplicația operatorului funcționale.
