"""Independent process: bounded native telemetry and read-only backend samples."""
import json
import os
from pathlib import Path
import select
import sys
import threading
import time

OUT=Path(__file__).parent
ROOT=Path('/home/kali/.hermes/cache/scratch/t1-supervisor-diagnostic-20261030')
sys.dont_write_bytecode=True
sys.path[:0]=[str(ROOT/'api/src'),str(ROOT/'api/tests')]
fd=int(sys.argv[1]); prefix=sys.argv[2]
inert='--inert' in sys.argv
writer=(OUT/(prefix+'-events.jsonl')).open('x')
os.chmod(writer.name,0o600)
lock=threading.Lock(); targets=set(); native_pids=set(); stopped=threading.Event()
def emit(kind,**fields):
    row={'kind':kind,'mono_ns':time.monotonic_ns(),'wall_ns':time.time_ns(),'observer_pid':os.getpid(),**fields}
    with lock:
        writer.write(json.dumps(row,separators=(',',':'))+'\n'); writer.flush()
connection=None
if not inert:
    from sqlalchemy.engine import make_url
    from conftest import connect_test_database
    connection=connect_test_database(make_url(os.environ['OMNIS_TEST_DATABASE_URL']),autocommit=True)
    connection.execute('SET default_transaction_read_only = on')
    identity=connection.execute("SELECT system_identifier::text,current_setting('server_version'),current_setting('fsync'),current_setting('synchronous_commit') FROM pg_control_system()").fetchone()
    emit('independent_private_db',system_identifier=identity[0],version=identity[1],fsync=identity[2],synchronous_commit=identity[3])
    def backend():
        while not stopped.wait(.1):
            pids=list(targets)
            if not pids: continue
            start=time.monotonic_ns()
            try:
                result=connection.execute("SELECT pid,state,wait_event_type,wait_event,clock_timestamp(),query_start,xact_start,pg_blocking_pids(pid),query FROM pg_stat_activity WHERE pid=ANY(%s)",(pids,)).fetchall()
                for row in result:
                    query=row[8].strip().upper()
                    emit('native_backend_sample',backend_pid=row[0],state=row[1],wait_type=row[2],wait=row[3],db_now=row[4].isoformat(),query_start=row[5].isoformat() if row[5] else None,xact_start=row[6].isoformat() if row[6] else None,blocking_pids=row[7],query_class=query if query in {'COMMIT','ROLLBACK'} else 'OTHER')
                emit('backend_query_elapsed',elapsed_ns=time.monotonic_ns()-start)
            except Exception as error:
                emit('independent_backend_error',error_type=type(error).__name__)
                return
    thread=threading.Thread(target=backend,daemon=True); thread.start()
else:
    thread=None
emit('independent_process_ready',inert=inert)
print('SOL_WITNESS_READY',flush=True)
buffer=b''; last=time.monotonic_ns(); deadline=last+400_000_000_000
last_proc=last
try:
    while time.monotonic_ns()<deadline:
        ready,_,_=select.select([fd],[],[],.05)
        now=time.monotonic_ns()
        emit('independent_process_progress',gap_ns=now-last,process_cpu_ns=time.process_time_ns())
        last=now
        if now-last_proc>=100_000_000:
            last_proc=now
            for pid in list(native_pids):
                try:
                    sched=[int(v) for v in Path(f'/proc/{pid}/schedstat').read_text().split()]
                    stat=Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()
                    emit('native_scheduler_sample',native_pid=pid,run_ns=sched[0],runqueue_wait_ns=sched[1],timeslices=sched[2],state=stat[0],major_faults=int(stat[9]))
                except FileNotFoundError:
                    native_pids.discard(pid)
                except OSError as error:
                    emit('native_scheduler_access_error',native_pid=pid,error_type=type(error).__name__)
                    native_pids.discard(pid)
        if not ready: continue
        data=os.read(fd,65536)
        if not data: break
        buffer+=data
        while b'\n' in buffer:
            packet,buffer=buffer.split(b'\n',1)
            row=json.loads(packet)
            if row['kind'] in {'native_identity','declared_synthetic_emission_control'}:
                native_pids.add(row['pid'])
            if type(row.get('backend_pid')) is int and row['backend_pid']>0:
                targets.add(row['backend_pid'])
            emit('native_event_received',event=row)
    else:
        raise TimeoutError('SOL_WITNESS_BOUNDED_DEADLINE')
finally:
    stopped.set()
    if thread: thread.join(timeout=5)
    emit('independent_process_settled',thread_alive=thread.is_alive() if thread else False,partial_packet=bool(buffer))
    if connection: connection.close()
    writer.close(); os.close(fd)
if (thread and thread.is_alive()) or buffer:
    raise SystemExit(2)
