"""Native supervisor attachment: real main(), no product edits or extra authority."""
import asyncio
from contextlib import contextmanager
import functools
import importlib.util
import json
import os
from pathlib import Path
import sys
import time

OUT=Path(__file__).parent
ROOT=Path('/home/kali/.hermes/cache/scratch/t1-supervisor-diagnostic-20261030')
sys.dont_write_bytecode=True
sys.path[:0]=[str(ROOT/'api/src'),str(ROOT/'api/tests')]
fd=int(sys.argv[1])
os.set_blocking(fd,False)
spec=importlib.util.spec_from_file_location('sol_original_observer',OUT/'observe_existing.py')
obs=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=obs
spec.loader.exec_module(obs)
original_emit=obs.emit
dropped=0

def emit(kind,**fields):
    global dropped
    original_emit(kind,**fields)
    row=obs.rows[-1]
    packet=(json.dumps(row,separators=(',',':'))+'\n').encode()
    try:
        if len(packet)>4096 or os.write(fd,packet)!=len(packet):
            dropped+=1
    except (BlockingIOError,BrokenPipeError):
        dropped+=1
obs.emit=emit

async def progress():
    last=time.monotonic_ns()
    while True:
        await asyncio.sleep(.05)
        now=time.monotonic_ns()
        emit('native_loop_progress',gap_ns=now-last)
        last=now

if '--emission-control' in sys.argv:
    async def control():
        task=asyncio.create_task(progress())
        emit('declared_synthetic_emission_control',native_pid=os.getpid())
        await asyncio.sleep(.18)
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass
    asyncio.run(control())
    emit('emission_control_end',dropped=dropped)
    os.close(fd)
    raise SystemExit(0)

from omnis.supervisor import __main__ as consumer
from omnis.modules.instance import service as instance
from omnis.modules.runs.model_test_runtime import ApiKeyModelTest
from omnis.transport.local_control import LocalControl
from omnis.supervisor.model_sender import ModelSender,Backend

# This observer is bound to this child's imports, not the parent interpreter.
emit('native_identity',consumer_source=str(Path(consumer.__file__).resolve()),instrumented_main=True,source_root=str(ROOT),model_owner_source=str(Path(sys.modules[ApiKeyModelTest.__module__].__file__).resolve()))
cycle=0
original_cycle=instance.LeaseTrace.cycle
@contextmanager
def observed_cycle(self):
    global cycle
    cycle+=1
    with original_cycle(self):
        emit('native_cycle_begin',cycle=cycle)
        try:
            yield
        finally:
            emit('native_cycle_end',cycle=cycle,dropped=dropped)
instance.LeaseTrace.cycle=observed_cycle
original_mark=instance._lease_mark

def mark(step,**kw):
    original_mark(step,**kw)
    trace=instance._lease_trace.get()
    if trace is not None and trace.task is asyncio.current_task() and trace.events:
        emit('native_cycle_boundary',cycle=cycle,boundary=trace.events[-1])
instance._lease_mark=mark
original_init=ApiKeyModelTest.__init__

def model_init(self,*a,**kw):
    original_init(self,*a,**kw)
    emit('real_model_owner_constructed',owner_class=type(self).__name__)
ApiKeyModelTest.__init__=model_init
original_dispatch=LocalControl._dispatch
@functools.wraps(original_dispatch)
async def dispatch(self,command):
    emit('local_control_dispatch_begin',op=command.op,model_owner_bound=getattr(self.model_test,'__self__',None).__class__.__name__=='ApiKeyModelTest')
    try:
        reply=await original_dispatch(self,command)
        emit('local_control_dispatch_end',op=command.op,ok=reply.get('ok'),error=reply.get('error'))
        return reply
    except BaseException as error:
        emit('local_control_dispatch_error',op=command.op,error_type=type(error).__name__)
        raise
LocalControl._dispatch=dispatch
for name in ['reconcile','drain','drain_models']:
    original=getattr(ApiKeyModelTest,name)
    def install(name,original):
        @functools.wraps(original)
        async def observed(self,*a,**kw):
            emit('model_owner_callback_begin',method=name)
            try:
                return await original(self,*a,**kw)
            finally:
                emit('model_owner_callback_end',method=name)
        setattr(ApiKeyModelTest,name,observed)
    install(name,original)

# No caller in this diagnostic may enter provider/metadata or target transport.
async def forbidden(*a,**kw):
    emit('forbidden_provider_boundary')
    raise PermissionError('DIAGNOSTIC_PROVIDER_IO_FORBIDDEN')
for name in ['send','metadata','metadata_page']:
    setattr(ModelSender,name,forbidden)
Backend.connect_tcp=forbidden

def no_network(event,args):
    if event.startswith('socket.getaddrinfo') or (event=='socket.__new__' and args[1]!=1):
        emit('forbidden_network_boundary')
        raise PermissionError('DIAGNOSTIC_NETWORK_FORBIDDEN')
sys.addaudithook(no_network)
original_run=consumer.run
async def observed_run():
    task=asyncio.create_task(progress())
    try:
        return await original_run()
    finally:
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass
consumer.run=observed_run
try:
    result=consumer.main()
    emit('native_main_return',exit=result,dropped=dropped)
finally:
    os.close(fd)
raise SystemExit(result)
