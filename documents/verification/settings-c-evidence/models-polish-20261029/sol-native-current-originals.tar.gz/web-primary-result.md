VERDICT: PROPUNERE CONDIȚIONALĂ; cauza primară UNKNOWN, fără defect de produs demonstrat.

Bază verificată: b45fd552cd8c5c45eefbe2d47127fd02365f73c1, tracked/index curate. Comparația cu 1629ade confirmă bootstrap/ProviderSettings/sessionScope/Wizard/setup/config/lock identice și loaderul inițial Settings neschimbat; pagina și testele au alte modificări. client.ts diferă numai prin tipul RemoveModel. Originalul recuperat rămâne 4FAIL/289PASS; fbb379e rămâne acceptat pentru contaminarea secundară.

Frontiere demonstrate, nu cauze atribuite

Provider: Checking local session precede orice Add/key-save. Traseul este App.Shell→BrowserSessionProvider→useBrowserSession→api.session/request/body→React Query→commit React. Nu avem martor istoric pentru settlement/notificare/commit; settingsBackend întoarce session imediat, dar nu o înregistrează în state.reads (web/tests/settings-fixtures.ts:27–33).

Known capsule: eșec înaintea tastaturii. Add models prezent, disabled, înseamnă că bindingul ProviderSettings/sessionScope a trecut. Urmează SettingsModelsPage.load: instance→providerKeys→readLibrary→latest-entry→catalog search local→publicare agregată (web/src/features/engagement/SettingsModelsPage.tsx:54–84). Nu știm care await sau notificare/commit întârzia. Nu este dovadă de Refresh/provider IO.

POST: timeoutul nu dovedește nici că HTTP POST începuse. Față de PUT, cazul completează întâi cinci câmpuri cu user.type (web/src/app/Wizard.test.tsx:57–62); prima mutație primește 413 imediat în fixture. user-event instalat 14.6.7 așteaptă setTimeout(0) per tastă și la încheierea API-ului; RTL.asyncWrapper adaugă alt timer. Acest traseu pre-request nu era observat. Abia apoi urmează Wizard.save→readPrivate→api.createDraft/body→BODY_TOO_LARGE.

Ipoteze, în ordine

1. Progres întârziat al timerelor/notificării/commitului sau user-event: mecanism comun posibil, nu diagnostic CPU/VM. TanStack 5.103.2 livrează batchCalls către useSyncExternalStore prin setTimeout(0); query success nu dovedește DOM comis.
2. Settlement întârziat session/load/JSON: neexclus prin fixture-ul cu Response imediat; lipsesc spanurile originale.
3. Teardown/contaminare primară: neprobată. Provider și known erau primele cazuri declarate în fișierele originale; Vitest implicit isolate=true. Ordinea globală/intercalarea workerilor rămân necunoscute. cleanup dezmontează React, nu anulează promisiunile user-event; aceasta nu justifică speculativ client.clear.

Cel mai mic control propus — NU executat

Cerință→consumer→risc→decizie: bootstrap/editare/413→cele trei cazuri App existente→separă setupul/schedulerul de așteptarea produsului→alege exclusiv remediul frontierei măsurate. Extensie temporară în callerii existenți, nu harness nou: markeri bounded begin/end pentru session/body, notificare/commit, await-urile load și user-event pre-Save; owner capturat înainte de async, niciun fallback «current test», fără payload/token.

Calibrare înaintea tentativei: hold/release la frontiera urmărită trebuie să distingă (a) session cache-success/notificare reținută/Checking, (b) load reținut/Settings fără library, (c) user-event pre-Save reținut/zero POST. Negativ: aceeași frontieră eliberată, oracle original satisfăcut. Sunt controale SOURCE injectate, nu explicația incidentului. Numai cu admitere/buget nou explicit urmează observația fără hold pe consumerul existent, limite/topologie neschimbate. Un nou PASS izolat nu adjudecă FAIL-ul și nu resetează bugetele consumate.

Remediu și acceptare condiționale

Dacă spanul dominant este exclusiv completarea auxiliară POST: numai cele cinci user.type→fireEvent.change; păstrați tastarea numelui, 413, re-editarea acceptată și payloadul exact. Altfel, fixați numai callbackul/callerul demonstrat; fără scheduler global/QueryClient speculativ.

Scope posibil, căi exacte sub web/: src/app/ProviderKeySettings.test.tsx (mount/open), src/app/SettingsWizard.test.tsx (known/mount), src/app/Wizard.test.tsx (POST setup), tests/settings-fixtures.ts (settingsBackend). Produs numai cu finding: src/app/App.tsx (Shell), src/features/bootstrap/useBrowserSession.ts, src/features/engagement/SettingsModelsPage.tsx (load), src/features/engagement/Wizard.tsx (save), src/shared/api/client.ts (session/request/body/createDraft). Fără config/exports/dependențe noi.

Regresie: callerii modificați și controalele auth/413 afectate; RED de clasă→fix minim→GREEN cu spanul corectat, review independent pe bytes finali. 1000ms waitFor și 5000ms test sunt limite ale oracle-ului, nu SLA canonic; requestul produs are 12000ms. Nu se relaxează. Canonicalul unic check-components≤5400s se admite după dispoziția actuală justificată astfel și eliminarea prerechizitelor supervisor, nu după certitudine retrospectivă imposibilă. Originalul rămâne FAIL; T1 cere și gate-ul final/aplicația reală.

Neexecutat: teste, fixtures, browser/servicii/DB/provider, editări repo, commit/push; fișierele protejate neatinse. Risc: sursa localizează frontierele neobservate, nu dovedește încă o cauză sau un remediu primar.
