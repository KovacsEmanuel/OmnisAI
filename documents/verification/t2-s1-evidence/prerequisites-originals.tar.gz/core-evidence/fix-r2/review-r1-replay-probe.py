"""Focused SOURCE call-path probe. No PG, sockets, children or native execution.

Reuse only the setup prefix of the existing source test, ending before its
adapter/native section. The stored descriptor and catalog lookup are explicit
SOURCE doubles. Run real replay -> readback -> qualified -> ModelDispatch.read
-> _context -> ManagedAdmission._source -> PureProbe._selection -> load_probe.
Stop at candidates.sources, immediately after the actual legacy guard: this
proves guard reachability/refusal, not complete historical replay or PG joins.
"""
import ast
import asyncio
import io
import json
import subprocess
import sys
import tarfile
import tempfile
from contextlib import asynccontextmanager
from pathlib import Path
from types import MethodType
from unittest.mock import AsyncMock
from uuid import uuid4

REPO = Path('/home/kali/.hermes/cache/scratch/omnis-s1-20261104')
HEAD = 'f85e89a84b264f05466b8b085d79aa21de986d73'
BASE = '69157fe2aac2198397d45af10d9001923e27f47d'
archive = subprocess.check_output(['git', 'archive', HEAD, 'api', 'skills', 'profiles', 'integrations/hermes'], cwd=REPO)
old_source = subprocess.check_output(['git', 'show', BASE + ':api/src/omnis/modules/runs/managed_admission.py'], cwd=REPO, text=True)


def deny_effect(event, args):
    if event in {'socket.connect', 'socket.bind', 'socket.getaddrinfo', 'subprocess.Popen', 'os.system', 'os.fork', 'os.posix_spawn', 'os.exec'}:
        raise AssertionError('SOURCE effect denied: ' + event)


with tempfile.TemporaryDirectory(prefix='u02-r1-replay-', dir='/home/kali/.hermes/cache/scratch') as temp:
    root = Path(temp)
    with tarfile.open(fileobj=io.BytesIO(archive)) as stream:
        stream.extractall(root, filter='data')
    sys.path[:0] = [str(root / 'api/src'), str(root / 'api/tests')]
    sys.addaudithook(deny_effect)
    import pytest
    import test_model_admission as fixtures
    from omnis.modules.runs import managed_admission, model_protocol
    from omnis.modules.runs.plan_snapshot import snapshot_payload
    from omnis.modules.runs.pure_probe import PureProbe
    from omnis.modules.settings import candidate_catalog, candidate_store as records
    from omnis.modules.settings.catalog_models import CatalogError
    from omnis.modules.settings.catalog_publication import PublicationCatalog
    from omnis.modules.tasks import managed_store
    from omnis.modules.instance.schemas import NativeTaskCommand
    from omnis.supervisor.native_tasks import NativeTaskOwner

    assert Path(managed_admission.__file__).is_relative_to(root)
    tree = ast.parse(Path(fixtures.__file__).read_text())
    setup = next(n for n in tree.body if isinstance(n, ast.AsyncFunctionDef) and n.name == 'test_qualified_projection_reaches_cold_admission_without_model_reservation')
    # Exact existing setup, stopping before the first adapter import (line 223).
    stop = next(i for i, n in enumerate(setup.body) if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'adapter' for t in n.targets))
    setup.body = setup.body[:stop] + [ast.Return(value=ast.Call(func=ast.Name(id='locals', ctx=ast.Load()), args=[], keywords=[]))]
    setup.decorator_list = []
    setup.name = 'source_setup'
    setup_module = ast.fix_missing_locations(ast.Module(body=[setup], type_ignores=[]))
    namespace = dict(vars(fixtures))
    exec(compile(setup_module, str(fixtures.__file__), 'exec'), namespace)
    old_class = next(n for n in ast.parse(old_source).body if isinstance(n, ast.ClassDef) and n.name == 'ManagedAdmission')
    old_method = next(n for n in old_class.body if isinstance(n, ast.AsyncFunctionDef) and n.name == '_source')
    old_namespace = dict(vars(managed_admission))
    exec(compile(ast.fix_missing_locations(ast.Module(body=[old_method], type_ignores=[])), BASE + ':managed_admission.py', 'exec'), old_namespace)

    class PassedLegacyGuard(Exception):
        pass

    async def probe(method, legacy, label):
        with pytest.MonkeyPatch.context() as mp:
            state = await namespace['source_setup'](root / label, mp)
            domain, conn = state['managed'], state['connection']
            owner, run = state['owner'], state['run']
            prepared, binding = state['prepared'], state['binding']
            selected = state['sources'][0].selection
            domain.root = root / label / 'private-catalog'
            domain.root.mkdir(mode=0o700)
            domain._source = MethodType(method, domain)
            command = NativeTaskCommand.model_validate({
                **fixtures.preflight_command(), 'owner_id': owner,
                'manifest_ref': records.reference(state['manifest']),
                'action': 'model_protocol_prepare', 'protocol_id': str(uuid4()),
                'provider_config_ref': records.reference(records.envelope('provider-config', {})),
                'protocol_caps': {'calls': 1, 'output_tokens': 64, 'wall_seconds': 3},
            })
            descriptor = records.envelope('model-dispatch-owner', {
                'version': 1, 'provenance': model_protocol.PROVENANCE,
                'owner_id': owner, 'run_id': run, 'manifest_ref': command.manifest_ref,
                'binding_ref': records.reference(binding), 'authority': binding['payload']['authority'],
                'runtime_boot': binding['payload']['runtime_boot'], 'purpose': 'PREPARE',
                'provider_config_ref': command.provider_config_ref,
                'execution_selection_ref': records.reference(selected), 'prepared': prepared,
                'requested_caps': command.protocol_caps, 'admitted_caps': command.protocol_caps,
                'request_id': str(uuid4()), 'body_digest': 'a' * 64, 'frame_digest': 'b' * 64,
                'body': '{}', 'deadline': '2030-01-01T00:00:00+00:00', 'deadline_ns': 1,
            })
            refs = {'descriptor_ref': records.reference(descriptor), 'dispatch_ref': records.reference(records.envelope('model-dispatch', {}))}
            mp.setattr(managed_store, 'command_replay', AsyncMock(return_value=refs))
            mp.setattr(managed_store, 'owned', AsyncMock(return_value=(run, descriptor)))
            candidate = records.envelope('candidate-snapshot', {})
            publication = records.envelope('catalog-publication', {
                'compiler_revision': candidate_catalog.LEGACY_COMPILER_REVISION if legacy else candidate_catalog.COMPILER_REVISION,
                'evaluator_revision': candidate_catalog.LEGACY_EVALUATOR_REVISION if legacy else candidate_catalog.EVALUATOR_REVISION,
                'snapshot_ref': records.reference(candidate),
                'profile_ref': records.reference(records.envelope('profile', {})),
                'candidate_refs': [], 'dependency_closure_refs': [], 'dependency_artifact_refs': [],
                'material_digest': 'c' * 64, 'resolved_index_digest': 'd' * 64,
                'dependency_closure_digest': 'e' * 64, 'created_by': owner,
            })
            snapshot = records.envelope('run-snapshot', snapshot_payload(publication))
            group = str(uuid4())

            async def catalog_get(connection, actual_owner, pin):
                assert connection is conn and actual_owner == owner
                if pin == records.reference(selected):
                    return group, selected
                if pin == selected['payload']['snapshot_ref']:
                    return group, snapshot
                assert pin == records.reference(publication)
                return group, publication

            mp.setattr(records, 'get', catalog_get)
            mp.setattr(PublicationCatalog, '_readback', AsyncMock(return_value={'publication': publication, 'snapshot': candidate, 'resolved_index': {}}))
            mp.setattr(candidate_catalog.CandidateCatalog, 'sources', AsyncMock(side_effect=PassedLegacyGuard()))
            trace = []
            original_selection = PureProbe._selection

            async def selection(self, *args, **kwargs):
                trace.append({'method': 'PureProbe._selection', 'read_only': kwargs.get('read_only', True)})
                return await original_selection(self, *args, **kwargs)

            mp.setattr(PureProbe, '_selection', selection)
            for mod, name in [(records, 'put'), (records, 'complete'), (managed_store, 'put'), (managed_store, 'command_complete')]:
                mp.setattr(mod, name, AsyncMock(side_effect=AssertionError('replay write denied')))

            @asynccontextmanager
            async def begin():
                yield conn

            domain.engine.begin = begin
            handler = object.__new__(NativeTaskOwner)
            handler.domain = domain
            before = fixtures.canonical(state['graph'])
            try:
                await handler._model_protocol(command, binding, 0.0)
                raise AssertionError('expected bounded gate observation')
            except PassedLegacyGuard:
                outcome = 'PASSED_ACTUAL_LEGACY_GUARD'
            except CatalogError as error:
                if not trace:
                    raise
                outcome = error.reason
            assert fixtures.canonical(state['graph']) == before
            assert len(trace) == 1, (outcome, trace)
            return {'case': label, 'outcome': outcome, 'trace': trace, 'retained_managed_graph_unchanged': True}

    async def main():
        results = []
        results.append(await probe(old_namespace['_source'], True, 'base-legacy-replay'))
        results.append(await probe(managed_admission.ManagedAdmission._source, True, 'final-legacy-replay'))
        results.append(await probe(managed_admission.ManagedAdmission._source, False, 'final-current-replay'))
        assert [r['outcome'] for r in results] == ['PASSED_ACTUAL_LEGACY_GUARD', 'LEGACY_READ_ONLY', 'PASSED_ACTUAL_LEGACY_GUARD'], results
        print(json.dumps({'source': HEAD, 'compared_source_method': BASE, 'results': results, 'limit': 'SOURCE graph/descriptor/catalog lookup doubles; actual replay/readback/caller/guard chain; stops before compilation, not full historical replay or persistence proof.'}, indent=2))

    asyncio.run(main())
