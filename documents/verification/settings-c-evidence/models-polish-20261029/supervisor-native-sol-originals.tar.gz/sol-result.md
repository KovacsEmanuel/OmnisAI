# Rezultat Sol — supervisor lease loss, fără remediu implementat

## Verdict și stare recuperabilă

Expirarea este autentică și refuzul supervisorului este corect fail-closed. Cauza fizică a întârzierii din 30 octombrie, 01:24:29–01:24:35 UTC, rămâne NEIDENTIFICATĂ. Nu există dovadă suficientă pentru a alege între commit/protocol PostgreSQL și descheduling/blocarea buclei sau a VM-ului. Nu am găsit un defect demonstrat de lease/oracle care să explice singur incidentul.

Prima invocare privată a fost baseline-ul InstanceService/observer:25PASS, pytest55.37s, runner66.17299560099491s, exit0/family_drained=true. Nu a executat procesul supervisor/model-owner. Follow-up-ul de mai jos a executat acum consumerul nativ real și a observat o întârziere de commit în WalSync; NU a reprodus pierderea lease-ului. Nicio modificare de produs, test tracked, configurație, deadline, lease sau durability. Nicio recuperare, pornire/oprire sau scriere în DB-ul operatorului.

Buget curent:2/2invocări private consumate,197.41416285399464s cumulat; ZERO rămase. La prima predare, invocarea2 era neconsumată și nu am reluat suitele de serviciu. Părintele a admis ulterior procesul nativ drept consumer material diferit, după drainul Models. Originalele invocării1 sunt neschimbate, confirmat prin hashurile păstrate în freeze2. Contoarele istorice Models/default-web/SOURCE și canonicalul nu au fost resetate sau consumate. Nu se lansează o a treia invocare.

Recovery point unic: acest fișier. Artefacte originale/allowlisted: /home/kali/.hermes/cache/scratch/t1-parallel-20261030/sol-evidence/.

## CURRENT follow-up — proces nativ supervisor/ModelOwner, invocarea2/2

Rezultat: **1PASS diagnostic nativ, pytest119.53s, runner131.24116725299973s, exit0/family_drained=true**. Nu este acceptare T1/T2, proces instalat al operatorului sau o remediere. Cea mai lentă tranzacție nouă localizează întârzierea în commitul PostgreSQL/WalSync; nu justifică atribuirea retrospectivă a incidentului5852ms.

### Consumerul real și diferențele explicite

Selecție unică din test-sl04-pg: api/tests/test_supervisor.py::test_real_supervisor_is_unique_and_restart_stays_closed[before_shutdown]. Nu au rulat celelalte cazuri/suite ale targetului. Helperul start_supervisor și request/stop au primit un atașament scratch în procesul de diagnostic; asserțiile testului și ownerul/attestorul/guardurile/cleanupul fixture-ului original sunt păstrate.

Copiii au executat **consumer.main() și bucla reală run()** din checkoutul exact539e89f, nu o simulare a lor. Bootstrapul diferă de argv stock python -I -m omnis.supervisor: python -I -B native_bootstrap.py <FD>, source explicit, preimporturi de instrumentare și telemetrie pe pipe anonim nonblocking. Doi parametri fresh vault/key și egress-dir fix/vault au activat ramura reală ProviderSettingsOwner/ModelSender/ApiKeyModelTest; nu există operații/model/chei de seed. Apelurile provider/metadata/transport sunt refuzate diagnostic, fără relaxarea vreunui guard. Nu este benchmark cold-start stock și nici execuție în containerul supervisorului instalat. Conexiunea PG este UDS/no-network, nu TCP-ul operatorului.

Identitatea observată în fereastra normală: proces nativ PID2798210/start_ticks20426760, instance6c4e82f6-b959-4d88-aa6e-fd1e6d0e0626, epoch1/generation0, backend PG PID127. Telemetria confirmă sursele __main__.py/model_test_runtime.py din propriul checkout și constructorul real ApiKeyModelTest. Toate dispatchurile observate aveau handlerul model_test legat de acel owner. Au rulat callbackurile reale reconcile/drain/drain_models și LocalControl._dispatch; nu s-au cerut operații model ca să fie exercitate aceste callbackuri.

Un proces martor separat PID2798063 a primit telemetria copilului, a făcut citiri pg_stat_activity READ ONLY/autocommit pe clusterul propriu atestat și a înregistrat progresul său independent de threadul SQL. Markerii de commit/protocol/reset/checkin provin din copilul nativ însuși; nu sunt monkeypatchuri numai în pytest. Positive control înainte de provisioning: bootstrap/martor -I/-B, exit0/0, progres asyncio și3mostre /proc ale copilului recepționate, dropped0, fără PG ori pornire supervisor. Acest control certifică emisia/recepția, nu un commit; wrapperii driver/pool provin byte-exact din observerul exercitat în invocarea1.

### Fereastra, host load și rezultatul discriminant

Fereastră normală90.10564754300867s: **09:54:51.152432–09:56:21.258093UTC**, convertită din markerii monotonic ai părintelui prin perechea wall/monotonic observată în copil pe același kernel. Nu pretind timestamp wall păstrat direct de părinte.82citiri status au păstrat aceeași identitate/epoch/generation și supervisor_ready=true;82cicluri heartbeat reale au markeri compleți de context și driver. Nu a existat pierdere spontană de lease în fereastră.

Nota de host-load a părintelui a fost corelată, nu ignorată. Am citit CURRENT din astra-result.md: lucrările SOURCE declarate se întind09:49:09.010–09:52:10.397UTC. Regresia SOURCE a părintelui este09:58:13UTC/4.84s. **Niciuna nu se suprapune ferestrei native**, nici întregului test nativ care termină înainte de09:56:38. Asta exclude aceste lucrări nominalizate drept încărcare concurentă directă; nu dovedește că întregul host/storage sau operatorul API/DB erau inactive. Nu atribui WalSync Astrei, testelor ori unui host global „quiet” doar din aceste intervale. Corelare: invocation-2-host-correlation-exact.json.

**Observația decisivă nouă este ciclul18 / heartbeat:56**, la09:55:10.720498UTC:

- Marker COMMIT→TX_DONE265.565751ms; driver commit264.947069ms, backend127; driver thread CPU5.411984ms. Protocol COMMIT begin/end încadrează același span. TX status este IDLE la întoarcere.
- Trei mostre din procesul independent, la09:55:10.733834/.834826/.936162UTC, văd **același backend127, aceeași query_start09:55:10.720658, state=active, query_class=COMMIT, wait_type=IO, wait_event=WalSync, blocking_pids=[]**. Autocommit pe observer evită un snapshot pg_stat_activity reținut de o tranzacție de polling.
- ÎN TIMPUL acelui commit apar5tickuri continue ale buclei native și15tickuri ale procesului independent; gapul maxim al acestuia în span este21.380372ms. Nu este o oprire globală a buclei/clientului ori VM-ului pentru întregul interval de265ms.
- Pentru toate82heartbeaturile: driver_end→pool_checkin maxim0.922075ms și checkin→service_return maxim0.292106ms. În cel mai lent ciclu, fresh owned_status încă are4716ms din noua expirare. Refuzul corect la expirare nu a trebuit ocolit.
- În fereastra completă, progresul nativ are gap maxim63.812635ms, procesul independent62.033890ms. Au fost889mostre backend,17dintre ele active/IO/WalSync/COMMIT în total; trei sunt cele corelate mai sus. „17mostre” nu înseamnă17commituri lente distincte și nici265ms măsurați integral într-un syscall fsync.

Sursa PostgreSQL REL_18_6 a fost consultată direct, HTTP200: wait_event_names.txt:274 definește WAL_SYNC drept „Waiting for a WAL file to reach durable storage”; xlog.c:8767 setează WAIT_EVENT_WAL_SYNC înaintea selecției metodei de sync WAL. Extrasele originale sunt în invocation-2-wait-event-source.json. Aceasta validează interpretarea fazei, nu performanța discului fizic de pe hostul VMware.

Limită importantă a martorului de scheduling: **kernel.sched_schedstats=0** la citire. Diferența runqueue_wait_ns=0 din calculul brut NU demonstrează zero așteptare CPU. Progresul asyncio și al procesului independent este observat direct și rămâne valabil; nu îl înlocuiesc cu acel contor inactiv. Nu am schimbat sysctlul. Nu am măsurat schedulingul PID-ului backend pe host ori latența dispozitivului/hypervisorului; backendul poate rămâne în regiunea WalSync și dacă este descheduled în interiorul ei.

Originale: invocation-2-native-events.jsonl; corelarea finitului ciclu: invocation-2-slowest-native-cycle.json; agregarea programatică: invocation-2-summary.json și invocation-2-heartbeat-spans.json. Zero erori ale observerului backend, zero evenimente provider/network forbidden, dropped0 în toate ciclo-finalele și în toate ieșirile native normale observate. Martorul închide cu thread_alive=false/partial_packet=false.

### Ce schimbă și ce NU schimbă concluzia

Pentru **noul** episod265ms, întârzierea se localizează în faza server-side de durabilitate WAL a commitului, nu în returnarea conexiunii/pool sau într-un blocaj al buclei clientului de aceeași durată. „Driver/protocol lent” nu mai este doar o poveste compatibilă pentru această observație; există backend/wait-event corelat. Nu am separat discul virtual/hostul fizic de schedulingul backendului în acea regiune.

Pentru incidentul **istoric5852ms**, lipsesc în continuare backend/wait-event/ACK și martorii de progres din acel ciclu. Noul265ms nu este o recurență de LEASE_LOST și nu dovedește că vechiul interval a avut aceeași cauză. Pentru prioritizarea unui diagnostic ulterior, calea WAL/VM storage are acum un fenomen contemporan măsurat și merită verificată înaintea unui refactor al poolului/lease-ului; atribuirea istorică rămâne UNKNOWN.

Nu există încă un remediu cauzal demonstrat de implementat. **Cel mai mic remediu candidat, numai după confirmarea unei latențe multi-secunde în aceeași fază, este pe calea PG WAL/storage/VM**, nu în _require_owner și nu prin mărirea lease/timeoutului, mutarea timestampului după commit, fsync/synchronous_commit off ori autorestart. Ca să alegi efectiv storage versus backend scheduling, observația care schimbă decizia este același commit lent împreună cu wait-event și timpii I/O/scheduling ai backendului/VM. Un episod în care backendul este deja idle/COMMIT confirmat, dar clientul nu avansează, ar refuta atribuirea acelui episod la WAL sync și ar readuce problema la client/pool/scheduling. Backend WalSync cu progres client+martor și cu latență sync/block-I/O măsurată pe aceeași perioadă ar susține remediul de storage. Accesul hypervisor ready/stun rămâne indisponibil prin Guest API, iar telemetria istorică nu poate fi recreată. Nu cer un al treilea run și nu îl autorizez implicit.

### Comanda, controalele originale și lipsa efectelor model

Comanda exactă din worktree:

    api/.venv/bin/python -I -B /home/kali/.hermes/cache/scratch/t1-parallel-20261030/sol-evidence/run_native.py

Runnerul original a primit --check --target test-sl04-pg --uv /home/kali/.local/share/omnis-toolchains/bin/uv --timeout-seconds600. Atașamentul run_gate înlocuiește numai comanda broad make cu observe_native_case.py și selecția explicită de mai sus. Nu pretind că întregul make test-sl04-pg a trecut. Procesul urmărit proc_14b3d1dab66e are exit0 confirmat prin process_manage.wait. Help/choices, pin/access, source, colecția exact1 și positive control precedă provisioningul; invocation-2-toolchain-preflight.json și invocation-2-collection.txt păstrează rezultatele. Manifestul invocation-2-freeze.json acoperă sursa API, testul/helperii, runnerul/configul și atașamentele; inputurile și toate originalele invocării1 rămân hash-identice la ieșire și la predare.

După cele90s, originalul [before_shutdown] a păstrat controlul său SIGKILL declarat asupra primului owner, după OPEN. Acesta NU este cauza unui LEASE_LOST spontan. Copilul concurent2800343 refuză acquire cu SUPERVISOR_OWNED/exit3; successorul2800546 și ultima pornire explicită2800667 ies0. Asserțiile originale de instance/epoch, închidere moștenită, OPEN refuzat înainte de finalizare, quiescence/FINALIZE și noul OPEN explicit au trecut. Au fost3procese cu ModelOwner construit efectiv; contenderul este refuzat înainte de constructor. Există în telemetrie două erori așteptate ale controalelor negative, nu două recurențe ale incidentului.

Readback READ ONLY după oprirea copiilor: system_operation count0, model_dispatch_v2 count0, fișiere chei0. Au fost numai status/open/finalize din cazul original și statusurile suplimentare declarate, fără Test/Refresh/provider/catalog sau model. Callbackurile ModelOwner sunt reale, dar nu pretind că au avut workeri model activi. Parent/witness/operații: invocation-2-native-parent.json.

### Cleanup, retenție și release slot

Fixture2: root /home/kali/.hermes/cache/scratch/db-f7815d1c00484bdf, project omnis-p01-31859a65942b426a89fcd0ed9948b3d8, CID28e04de59214319ca7f5e6f32ea70b169b566f717e163d6096abc2c4bbafc2de, PG system_identifier7702397094254473247. PG18.6/image8d76d8de17e883d3995f76252e260bc6b7761e9c23edbf3356b0676d37c49ddb, fsync=on și synchronous_commit=on observate de martor. Nicio instalare sau schimbare de durabilitate/pool.

Ownerul original a oprit/înlăturat exact CID-ul; am interpus numai captura raw allowlisted stdout/stderr PG imediat înaintea comenzii remove atestate, după Stop, fără schimbarea comenzii sau a predicatelor. Sunt păstrate și checkpoint/shutdown logs. invocation-2-pg-log-retention.json: stdout11/47linii, SHA256cca7138ff99004821aa74d0ddc84807ef3000d8d36b11fc7fa6a4f5fb271d9e9; stderr14/15linii, SHA2565685d0c24982886a2c7d4fdcf89557c659171efc9c6068ab7fc05ebf373ea2cf. Liniile excluse nu sunt reconstituite. Lipsa streamului PG din invocarea1 rămâne istorică, nu a fost „reparată” prin proba2. Nu există checkpoint în logul păstrat la momentul commitului lent09:55:10; checkpointul explicit este după test la09:56:37.38.

Readback independent exit0: CID/proiect-containere/proiect-rețele absente; UDS lexists=false; toate cele4PID-uri native și PID-ul martor au /proc absent; gate.log.result.json code0/family_drained=true. PGDATA și toate rooturile sintetice/logurile sunt păstrate. Gate original păstrat byte-exact în invocation-2-gate-original.txt, SHA25663371b8facfa5ce50c437fd5137eceff04436bdfd4b797fe7f8dd13f4a1bfd64. Cleanup: invocation-2-cleanup-readback.json.

Cele două symlinkuri temporare proprii au fost unlinkuite numai după compararea inode/target; targeturile comune există în continuare. Checkoutul diagnostic este curat, branch diag/t1-supervisor-20261030, HEAD539e89f3bbe7445b880c48c1203c17f70747215b; sursa/indexul neschimbate, zero commituri. Niciun fișier main/Astra nu a fost modificat; referințele/dependențele și raportul CURRENT Astra au fost numai citite. Nu am publicat secrete și nu am accesat fișierele protejate. invocation-2-final-worktree-state.json confirmă și egalitatea inputurilor/originalelor1.

**Slotul DB este ELIBERAT**, comunicat părintelui imediat după readbackul drainului. Nu mai există efect/proces deținut de această investigație; nicio altă invocare nu urmează în bugetul2/2. Parentul deține orice acceptare/integrări ulterioare.

Secțiunile următoare păstrează analiza inițială și limitele primului baseline, fără a promova acel25PASS în execuție nativă sau a înlocui lipsa martorilor istorici.

## Ce este demonstrat despre incidentul original

Originalul a fost recitit din exact containerul df6b1ab2fe2e07e1e26486e9928a6513268eb1cc0e974c5771ba4ac2935ce9d0. JSON-ul emis este egal cu trace_original din documents/verification/settings-c-evidence/models-polish-20261029/execution-20261030.json. Calculul programatic este în original-trace-analysis.json; ieșirea allowlisted Docker este în host-before.json.

- SUPERVISOR_FAILURE la01:24:35.821638751Z spune phase=QUIESCE, însă trace-ul precis spune OWNED_STATUS/LEASE_LOST. __main__.py:226 atribuie faza externă înainte de owned_status; nu este dovadă de intrare în drain.
- COMMIT→TX_DONE=5852ms, atât monotonic, cât și wall. COMMIT este markerul de dinaintea ieșirii engine.begin(), NU confirmarea unui commit deja terminat: service.py:410–450; SQLAlchemy2.0.54 AsyncEngine.begin/AsyncTransaction.__aexit__/AsyncConnection.__aexit__ au fost inspectate local.
- TX_DONE→următorul CONNECT=0ms; TX_DONE→LIVE_RESULT=5ms. Lockurile următoarei citiri nu explică intervalul mare.
- La citirea care refuză: DB now1793323475804, expiry1793323474946; întârziere858ms, owner și epoch identice. Heartbeatul precedent a scris o expirare NOUĂ, cu4999ms rămase la ultima sa verificare înainte de commit. Vechiul snapshot1793323472652 din heartbeat NU este folosit pentru calculul858ms.
- Trace-ul este complet și neclipped. Monotonic/wall/DB avansează compatibil în intervalul observat. Un simplu salt exclusiv al ceasului PostgreSQL nu explică5852ms monotonic; pauza comună VM/ceas și pauzele dintre eșantioane nu sunt astfel excluse.
- Containerul este în continuare exited/exit3/OOMfalse/restarts0, FinishedAt2026-10-30T01:24:37.163712911Z. Cmd corespunde exact python -I -m omnis.supervisor, fără entrypoint suplimentar și fără nume de variabilă Python instrumentation din allowlist. Nu am afișat Docker Env.

## Ipoteze clasate și limitele refutării

1a. Commit PostgreSQL/ACK libpq lent, inclusiv WAL flush sau schedulingul backendului — PLAUZIBIL, NEATRIBUIT. Localizarea permite această cauză. statement_timeout=2000 nu este o limită wall-clock pentru engine.begin/commit. Sursa PG REL_18_6 furnizată în mandat dezactivează statement timeout înainte de CommitTransactionCommand, iar commitul sincron poate aștepta XLogFlush. Driverul local confirmă await self.wait(self._commit_gen()), cu COMMIT pe protocol și fără timeout total explicit în această cale. Nu există backend PID/wait-event ori moment ACK pentru incident. Nu numesc5852ms „fsync măsurat”.

1b. Supervisor/event loop descheduled sau blocat de alt callback; GIL/proces/VM suspendat temporar — LA FEL DE PLAUZIBIL, NEATRIBUIT. Contextul async cedează execuția în commit și din nou în închiderea conexiunii printr-un task shielded; un callback concurent ori o pauză VM poate ocupa exact aceeași fereastră. Nu există martor de progres/CPU al procesului în incident. Gazda este VMware Virtual Platform,12CPU; VMware Guest API refuză statisticile cpulimit/memlimit cu exit75. %steal curent0 nu exclude ready-time/stun pe VMware. O eventuală suită/build Astra este numai confounder, nu explicație demonstrată; în snapshotul inițial nu apăreau procese Node în lista allowlisted.

2. Connection close/pool reset/return ori lock intern psycopg — POSIBIL, cu prioritate sub cele două de mai sus. engine.begin include toate aceste faze. Sursa arată rollback-on-return; după commit, rollback_gen pe conexiune IDLE revine fără ROLLBACK pe fir. Asta slăbește teoria unei așteptări SQL de rollback obișnuite după commit, nu exclude un task de close întârziat sau un lock intern. În proba nouă, commiturile heartbeat au0.630205–0.728380ms; driver_end→pool_checkin0.110983–0.118446ms. Aceste măsurători nu se transferă incidentului.

3. Contenție SQL pe instance/lease, actor concurent/takeover — RESPINSĂ ca explicație a lockurilor următoarei citiri sau ca takeover. Lockurile inițiale și UPDATE sunt deja parcurse înaintea pauzei; citirea următoare termină în5ms, owner/epoch rămân aceleași. Migrațiile nu definesc un constraint trigger deferred pe supervisor_lease; lease-ul nu are o relație deferred care să explice în mod obișnuit un lock de șase secunde la commit. Un wait server-side neobservat rămâne în1a, nu este exclus absolut.

4. Oracle, snapshot stale, loguri greșit ordonate, observer care fabrică pierderea — RESPINSĂ pentru verdictul de expirare. Originalul și înregistrarea sunt egale, ceasurile și identitățile concordă; expirarea folosită la refuz este cea nouă. Observerul LeaseTrace este în același task, bounded, fără I/O/SQL suplimentar. Nu am măsurat overhead-ul lui în incident; o pauză în interiorul observerului nu poate fi exclusă prin sursă. Testul de acum are alt observer, etichetat, și nu dovedește că instrumentarea istorică nu a perturbat schedulingul. Nu există sys.monitoring/settrace/setprofile/addaudithook în sursele API căutate; cele patru time.sleep găsite sunt în owner.py/serve.py, nu în calea localizată a heartbeatului.

5. Clock step pur, OOM/auto-restart, quota cgroup explicită — FĂRĂ SUPORT; unele variante refutate. Containerul nu a fost OOM-killed/restarted și nu are CPU/memory quota Docker. DB/API actuale au cpu.max=max, nr_throttled=0 și oom_kill=0 pe durata cgroupurilor lor. Acestea nu reconstruiesc schedulerul cgroupului supervisorului dispărut și nu exclud reclaim/host contention. Gazda nu are swap configurat la observația actuală. Journalul kernel din fereastra istorică are doar șase evenimente veth/bridge la01:24:37.4, după ieșire; nu sunt cauza inițiatoare demonstrată. Nu există mesaje relevante timesync/chrony/open-vm-tools în ferestrele consultate. Nici lipsa logurilor, nici NTPSynchronized=yes acum nu certifică lipsa unei pauze istorice.

6. Presiune memorie, I/O/checkpoint, rețea/TCP — POSIBILE SUBCAUZE ale1a/1b, fără atribuire. PostgreSQL rulează pe bind ext4 pe /dev/sda1; nu am găsit checkpoint/WAL/storage-fault în fereastra de log consultată. Nu există telemetrie sar pentru ziua incidentului: singurul fișier sa24 este din24iulie2023/alt kernel. Datele host curente (memorie disponibilă, PSI, disk liber) nu refută presiunea trecută. Proba nouă este UDS/no-network, pe când operatorul folosește rețeaua control Docker: un PASS UDS nu exclude rețeaua/TCP a operatorului.

## Contractul de lease și locul unui remediu

service.py:497–532 folosește DB clock la acquire/UPDATE și GREATEST pentru heartbeat; extensia începe la UPDATE, nu la întoarcerea durabilă către client. Postcheckul heartbeatului verifică în mod intenționat vechiul lease încă valabil și împiedică resuscitarea după expirare în UPDATE. owned_status:1170–1174 citește proaspăt și nu reînnoiește. În incident, chiar noua fereastră este deja consumată când contextul revine. Așadar implementarea fail-closed nu trebuie „reparată” eliminând acest refuz.

Propunerea inițială a fost observațională: commit/protocol/pool/context și backend PID/wait-event, plus proces independent. Ea a fost realizată în consumerul nativ din invocarea2 de mai sus, nu în supervisorul instalat al operatorului. Rezultatul nou separă un commit265ms/WalSync de client/pool pentru acel ciclu. Observația istorică5852ms și stratul storage/hypervisor/backend scheduling rămân neatribuite; nu propun un nou replay Models ori o a treia invocare.

Remediile rămân condiționale, în ordinea celei mai mici schimbări care rezolvă cauza măsurată:

- Dacă backendul este în WALSync/WALWrite/SyncRep în timp ce bucla și procesul avansează: corectați latența storage/VM pe calea PGDATA/WAL (diagnostic host/hypervisor și stocare durabilă), fără fsync=off, synchronous_commit=off ori lease mai lung. Un nou aceeași-condiție commit peste fereastră ar falsifica remediul de mediu. Stocarea rapidă nu remediază un blocaj de event loop.
- Dacă backendul este deja idle/COMMIT confirmat, dar bucla nu avansează, iar un alt proces avansează: remediul este la callbackul sincron/CPU identificat din supervisor, prin reutilizarea delegării bounded existente; nu mutarea arbitrară a expirării. Controlul trebuie să reproducă acel callback în consumerul existent, să păstreze1s cadence/5s lease și să arate refuz la expirare reală. Fără identificarea callbackului nu există patch justificat.
- Dacă bucla, martorul extern și backendul se opresc împreună: investigați scheduling/VM/storage al gazdei. Un guest cu pauze peste5s nu poate avea disponibilitate neîntreruptă sub acest contract; refuzul și recovery manual sunt consecințe de siguranță, nu o cauză rezolvată prin autorestart. Pentru host-side ready-time/stun/loguri există o limită reală de acces: Guest API neactivat, fără privilegii/hypervisor logs în mandat.
- Numai dacă driverul a terminat și pauza este izolată în reset/checkin: remediul se localizează la core/db.py și boundary-ul SQLAlchemy/psycopg demonstrat, nu în _require_owner. Măsurarea a patru heartbeaturi rapide nu justifică dezactivarea resetului ori schimbarea poolului.

Mutarea simplă a lease timestampului „după commit” sau încă un heartbeat după retur nu recuperează în mod sigur autoritatea deja expirată; poate însemna resuscitare ori un nou protocol. Un timeout async ar limita așteptarea clientului, dar nu ar face commitul durabil mai rapid și nu ar transforma un outcome incert în succes. Nu recomand aceste schimbări drept remediu cauzal demonstrat.

## Execuții și dovada nouă

Preflight fără provisioning, toate exit0:

- git status --short --branch; git branch --show-current; git rev-parse HEAD; git diff --stat; git diff --cached --stat.
- /home/kali/OmnisAI/api/.venv/bin/python -I -B ops/run_test_db_gate.py --help.
- _preflight_gate("/home/kali/.local/share/omnis-toolchains/bin/uv", "test-instance-drain-pg") prin încărcarea read-only a runnerului; rezultat real /home/kali/.local/share/omnis-toolchains/uv-0.12.19.
- env PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 /home/kali/OmnisAI/api/.venv/bin/python -I -B -m pytest -p pytest_asyncio.plugin -p no:cacheprovider -c api/pyproject.toml api/tests/test_instance.py api/tests/test_control_regressions.py::test_quiesce_owner_expiry_during_update_lock_wait_rolls_back --collect-only -q:25 colectate. Aceeași colecție a fost verificată prin atașament înainte de efecte; originalul este invocation-1-collection.txt.

Pins/origini inspectate: Python3.13.15, uv0.12.19, SQLAlchemy2.0.54, psycopg/psycopg-binary3.3.6, greenlet3.5.6, pytest9.1.1, pytest-asyncio1.4.0; node24.21.0/npm11.19.0 pentru preflightul runnerului. Imagine PG18.6 digest3725f4e2499eef5134592b3b4ab79a543ed7f8e533b05b5b637af926630f6650, image ID8d76d8de17e883d3995f76252e260bc6b7761e9c23edbf3356b0676d37c49ddb. UID/GID1000, sursă explicită a checkoutului diagnostic; alembic.ini fixează propriul src. Nu am instalat dependențe. Doar două symlinkuri noi, api/.venv și cli/.venv către mediile main deja verificate, au fost temporar create; ulterior au fost unlinkuite fără dereferențiere și fără atingerea targeturilor.

Invocarea reală exactă, din worktreeul diagnostic:

    api/.venv/bin/python -I -B /home/kali/.hermes/cache/scratch/t1-parallel-20261030/sol-evidence/run_existing.py

Scriptul fixează PATH=/home/kali/.local/share/omnis-toolchains/bin:/usr/bin:/bin și TMPDIR=/home/kali/.hermes/cache/scratch; apelează main-ul runnerului original cu --check --target test-instance-drain-pg --uv /home/kali/.local/share/omnis-toolchains/bin/uv --timeout-seconds600. Numai comanda consumerului din run_gate este înlocuită cu python -I -B observe_existing.py; același set25/teste/asserții/limite din target, aceiași owner/attestor/guard/family/cleanup. NU este un make target nemodificat sau un canonical PASS; este o invocare instrumentată explicită a selecției existente. Scripturile și inputurile sunt frozen în invocation-1-freeze.json, neschimbate la ieșire. Proces urmărit proc_ab670a326396, exit0 confirmat prin process_manage.wait.

Dovezi noi, invocation-1-observations.json / heartbeat-boundaries.json / invocation-1-summary.json:

-49 perechi driver commit/protocol pe metodele owner observate; cel mai lung commit3.123186ms. Patru heartbeaturi reale reușite, commit0.630205–0.728380ms, fără recurența5852ms.
- Martor pozitiv pe aceeași cale: testul existent cu BEFORE UPDATE/pg_sleep0.3 traversează heartbeatul real; șase mostre backend PID131 active/Timeout/PgSleep, zero blocking PIDs, bucla progresează cu gap maxim21.7763ms. La306.023489ms, heartbeat refuză LEASE_LOST și NU intră în commit. Asserțiile originale verifică nextval=1 și rollbackul expirării. Demonstrează discriminarea unui UPDATE lent de commit, nu un COMMIT lent nou.
- Al doilea refuz heartbeat observat este controlul existent cu owner expirat/înlocuit; nu o recurență spontană.49commituri nu înseamnă49renovări supervisor și25PASS nu înseamnă25probe native.
- Zero erori ale observerului backend; niciun gap al threadului independent peste100ms; toate11threaduri de observer sunt joinuite/alive=false. Acesta este martor independent de bucla asyncio, NU independent de GIL/proces/VM.
- Metadata citită pe fixture: PostgreSQL18.6, fsync=on, synchronous_commit=on, wal_sync_method=fdatasync. Nu s-au relaxat condițiile pentru verde.

## Cleanup, acces și limite de execuție

Fixture proprie: project omnis-p01-80731d275ac54d16946f16977b7acf1b; root /home/kali/.hermes/cache/scratch/db-2e22016f6c6e45b5; CID af9e8b3ace1f74bd4e6fa24a66d9431a4a55d705255c729366b738ba24fea2df; PG system_identifier7702389199588118558. Before: proiect/root noi, negative missing bind și wrong-password ale runnerului, network_none/socket_private atestate. Inversă executată de același runner: stop exact CID, apoi îndepărtare exact CID, păstrând PGDATA. Nu a fost invocat cleanup global.

Readback independent exit0: exact CID absent, niciun container/network al proiectului, UDS lexists=false; gate.log.result.json code0/family_drained=true. PGDATA/root private și gate.log sunt păstrate. Originalul allowlisted gate.log a fost copiat byte-exact în invocation-1-gate-original.txt, SHA25640a11f0dbe1e03cbf5574699088c7243b9d7152d5fc765261f50bc5da5fe7356. Cleanup/status: cleanup-and-status.json; starea finală Git/linkuri: final-worktree-state.json.

Limită de retenție: runnerul original nu arhivează stdout/stderr PostgreSQL înainte să înlăture containerul. PGDATA și logurile de gate/diagnostic sunt păstrate, dar NU revendic păstrarea streamului Docker PostgreSQL al fixture-ului. Nu îl recreez și nu relansez proba pentru a repara retroactiv această lipsă. Nicio eroare PG spontană nu a fost observată; lipsa streamului rămâne o limită, nu dovadă de absență.

Acces/încercări read-only păstrate: primul colector host a ieșit1 din cauza unui timeout20s journalctl înainte de scrierea rezultatului; corecția scratch a făcut citirea bounded și colectarea ulterioară exit0. Nu a fost o tentativă DB. execute_code a fost refuzat înainte de execuție în modul unattended; am folosit tools directe. Skillurile locale indisponibile prin skill_view au fost citite din repo, fără trust/config change. sysstat nu conține ziua cerută; Guest API cpu/memory exit75. Nu s-au cerut privilegii, parole ori alte întrebări operatorului.

Checkout final: /home/kali/.hermes/cache/scratch/t1-supervisor-diagnostic-20261030; branch diag/t1-supervisor-20261030; HEAD539e89f3bbe7445b880c48c1203c17f70747215b; tracked/index/untracked curate după înlăturarea exclusiv a celor două linkuri proprii. Zero commituri noi, zero push/fetch, niciun fișier tracked schimbat. /home/kali/OmnisAI a fost numai referință/dependențe read-only; worktreeul Astra nu a fost atins. Fișierele protejate nu au fost deschise/hashed/modificate.

Slotul DB este ELIBERAT; nu mai există proces/fixture activ deținut de această investigație. Parentul deține integrarea și acceptarea. SL12/finalizarea T1 rămân blocate; Reticle NOT_APPLICABLE, Chisel BLOCKED_NO_GO.

Nu am executat recovery operator, probe Models/default-web, canonical, stress/suspend sau schimbări de durability; singurul crash este controlul original declarat al cazului nativ. Nu urmează o a treia invocare.
Riscul rămas: noul commit265ms este localizat la WalSync, dar nu explică retrospectiv5852ms și nu separă storage de schedulingul backendului/hypervisorului; un PASS fără recurența pierderii de lease nu este un fix.
