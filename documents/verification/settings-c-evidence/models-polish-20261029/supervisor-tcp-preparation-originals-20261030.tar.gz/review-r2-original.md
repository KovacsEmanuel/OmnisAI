# R2 — review independent complementar, fără efecte diagnostice

**Verdict: CHANGES_REQUESTED, scoped la bugetul agregat și ownership-ul lifecycle. Nu admite încă unica invocare.** Părintele reproduce/adjudecă și decide acceptarea; acesta nu este runtime PASS și nu atribuie cauza5852ms.

## Identitate și limită

- Worktree: `/home/kali/.hermes/cache/scratch/settings-supervisor-tcp-20261030`.
- HEAD: `9122a34d4449212b6271ebed504f1f7ffde3e924`; patru fișiere integration modificate, fără editări ale reviewerului în repo.
- Manifest: `FREEZE.json`, SHA256 **`2016b9599fe6bb05aace7e9e9cf8a3c5b6a8d8fb9462fe1742a3b4802a9d8bb1`**. Recalculare independentă: 4 changed, 6 adapted, 131 prepared_source, zero nepotriviri.
- Diff-ul înghețat și newline-ul suplimentar sunt deja adjudecate de părinte; nu le redeschid.
- Cerință → consumer → risc → decizie: diagnosticul unic≤600s, inclusiv pregătire/teardown → `ReleaseBundleTest.test_t1_supervisor_diagnostic_installed` → `run_installed_stop` → efecte după deadline ori întreruperea ownerului în timpul cleanupului → refuz înainte de `--run` până la adjudecarea constatărilor.
- Scope citit: callerul nou, ownerul instalat și finalizerul existent, compose/install-image/development/config/start/stop afectate, cele trei module observer, runner/calibrare. R1 deține suficiența cauzală ACK/backend; nu o dublez.

## R2-F01 — P1: pregătirea poate lansa install-image după expirarea celor600s

**Loc:** `cli/integration/test_release.py:52,87–125`.

Deadline-ul este creat înaintea pregătirii, dar cele două comenzi uv și cele două comenzi install folosesc timeouturi fixe, fără verificarea/reducerea la bugetul rămas. `shutil.copytree` și chmod-urile intermediare nu verifică deadline-ul. Prima validare a acestui deadline din traseul normal apare abia în `run_installed_stop`, după install-image; aserțiunea agregată de la125 rulează doar dacă tot traseul se întoarce cu succes.

**Reproducer SOURCE executat, exit0, zero subprocess/DB/Docker:** apelul metodei reale cu `bundle_scratch`, `run_cli_scope`, I/O Path și `run_installed_stop` mockuite; ceasul începe la0, iar mockul `shutil.copytree` îl mută la610. Callerul real a emis apoi:

```text
venv at_seconds=0.0 timeout=20
pip at_seconds=0.0 timeout=20
install at_seconds=610.0 timeout=30
install-image at_seconds=610.0 timeout=120
```

Nu s-a simulat un rezultat live: outputul arată exclusiv deciziile callerului sub ceas controlat. O pauză reală la copiere/storage/scheduling poate produce aceeași admitere tardivă.

**Criteriu încălcat:** limita agregată explicită≤600s include pregătirea și teardown-ul; nu este doar o aserțiune post-hoc pe happy path.

**Remediu minim:** în callerul existent, înaintea fiecărui subprocess cu efect și după pregătirea sincronă, refuz dacă bugetul rezervat nu mai încape; timeoutul fiecărei comenzi trebuie plafonat de deadline-ul comun minus rezerva necesară settlementului existent. Nu introduce un owner nou, nu mări bugetul și nu consuma diagnosticul pentru acest control. Adaugă controlul cu ceas avansat în testele existente.

## R2-F02 — P1: watchdogul nou poate omorî ownerul înaintea cleanupului lui normal

**Loc principal:** `cli/integration/installed_stop.py:203–233,994–1007`.
**Callerii care stabilesc intervalele reale:** `cli/src/omnis_cli/config.py:25–28`; `start.py:1151–1159,1183,1699–1709`; `start.py:680–695`; `stop.py:631–651`; `start_runtime.py:350–362`.

Configul fresh scrie numai port/workspace. Rămân deci limitele produsului neschimbate: Start180s, cleanup100s, Stop180s. Adaptorul impune în schimb `subprocess.run(timeout=180)` pentru Start și110s pentru Stop. Pe `TimeoutExpired`, `subprocess.run` omoară/reap-uiește procesul CLI, nu întregul ownership downstream. Docker clients au chiar `start_new_session=True`; forwarderul instalat are de asemenea sesiune proprie. `driver_pending` rămâne True și finalizerul probei sare peste Stop/cleanup, păstrând doar locatorul UNCERTAIN.

**Reproducer de traseu SOURCE, fără a injecta un timeout real:** Start petrece aproape180s în readiness și intră în cleanupul său autorizat de100s; watchdogul adaptorului îl omoară la180s, înaintea întoarcerii normale/receiptului cleanup. Alternativ Stop încă legitim între110 și180s este omorât la110s. Din sursa citită: bugetul normal Start+cleanup este280s, nu180s. Controlul existent `test_supervisor_prefix_uses_one_start_and_owned_stop_or_preserves_uncertainty` modelează timeoutul ca excepție și UNCERTAIN, nu demonstrează drenarea copiilor reali.

**Criteriu încălcat:** reutilizarea ownerului existent până la Stop/failure/timeout și includerea settlementului în buget; watchdogul nou nu trebuie să taie finalizerul produsului. Păstrarea datelor/UNCERTAIN este corectă și nu cer purge sau cleanup nesigur, dar nu substituie păstrarea ownershipului în timpul deadline-urilor normale.

**Remediu minim:** adjudecă intervalele complete înainte de Start, rezervând în cele600s timpul necesar ownerului/finalizerului existent; watchdogul extern nu trebuie să expire înaintea acestor intervale. Folosește cancellation/settlement-ul deja existent dacă refuzul este necesar, fără un supervisor nou și fără schimbarea lease-ului sau deadline-urilor de produs. Nu rezolva numai prin `killpg`: copiii instalați au sesiuni proprii. Control SOURCE cu expiry în cleanup, înainte de o singură probă reală.

## Elemente fără finding nou în scope-ul inspectat

- Fixture fresh: `mkdtemp` separat pentru install și state/control; env explicit; receipt/project nou; workspace DEVELOPMENT propriu validat; Stop selectează binding-ul din journal. Nu am găsit adoptarea instalației operatorului în acest call path.
- Wrapperul build este pe **callerul real**, nu doar decorativ: `compose._run` folosește `docker` prin PATH-ul explicit păstrat; buildul real include `--pull=false`, wrapperul adaugă `--network=none`, iar explicit `pull` este refuzat. Runtime Start folosește ulterior executabilul fix `/usr/bin/docker`, fără build/pull. Nu cer aplicarea pragului Docker28 din vechiul `control_topology.run_probe`: acest caller are rețea internă/no published ports și forwarder host→UDS.
- Limita rămasă de preflight: Dockerfile-ul public are `RUN pip install --no-cache-dir --require-hashes`; buildul offline depinde de cache-ul exact al acelui layer, nu doar de prezența imaginii Python/PG. Nu am verificat cache-ul daemonului și nu declar că lipsește. Un cache miss trebuie să rămână refuz, niciodată fallback de rețea.
- Observer: DB fixată la db:5432/omnis și parola internă existentă; refuz hostaddr/service/passfile; provider send/metadata/metadata_page și Backend.connect_tcp refuzate; audit Python socket/DNS restrictiv. Witnessul citește numai DB-ul fresh, read-only, statement_timeout500, fără export query/DSN/parolă. Acestea sunt constatări SOURCE, nu firewall certification universal.
- Pipe-ul producerului este nonblocking, packet≤4096; witnessul separat are limite de pachet, număr de evenimente și durată. Backpressure poate pierde observații, nu blochează producerul pe scrierea fișierului. Nu afirm overhead zero sau cauză exclusă prin aceasta.
- Comanda supervisorului/attestorul și ownerul model real nu sunt înlocuite; hookurile sunt în copia DEVELOPMENT. Logurile/PGDATA și image-installing/UNCERTAIN sunt păstrate; nu există purge nou în traseul diagnosticului.

## Verificări efectuate și neefectuate

- Citire Git/status/diff și hashurile explicite de mai sus: exit0.
- Reproducerul no-effect F01 pe metoda reală: exit0, confirmă admiterea tardivă.
- Două controale existente, numai SOURCE: `test_supervisor_build_guard_has_no_network_fallback` și `test_supervisor_preflight_refuses_before_fixture_or_runtime`: **2PASS,0.068s,exit0**, prin `/home/kali/OmnisAI/api/.venv/bin/python -I -B` cu source paths explicite.
- Niciun `--run`, install, build, container, service, SQL live, browser, acces operator sau provider/model/target. Nici raw Docker Env, credentiale, DSN operator sau fișiere protejate citite/hashuite. Diagnostic nou rămâne0/1; vechi2/2 neschimbat.
- Reticle NOT_APPLICABLE; Chisel BLOCKED_NO_GO. Fără commit, editare source ori actualizare a hărții globale de către reviewer.

**Livrabil unic creat:** acest original R2. Omis: QA instalată, cache-ul Docker și validarea cauzală R1. Risc de păstrat: chiar după remedierea admission/ownership, proba reală și settlementul exact rămân NOT_RUN; cauza5852ms rămâne UNKNOWN.
