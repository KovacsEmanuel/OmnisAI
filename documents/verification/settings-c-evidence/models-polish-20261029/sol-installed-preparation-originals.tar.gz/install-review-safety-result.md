# Review complementar SAFETY — READ-ONLY, SOURCE scoped

Verdict: APPROVED_SCOPED_SOURCE pentru delta frozen din cli/integration/test_release.py. Niciun finding blocant demonstrat în delta revizuită. Verdictul NU admite o nouă tentativă, trafic de build sau efecte asupra operatorului; nu este PASS instalat și nu închide T1/T2. Părintele decide admiterea, integrarea și acceptarea.

## Identitate exactă verificată

- Worktree: /home/kali/.hermes/cache/scratch/settings-supervisor-tcp-20261030
- Base/HEAD: 9eb87fd11c63490f3d7afa4d7e97efb45decf20f; singurul WIP raportat de Git: cli/integration/test_release.py.
- SHA256 fișier: bb2e3dad4c2cba0306d6bc486b312865ae8a34fb47271faaf247dbd81692d9b7
- FREEZE: /home/kali/.hermes/cache/scratch/settings-sol-team-b45fd55/installed-path-fix/FREEZE.json
- SHA256 FREEZE: 54556f882bb8ff9bb53af51e4ec8576a0c3fb252d68c828c03bc6ef9d2a09edf
- SHA256 candidate.patch: 51e290d11cbcb8158c56f688da918472b87cf677952504d7a140b906cd8d1cdb
- Checkout principal observat: checkpoint/p2-batch2-pause-20261015, HEAD b45fd552cd8c5c45eefbe2d47127fd02365f73c1, tracked clean; cele două fișiere untracked protejate nu au fost deschise/hashuite/modificate.

## Cerință → risc → decizie

1. Owner/deadline/settlement → evitarea unui Docker copil desprins ori a unui watchdog nou incompatibil → delta acceptată SOURCE. La test_release.py:161–183, buildul folosește subprocess.run cu stdout/stderr în fișiere, fără start_new_session, grup nou, PIPE sau timeout propriu; non-build rămâne execv. Astfel noua așteptare rămâne în grupul CLI existent. Nu reautorizez și nu reauditez întreaga implementare run_cli_scope/bundle_scratch ori protocolul ACK; păstrez reviewul anterior scoped pentru corpurile neschimbate. F01/F02 nu sunt redeschise de această delta.

2. Buget după I/O nou → lansarea CLI după consumarea rezervei în flush/fsync → delta acceptată SOURCE. La :86–100, verificarea preparation_timeout(bound) se execută după scrierea/flush/fsync a comenzii și imediat înainte de apelul ownerului. La :194–203 există recheck înaintea consumerului instalat, deadline-ul agregat rămâne 600s; nu sunt schimbate limitele produsului 180/100/180 sau adaptorului 310/210. Persistarea finală poate eșua/refuza; nu există fallback care să transforme asta în succes.

3. Diagnostic păstrat înainte de assert / fără overwrite sau secret ambient → pierderea refuzului inițial ori atingerea unei destinații străine → delta acceptată SOURCE. La :74–84 și :86–118: mediu explicit cu HOME/XDG private, director 0700, sink 0600 O_EXCL|O_NOFOLLOW; comanda este sincronizată înaintea efectului, iar rezultatul CLI înainte de assert. La :166–177: toate sinkurile buildului sunt deschise exclusiv înainte de subprocess, comanda este fsync-uită înainte de lansare, rezultatul și streamurile înainte de exit normal. Semnalul copilului este propagat la :178–182. Timeout/ucidere de grup nu garantează înregistrarea unui returncode final de build; nu revendic această proprietate. Outputul rămâne privat, nu este autorizat pentru publicare integrală. Nu sunt introduse credentiale în argv sau în mediul explicit.

4. Build normal versus autorizație de rețea → descărcări de pachete neadmise → condiție de admitere la părinte, NU constructor demonstrat nesigur. Delta elimină doar injectarea artificială --network=none; compose.py:497–519 păstrează --pull=false, iar shimul refuză pull explicit. Conform contractului cli/README.md:209 indicat în mandat, buildul normal poate cere PyPI/files.pythonhosted.org. --require-hashes nu fixează dependențele build-isolation ale unui sdist, iar --pull=false nu este o barieră de egress. Înainte de orice tentativă, părintele trebuie să adjudice permisiunea precisă și preflightul inputurilor/destinațiilor. Nu propun reinstalarea implicită a unei cerințe offline și nici Dockerfile/wheelhouse/lock/product change. Guardurile runtime provider/target nu sunt modificate de patch.

## Dovezi și limite

Citite: CURRENT/recovery, AGENTS, CONTRIBUTING, team-slice, omnis-review-qa, FREEZE, patch și codul afectat. SHA256-urile de mai sus coincid cu mandatul; git diff --check pe worktree a ieșit 0. Reutilizez dovezile părintelui: cele trei teste SOURCE afectate PASS/0.499s, RED-urile păstrate și scope-ul SOURCE anterior neschimbat; nu pretind execuție independentă a lor. Nu am avut un finding concret care să justifice rularea stuburilor sau un harness nou. O încercare de citire batch prin execute_code a fost refuzată înainte de execuție; citirile au continuat prin uneltele normale.

Findings noi blocante: niciunul demonstrat. Reproducer/remediu de cod: nu se aplică. Noua invocare reală rămâne NOT_ADMITTED/NOT_RUN; lipsa ei nu este blocker circular al aprobării SOURCE. Vechile 2/2 + 1/1 și FAIL_PREPARATION rămân neschimbate. Nu au fost executate Docker/build/install/live SQL/service/lifecycle/provider/model/target, nu au fost citite secrete și nu există editare de sursă, commit sau push. Singura scriere cerută este acest raport scratch.

Nu am verificat buildul real, settlementul real sau comportamentul instalat; Reticle NOT_APPLICABLE, Chisel BLOCKED_NO_GO. Riscul rămas pentru admitere este egressul normal de build, inclusiv build-isolation sdist; operatorul UNAVAILABLE/schema0017 nu devine fixture.
